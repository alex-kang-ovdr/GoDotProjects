class_name VoxelChunkStore
extends RefCounted

const FORMAT_VERSION := 2
const GENERATION_VERSION := DeterministicWorldGenerator.GENERATION_VERSION
const CHUNK_SIZE := 16
const MAX_SAVE_BYTES := 32 * 1024 * 1024

var seed_value := 0
var world_size := 0
var base_cells: Dictionary = {}
var edits: Dictionary = {}
var dirty_chunks: Dictionary = {}
var base_signature := 0
var generation_options: Dictionary = {"mode": "overworld"}
# Effective solid/non-air cells partitioned into 16-cube chunks for local meshing.
var chunks: Dictionary = {}
var mesh_dirty_cells: Dictionary = {}


func initialize(seed_input: int, size_input: int, generated_cells: Dictionary, signature_input: int = -1) -> void:
	seed_value = seed_input
	world_size = size_input
	generation_options = {"mode": "overworld"}
	base_cells = generated_cells
	base_signature = DeterministicWorldGenerator.signature(generated_cells) if signature_input == -1 else signature_input
	edits.clear()
	dirty_chunks.clear()
	chunks.clear()
	mesh_dirty_cells.clear()
	for cell: Vector3i in generated_cells:
		_index_cell(cell, int(generated_cells[cell]))


func get_block(cell: Vector3i) -> int:
	if edits.has(cell):
		return int(edits[cell])
	return int(base_cells.get(cell, -1))


func set_block(cell: Vector3i, material_id: int) -> void:
	if get_block(cell) == material_id:
		return
	if material_id == int(base_cells.get(cell, -1)):
		edits.erase(cell)
	else:
		edits[cell] = material_id
	_index_cell(cell, material_id)
	_mark_dirty(cell)


func consume_dirty_chunks() -> Array[Vector3i]:
	var result: Array[Vector3i] = []
	for chunk: Vector3i in dirty_chunks:
		result.append(chunk)
	result.sort_custom(_sort_cells)
	dirty_chunks.clear()
	return result


func encode(player_state: Dictionary = {}) -> String:
	var edit_rows := []
	var cells: Array = edits.keys()
	cells.sort_custom(_sort_cells)
	for cell: Vector3i in cells:
		edit_rows.append([cell.x, cell.y, cell.z, int(edits[cell])])
	var payload := {
		"format_version": FORMAT_VERSION,
		"generation_version": GENERATION_VERSION,
		"seed": seed_value,
		"world_size": world_size,
		"base_signature": base_signature,
		"generation_options": generation_options,
		"edits": edit_rows,
		"player": player_state,
	}
	var payload_text := JSON.stringify(payload)
	return JSON.stringify({"payload": payload_text, "sha256": payload_text.sha256_text()})


func decode(encoded: String) -> Dictionary:
	var result := inspect_save(encoded)
	if result.ok:
		result.changed_cells = apply_edits(result.edits)
	return result


# Parsing and validation never mutate the live journal or dirty queue.
func inspect_save(encoded: String) -> Dictionary:
	if encoded.length() > MAX_SAVE_BYTES:
		return {"ok": false, "error": "save exceeds size limit"}
	var envelope = JSON.parse_string(encoded)
	if not envelope is Dictionary or not envelope.has("payload") or not envelope.has("sha256"):
		return {"ok": false, "error": "save envelope is malformed"}
	var payload_text = envelope.payload
	if not payload_text is String:
		return {"ok": false, "error": "save payload is malformed"}
	if payload_text.sha256_text() != str(envelope.sha256):
		return {"ok": false, "error": "save checksum mismatch"}
	var payload = JSON.parse_string(payload_text)
	if not payload is Dictionary:
		return {"ok": false, "error": "save payload JSON is malformed"}
	if not SavedPlayerState.integer_in_range(payload.get("format_version"), FORMAT_VERSION, FORMAT_VERSION):
		return {"ok": false, "error": "unsupported save format"}
	if not SavedPlayerState.integer_in_range(payload.get("generation_version"), GENERATION_VERSION, GENERATION_VERSION):
		return {"ok": false, "error": "incompatible generation version"}
	if not SavedPlayerState.integer_in_range(payload.get("seed"), seed_value, seed_value) or not SavedPlayerState.integer_in_range(payload.get("world_size"), world_size, world_size):
		return {"ok": false, "error": "save belongs to a different world"}
	if not SavedPlayerState.integer_in_range(payload.get("base_signature"), base_signature, base_signature):
		return {"ok": false, "error": "generated base differs from saved world"}
	var options: Variant = payload.get("generation_options", {"mode": "overworld"})
	if not options is Dictionary or options.size() != generation_options.size() or options.get("mode") != generation_options.mode:
		return {"ok": false, "error": "save generation mode/options differ"}
	if generation_options.mode == "dungeon" and not SavedPlayerState.integer_in_range(options.get("room_attempts"), generation_options.room_attempts, generation_options.room_attempts):
		return {"ok": false, "error": "save dungeon room attempts differ or are invalid"}
	var player: Variant = payload.get("player")
	if not player is Dictionary:
		return {"ok": false, "error": "player state is malformed"}
	if not player.is_empty():
		var player_error := SavedPlayerState.validate(player)
		if not player_error.is_empty():
			return {"ok": false, "error": player_error}
	var decoded_edits := {}
	var rows = payload.get("edits")
	if not rows is Array:
		return {"ok": false, "error": "edit journal is malformed"}
	for row in rows:
		if not row is Array or row.size() != 4:
			return {"ok": false, "error": "edit row is malformed"}
		for axis in 3:
			if not SavedPlayerState.integer_in_range(row[axis], -32767, 32767):
				return {"ok": false, "error": "edit coordinate is invalid"}
		if not SavedPlayerState.integer_in_range(row[3], -1, BlockRegistry.MATERIAL_COUNT - 1):
			return {"ok": false, "error": "edit material is invalid"}
		var cell := Vector3i(int(row[0]), int(row[1]), int(row[2]))
		var material_id := int(row[3])
		if decoded_edits.has(cell) or material_id < -1 or material_id >= BlockRegistry.MATERIAL_COUNT:
			return {"ok": false, "error": "duplicate cell or invalid material"}
		decoded_edits[cell] = material_id
	return {"ok": true, "error": "", "player": player, "edits": decoded_edits}


# Include the old journal so loading an earlier checkpoint also undoes new edits.
func apply_edits(incoming: Dictionary) -> Array[Vector3i]:
	var candidates := edits.duplicate()
	candidates.merge(incoming, true)
	var changed: Array[Vector3i] = []
	for cell: Vector3i in candidates:
		var next_material := int(incoming.get(cell, base_cells.get(cell, -1)))
		if get_block(cell) != next_material:
			changed.append(cell)
	var normalized := {}
	for cell: Vector3i in incoming:
		if int(incoming[cell]) != int(base_cells.get(cell, -1)):
			normalized[cell] = int(incoming[cell])
	edits = normalized
	for cell in changed:
		_index_cell(cell, get_block(cell))
		_mark_dirty(cell)
	return changed


func save_to_file(path: String, player_state: Dictionary = {}) -> String:
	var encoded := encode(player_state)
	var checked := inspect_save(encoded)
	if not checked.ok:
		return checked.error
	return write_encoded_file(path, encoded)


# Stage and read back before replacing the save; keep the previous file as .bak.
static func write_encoded_file(path: String, encoded: String) -> String:
	var temporary := path + ".pending"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		return "could not open temporary save for writing"
	file.store_string(encoded)
	file.flush()
	var write_error := file.get_error()
	file.close()
	if write_error != OK:
		return "temporary save write failed"
	var readback := read_encoded_file(temporary)
	if not readback.ok or str(readback.encoded) != encoded:
		return "temporary save read-back failed"
	if FileAccess.file_exists(path):
		if DirAccess.copy_absolute(path, path + ".bak") != OK:
			return "could not preserve previous save"
	if DirAccess.rename_absolute(temporary, path) != OK:
		return "could not replace save; previous file preserved"
	return ""


func load_from_file(path: String) -> Dictionary:
	var read_result := read_encoded_file(path)
	return decode(read_result.encoded) if read_result.ok else read_result


static func read_encoded_file(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "save file does not exist"}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {"ok": false, "error": "could not open save for reading"}
	if file.get_length() > MAX_SAVE_BYTES:
		file.close()
		return {"ok": false, "error": "save exceeds size limit"}
	var encoded := file.get_as_text()
	file.close()
	return {"ok": true, "error": "", "encoded": encoded}


func _index_cell(cell: Vector3i, material_id: int) -> void:
	var chunk := DeterministicWorldGenerator.world_to_chunk(cell)
	if material_id == -1:
		if chunks.has(chunk):
			chunks[chunk].erase(cell)
			if chunks[chunk].is_empty():
				chunks.erase(chunk)
		return
	if not chunks.has(chunk):
		chunks[chunk] = {}
	chunks[chunk][cell] = material_id


func _mark_dirty(cell: Vector3i) -> void:
	mesh_dirty_cells[cell] = true
	var chunk := DeterministicWorldGenerator.world_to_chunk(cell)
	var local := DeterministicWorldGenerator.world_to_local(cell)
	dirty_chunks[chunk] = true
	if local.x == 0: dirty_chunks[chunk + Vector3i.LEFT] = true
	if local.x == CHUNK_SIZE - 1: dirty_chunks[chunk + Vector3i.RIGHT] = true
	if local.y == 0: dirty_chunks[chunk + Vector3i.DOWN] = true
	if local.y == CHUNK_SIZE - 1: dirty_chunks[chunk + Vector3i.UP] = true
	if local.z == 0: dirty_chunks[chunk + Vector3i(0, 0, -1)] = true
	if local.z == CHUNK_SIZE - 1: dirty_chunks[chunk + Vector3i(0, 0, 1)] = true


static func _sort_cells(a: Vector3i, b: Vector3i) -> bool:
	if a.x != b.x: return a.x < b.x
	if a.y != b.y: return a.y < b.y
	return a.z < b.z
