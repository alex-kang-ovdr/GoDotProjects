class_name BlockInventory
extends RefCounted

signal changed

var counts := PackedInt32Array()


func _init(initial_count: int = 8) -> void:
	counts.resize(BlockRegistry.HOTBAR_SLOT_COUNT)
	for slot in counts.size():
		counts[slot] = clampi(initial_count, 0, max_for_slot(slot))


func count(slot: int) -> int:
	return counts[slot] if slot >= 0 and slot < counts.size() else 0


func max_for_slot(slot: int) -> int:
	var definition := BlockRegistry.by_slot(slot)
	return int(definition.get("max_stack", 0))


func can_add(slot: int, amount: int = 1) -> bool:
	return amount >= 0 and slot >= 0 and slot < counts.size() and counts[slot] + amount <= max_for_slot(slot)


func add(slot: int, amount: int = 1) -> bool:
	if not can_add(slot, amount):
		return false
	counts[slot] += amount
	changed.emit()
	return true


func consume(slot: int, amount: int = 1) -> bool:
	if amount < 0 or slot < 0 or slot >= counts.size() or counts[slot] < amount:
		return false
	counts[slot] -= amount
	changed.emit()
	return true

