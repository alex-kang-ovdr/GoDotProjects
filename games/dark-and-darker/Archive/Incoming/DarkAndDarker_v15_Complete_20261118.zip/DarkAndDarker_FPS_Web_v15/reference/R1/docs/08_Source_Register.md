# 출처 목록

확인일 2026-11-17. 아래 URL은 수치의 출처이며 페이지 전체를 이 패키지에 복제하지 않았다. 버전은 자료의 선언값이다.

| ID | 자료 | 유형 | 선언 버전 | 읽기 방식 | 제한 |
| --- | --- | --- | --- | --- | --- |
| official_s11 | [Early Access Season #11](https://darkanddarker.com/news/223) | official_patch | S11 | official_page_search_index_text | 공식 변경사항에 명시된 범위에 한해 근거로 사용. 전체 게임 데이터 스냅샷은 아님. |
| official_hf128 | [Hotfix #128](https://darkanddarker.com/news/224) | official_patch | HF128 | official_page_search_index_text | 공식 변경사항에 명시된 범위에 한해 근거로 사용. 전체 게임 데이터 스냅샷은 아님. |
| official_hf130 | [Hotfix #130](https://darkanddarker.com/news/228) | official_patch | HF130 | official_page_search_index_text | 공식 변경사항에 명시된 범위에 한해 근거로 사용. 전체 게임 데이터 스냅샷은 아님. |
| official_hf131 | [Hotfix #131](https://darkanddarker.com/news/229) | official_patch | HF131 | official_page_search_index_text | 공식 변경사항에 명시된 범위에 한해 근거로 사용. 전체 게임 데이터 스냅샷은 아님. |
| official_hf132 | [Hotfix #132](https://darkanddarker.com/news/230) | official_patch | HF132 | official_page_search_index_text | 공식 변경사항에 명시된 범위에 한해 근거로 사용. 전체 게임 데이터 스냅샷은 아님. |
| official_news | [공식 업데이트 목록](https://darkanddarker.com/news/all) | official_index | HF132 | official_page_search_index_text | 공식 변경사항에 명시된 범위에 한해 근거로 사용. 전체 게임 데이터 스냅샷은 아님. |
| class_fighter | [Fighter](https://darkanddarker.wiki.spellsandguns.com/Fighter) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| class_barbarian | [Barbarian](https://darkanddarker.wiki.spellsandguns.com/Barbarian) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| class_ranger | [Ranger](https://darkanddarker.wiki.spellsandguns.com/Ranger) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| class_wizard | [Wizard](https://darkanddarker.wiki.spellsandguns.com/Wizard) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| class_rogue | [Rogue](https://darkanddarker.wiki.spellsandguns.com/Rogue) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| class_cleric | [Cleric](https://darkanddarker.wiki.spellsandguns.com/Cleric) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| class_bard | [Bard](https://darkanddarker.wiki.spellsandguns.com/Bard) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| class_warlock | [Warlock](https://darkanddarker.wiki.spellsandguns.com/Warlock) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| class_druid | [Druid](https://darkanddarker.wiki.spellsandguns.com/Druid) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| class_sorcerer | [Sorcerer](https://darkanddarker.wiki.spellsandguns.com/Sorcerer) | community_snapshot | HF132 | web_page | 자동 수치와 수동 설명이 혼재. 페이지의 Class Data HF132 표시를 보존하며 모든 문장이 최신이라는 보증은 아님. |
| weapon_longsword | [Longsword](https://darkanddarker.wiki.spellsandguns.com/Longsword) | community_snapshot | HF132 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_arming_sword | [Arming Sword](https://darkanddarker.wiki.spellsandguns.com/Arming_Sword) | community_snapshot | HF130 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_rondel_dagger | [Rondel Dagger](https://darkanddarker.wiki.spellsandguns.com/Rondel_Dagger) | community_snapshot | HF130 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_flanged_mace | [Flanged Mace](https://darkanddarker.wiki.spellsandguns.com/Flanged_Mace) | community_snapshot | HF130 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_falchion | [Falchion](https://darkanddarker.wiki.spellsandguns.com/Falchion) | community_snapshot | HF130 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_rapier | [Rapier](https://darkanddarker.wiki.spellsandguns.com/Rapier) | community_snapshot | HF130 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_battle_axe | [Battle Axe](https://darkanddarker.wiki.spellsandguns.com/Battle_Axe) | community_snapshot | HF132 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_double_axe | [Double Axe](https://darkanddarker.wiki.spellsandguns.com/Double_Axe) | community_snapshot | HF130 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_spear | [Spear](https://darkanddarker.wiki.spellsandguns.com/Spear) | community_snapshot | HF132 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_halberd | [Halberd](https://darkanddarker.wiki.spellsandguns.com/Halberd) | community_snapshot | HF130 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_longbow | [Longbow](https://darkanddarker.wiki.spellsandguns.com/Longbow) | community_snapshot | HF132 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| weapon_crossbow | [Crossbow](https://darkanddarker.wiki.spellsandguns.com/Crossbow) | community_snapshot | HF132 | web_page | 표시된 데이터 버전 보존. 공격 타입은 파일상의 라벨이며 시각 모션과 다를 수 있음. 드롭 표는 개편 후 비활성화됨. 탭 번호를 희귀도 코드로 자동 치환하지 않음. |
| attack_times | [Attack Times](https://darkanddarker.wiki.spellsandguns.com/Attack_Times) | community_snapshot | 미확인 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| weapons | [Weapons](https://darkanddarker.wiki.spellsandguns.com/Weapons) | community_snapshot | HF130 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| damage | [Damage](https://darkanddarker.wiki.spellsandguns.com/Damage) | community_snapshot | 미확인 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| impact | [Impact Power](https://darkanddarker.wiki.spellsandguns.com/Impact_Power) | community_snapshot | 미확인 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| stats | [Stats](https://darkanddarker.wiki.spellsandguns.com/Stats) | community_snapshot | HF132 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| movement | [Movement](https://darkanddarker.wiki.spellsandguns.com/Movement) | community_snapshot | HF73 | web_page | 명시적으로 오래된 HF73 페이지. 현행 수치 확정용으로 사용 금지. |
| health | [Health](https://darkanddarker.wiki.spellsandguns.com/Health) | community_snapshot | 미확인 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| healing | [Healing](https://darkanddarker.wiki.spellsandguns.com/Healing) | community_snapshot | 미확인 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| item_state | [Looted Handled Supplied](https://darkanddarker.wiki.spellsandguns.com/Looted_Handled_Supplied) | community_snapshot | 미확인 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| spells | [Spells](https://darkanddarker.wiki.spellsandguns.com/Spells) | community_snapshot | 미확인 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| potion_healing | [Potion of Healing](https://darkanddarker.wiki.spellsandguns.com/Potion_of_Healing) | community_snapshot | 미확인 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| bandage | [Bandage](https://darkanddarker.wiki.spellsandguns.com/Bandage) | community_snapshot | 미확인 | web_page | 일부 오래된 설명·오기·미확정 공식 존재. 충돌 목록과 함께 사용. |
| prototype_v13 | [Crypt of the Fallen v13 업로드 소스](local:DarkAndDarker_FPS_Web_v13.zip) | prototype | crypt-v13 | uploaded_zip_and_node_exports | 원작 데이터가 아닌 사용자의 독립 프로토타입. 원본 파일 수정 없음. |
| monster_skeleton_footman | [Skeleton Footman](https://darkanddarker.wiki.spellsandguns.com/Skeleton_Footman) | community_snapshot | HF132 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_skeleton_archer | [Skeleton Archer](https://darkanddarker.wiki.spellsandguns.com/Skeleton_Archer) | community_snapshot | HF132 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_skeleton_guardsman | [Skeleton Guardsman](https://darkanddarker.wiki.spellsandguns.com/Skeleton_Guardman) | community_snapshot | HF132 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_skeleton_mage | [Skeleton Mage](https://darkanddarker.wiki.spellsandguns.com/Skeleton_Mage) | community_snapshot | HF132 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_zombie | [Zombie](https://darkanddarker.wiki.spellsandguns.com/Zombie) | community_snapshot | HF132 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_mummy | [Mummy](https://darkanddarker.wiki.spellsandguns.com/Mummy) | community_snapshot | HF132 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_spider_mummy | [Spider Mummy](https://darkanddarker.wiki.spellsandguns.com/Spider_Mummy) | community_snapshot | HF132 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_death_skull | [Death Skull](https://darkanddarker.wiki.spellsandguns.com/Death_Skull) | community_snapshot | HF128 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_goblin_warrior | [Goblin Warrior](https://darkanddarker.wiki.spellsandguns.com/Goblin_Warrior) | community_snapshot | HF130 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_goblin_archer | [Goblin Archer](https://darkanddarker.wiki.spellsandguns.com/Goblin_Archer) | community_snapshot | HF130 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_skeleton_champion | [Skeleton Champion](https://darkanddarker.wiki.spellsandguns.com/Skeleton_Champion) | community_snapshot | HF130 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_wraith | [Wraith](https://darkanddarker.wiki.spellsandguns.com/Wraith) | community_snapshot | HF129 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_cave_troll | [Cave Troll](https://darkanddarker.wiki.spellsandguns.com/Cave_Troll) | community_snapshot | HF132 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. |
| monster_cyclops | [Cyclops](https://darkanddarker.wiki.spellsandguns.com/Cyclops) | community_snapshot | HF132 | web_page | 자동 수치는 선언 패치 보존. Guide는 수동 관찰 설명이며 내부 AI 구현 근거로 확대하지 않음. WIP 표시 존재. |
