# Settlers 7 — 원작 데이터 재구축 v23

**공개 자료 복원이며 원본 게임 데이터 추출본·완성 게임이 아닙니다.**

## 먼저 볼 파일
- `v23/report.html`: 검색·연구판 관측도·출처별 연구비 검산 (별도 서버 불필요).
- `Settlers7_Original_Data_v23.xlsx`: 60개 시트. 통합 데이터58 + 요약·검산2.
- `v23/docs/01_Evidence_And_Scope.md`: 근거 수준과 이번 작업의 범위.
- `v23/data/reference_master.json`: 통합58표1,052행.
- `v23/data/reconstruction_delta.json`: 신규16표182행.

## 이번 추가
생산 수량 후보27건/입력35건, 전투 표시 수치 후보7건, 연구판 화면19슬롯/부분 연결선25건, 출처별 연구비 입력과 계산 감사, 충돌·정정8건. 후보 수치를 기존 원작 참고 필드에 자동 덮어쓰지 않았습니다. 생산시간28종은 여전히 미실측입니다.

연구 예제는 해당 글의 모집비로 다시 계산하면 37→23이 아니라34→23, 11개 절감입니다. 수련자 식량은 다른 문헌에서1개, 해당 글에서는2개이므로 프로필을 분리했습니다. v22 문헌 프로필의 동일 인원 벡터는29→20입니다.

## 실행
```bash
python v23/tools/run_tests.py
python v23/tools/restoration.py validate
python v23/tools/restoration.py research-budget --profile steam_2013_cleric_report --novices 5 --brothers 2 --fathers 1
```

핵심 도구는 Python 표준 라이브러리만 사용합니다. 선택 브라우저 검사에는 Playwright와 Chromium이 필요합니다.

## 보존 및 한계
`baseline_v22/`에 이전 ZIP의296개 파일을 바이트 그대로 보존합니다. 기존 웹 게임은 수정하지 않았습니다. 신규 도구 테스트53개와 HTML검사18개는 원작 실행 검증이 아닙니다. 엑셀은 생성·계산·렌더링을 확인했으며 데스크톱 Excel을 실행하지 않았습니다.

원본 이미지·문헌 전문·게임 에셋·폰트를 재배포하지 않습니다. 신규 연구판은 이미지를 보고 만든 별도 관측도이며 실제 기술 이름·판본·선행 AND/OR 규칙이 확정되지 않았습니다. runtime export는 차단됩니다.
