#!/usr/bin/env python3
import json
import sys
import unittest
from pathlib import Path
root=Path(__file__).resolve().parents[1]
class Result(unittest.TextTestResult):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);self.entries=[]
 def addSuccess(self,test):super().addSuccess(test);self.entries.append({'test':test.id(),'status':'passed'})
 def addFailure(self,test,err):super().addFailure(test,err);self.entries.append({'test':test.id(),'status':'failed'})
 def addError(self,test,err):super().addError(test,err);self.entries.append({'test':test.id(),'status':'error'})
suite=unittest.defaultTestLoader.discover(str(root/'tests'),pattern='test_*.py')
result=unittest.TextTestRunner(verbosity=1,resultclass=Result).run(suite)
report={'tests_run':result.testsRun,'passed':sum(x['status']=='passed' for x in result.entries),'failures':len(result.failures),'errors':len(result.errors),
 'scope':'Reference/data validation and synthetic tool tests. Not original game execution.','tests':result.entries}
(root/'reports').mkdir(exist_ok=True)
(root/'reports/test_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
raise SystemExit(0 if result.wasSuccessful() else 1)
