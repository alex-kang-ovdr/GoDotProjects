# 실제 측정 수집·검산 절차

## 상태
이번 산출물의 actual_measurements.json은 빈 배열이고 actual_measurements.csv는 헤더만 있다. 실제 원작 실행을 한 것처럼 보이는 예제 관측은 채우지 않았다. 자동 테스트의 합성 입력은 임시 디렉터리에 생성하며 SYNTHETIC TEST FIXTURE라고 표시한다.

## 유효한 생산 주기 기록
`processing_cycle`의 시작과 완료를 기록하고 `work_only=true`를 명시한다. 운반자 도착 간격, 창고 입고 간격, 애니메이션 길이를 작업장 생산 주기로 간주하지 않는다. 입력 원료 대기·출고 대기와 분리해야 한다.

필수: measurement_id, game_build, edition, subject_id, food_mode, technology_ids, work_event, work_only, speed_constant, modifiers_constant, game_speed, start_s, end_s, time_basis, evidence_file, evidence_sha256.

`time_basis=wall_seconds`이면 시뮬레이션 경과는 (end_s-start_s)×game_speed다. `simulation_seconds`이면 이미 게임 시간으로 측정했으므로 배속을 다시 곱하지 않는다. 구간 도중 속도가 바뀌거나 효과가 달라졌으면 이 간단한 도구는 계산을 거부한다.

## 증거 파일 검사
--evidence-root 내 상대 경로만 허용한다. 상위 경로 탈출과 해시 불일치를 거부한다. 파일이 존재하고 SHA-256이 일치한다는 것은 기록 무결성을 뜻한다. 영상이 진짜 해당 게임인지, 측정 경계가 맞는지는 검토자가 별도로 확인해야 한다.

## 합산
동일 빌드·판본·대상·식량·기술 조건에서 3건 이상을 입력한다. ID 중복과 혼합 빌드를 거부한다. 평균·중앙값·최솟값·최댓값을 계산하지만 원작 정본으로 자동 승격하지 않는다. 3건은 형식 검산의 최소값이지 충분한 정확도를 보증하는 표본 수가 아니다.

```bash
python v23/tools/restoration.py cycles --input measurements.json --evidence-root ./evidence
```

입력은 JSON 배열이다. measurement_record.schema.json은 필드 목록 참고용이며 도구 자체 검사가 실제 수용 기준이다. CSV는 수기 기록 서식이다. JSON 변환 없이 바로 CLI에 전달하는 기능은 제공하지 않는다.

## 우선 검증 항목
생산 시간 28종, 전투 7개 표시 수치의 실제 의미, 연구 슬롯별 이름 대응, 수련자 식량1/2, 수사15/20, Charge Attack 역전 여부를 우선 검증한다. 원본 설치 파일 목록만으로 임의의 데이터 포맷을 해석했다고 주장하지 않는다.
