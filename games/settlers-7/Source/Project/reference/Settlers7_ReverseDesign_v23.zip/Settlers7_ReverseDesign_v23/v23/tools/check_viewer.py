"""Optional: Playwright + Chromium required. This tests the viewer, not the game."""
from pathlib import Path
import json
import os
import shutil
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
checks=[]
def check(name,condition):
 checks.append({'name':name,'passed':bool(condition)})
 if not condition:raise AssertionError(name)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium'),args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 # Reading file bytes avoids file:// navigation policies. The delivery is still self-contained HTML.
 page.set_content((root/'report.html').read_text(),wait_until='load')
 check('viewer_loaded',page.evaluate('window.__v23Ready===true'))
 check('new_table_count',page.locator('#tableSelect option').count()==16)
 check('default_recipe_count',page.locator('#dataTable tbody tr').count()==27)
 page.locator('#search').fill('papermill')
 check('search_filters',page.locator('#dataTable tbody tr').count()==1)
 page.locator('#dataTable tbody tr').click()
 check('row_details', 'JP_BUILD' in page.locator('#rowJson').inner_text())
 with page.expect_download() as dl:page.locator('#download').click()
 download=dl.value
 check('csv_download',download.suggested_filename=='recipe_quantity_claims_v23.csv')
 page.locator('#search').fill('')
 page.locator('#scopeSelect').select_option('all')
 check('all_table_count',page.locator('#tableSelect option').count()==58)
 page.locator('[data-tab="board"]').click()
 check('board_nodes',page.locator('#boardSvg .node').count()==19)
 check('board_segments',page.locator('#boardSvg line').count()==25)
 page.locator('[data-node="n12"]').click()
 check('uncertain_digit_preserved','"displayed_cleric_right": null' in page.locator('#nodeJson').inner_text())
 page.locator('[data-tab="budget"]').click()
 check('steam_before_total',page.locator('[data-total="steam_2013_cleric_report"]').inner_text()=='34개')
 check('v22_before_total',page.locator('[data-total="v22_guide_cleric_reference"]').inner_text()=='29개')
 page.locator('#afterPreset').click()
 check('steam_after_total',page.locator('[data-total="steam_2013_cleric_report"]').inner_text()=='23개')
 check('v22_after_total',page.locator('[data-total="v22_guide_cleric_reference"]').inner_text()=='20개')
 page.locator('#novices').fill('-1')
 check('negative_input_rejected',bool(page.locator('#budgetError').inner_text()))
 page.locator('#beforePreset').click()
 page.locator('[data-tab="conflicts"]').click()
 check('conflicts_rendered',page.locator('.conflict').count()==8)
 page.locator('[data-tab="data"]').click()
 page.set_viewport_size({'width':412,'height':891})
 check('mobile_no_page_overflow',page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 1'))
 page.set_viewport_size({'width':1440,'height':1000})
 page.locator('[data-tab="board"]').click()
 page.screenshot(path=str(root/'reports/viewer_board.png'),full_page=True)
 page.locator('[data-tab="budget"]').click()
 page.screenshot(path=str(root/'reports/viewer_budget.png'),full_page=True)
 check('no_javascript_exceptions',not errors)
 browser.close()
report={'checks':checks,'passed':sum(c['passed'] for c in checks),'errors':errors,'method':'Chromium page.set_content from delivered HTML; file:// navigation not tested','original_game_tested':False}
(root/'reports/viewer_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
