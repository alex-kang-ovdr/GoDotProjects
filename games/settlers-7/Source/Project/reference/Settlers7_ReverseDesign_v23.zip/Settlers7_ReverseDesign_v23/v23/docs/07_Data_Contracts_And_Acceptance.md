# 데이터 계약·내보내기·검증

## 파일
- reference_master.json: v22 42표를 보존하고 새 16표를 덧붙인 통합본.
- reconstruction_delta.json: 이번 신규표만 포함.
- 각 CSV: UTF-8 BOM. null은 문자열 `null`로 표기하여 0과 구분.
- claim_trace.jsonl: 신규 182행 각각의 출처·근거 상태 연결. 182개 독립 실측이라는 뜻이 아니다.
- Excel: 통합 데이터 58시트 + 요약·연구비 검산 2시트, 총60시트.
- report.html: 내장 JSON을 사용하며 서버·원격 API 없이 검색·관측도·검산 가능.

## 참조 무결성
작업장→기존 레시피, 입력→후보 주장, 자원→기존 자원/식량 그룹, 유닛→기존 유닛, 화면 선분→관측 노드를 검증한다. 출처와 프로필은 ID로 연결한다. 기존 42개 표의 행을 변경하지 않았는지도 테스트한다.

## 실행용 내보내기 차단
`export --mode runtime`은 종료코드2와 이유를 반환하며 파일을 생성하지 않는다. `reference`는 not_runtime_data=true로만 내보낸다. 후보 조회 옵션을 켰다고 실행 데이터가 되는 것이 아니다.

## 실제 수행한 검증
Python53개: 예산 산술, 후보 조회 동의, 음수·실수·bool 인원 거부, 출처 참조, 이름/주기 추정 차단, 원문 표 보존, 빈 실측 파일, 증거 해시·경로, 시계 단위, 조건 혼합 거부 등.
HTML18개: 로드, 16/58표 전환, 검색·상세, CSV 생성, 19노드·25선, 모호 숫자, 두 프로필 검산, 음수 입력, 충돌8건, 모바일 가로 넘침, JS 예외 없음.
Excel: artifact_tool 계산 결과와 수식 오류 검색 및 미리보기 점검. 데스크톱 Excel을 직접 구동한 검사는 아님.

HTML 검사는 Chromium에 파일 내용을 로드하여 수행했다. file:// 직접 탐색 검증은 아니며 원작 게임 브라우저 플레이 검증도 아니다. JSON/CSV·기준 파일 SHA-256·ZIP 무결성 검사 결과는 reports의 배포 감사 파일로 확인한다.

## 재실행
```bash
python v23/tools/run_tests.py
python v23/tools/restoration.py validate
python v23/tools/restoration.py research-budget --profile steam_2013_cleric_report --novices 5 --brothers 2 --fathers 1
python v23/tools/restoration.py recipe --workshop papermill --allow-candidate
```

Python 핵심 도구는 표준 라이브러리만 사용한다. 선택적인 check_viewer.py는 Playwright와 Chromium이 필요하다. 시스템 Chromium을 찾거나 CHROMIUM_PATH를 지정할 수 있다.
