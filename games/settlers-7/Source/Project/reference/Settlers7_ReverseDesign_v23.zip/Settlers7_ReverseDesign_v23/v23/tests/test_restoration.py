"""Synthetic tests validate the tools, NOT original-game behavior."""
import copy
import csv
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from restoration import *

class RestorationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.d=load_data()
 def budget(self,p='steam_2013_cleric_report',n=5,b=2,f=1): return research_budget(self.d,p,dict(novice=n,brother=b,father=f))
 def test_schema_references(self): self.assertEqual(validate(self.d),[])
 def test_source_profile_before_total(self): self.assertEqual(self.budget()['unweighted_goods_total'],34)
 def test_source_profile_before_goods(self): self.assertEqual(self.budget()['goods'],dict(beer=12,plain_food=14,fancy_food=2,book=5,jewelry=1))
 def test_source_profile_after_total(self): self.assertEqual(self.budget(n=3,b=1)['unweighted_goods_total'],23)
 def test_source_profile_savings(self): self.assertEqual(self.budget()['unweighted_goods_total']-self.budget(n=3,b=1)['unweighted_goods_total'],11)
 def test_guide_profile_before(self): self.assertEqual(self.budget('v22_guide_cleric_reference')['unweighted_goods_total'],29)
 def test_guide_profile_after(self): self.assertEqual(self.budget('v22_guide_cleric_reference',3,1,1)['unweighted_goods_total'],20)
 def test_profiles_not_equal(self): self.assertNotEqual(self.budget()['goods'],self.budget('v22_guide_cleric_reference')['goods'])
 def test_zero_counts(self): self.assertEqual(self.budget(n=0,b=0,f=0)['unweighted_goods_total'],0)
 def test_negative_count_rejected(self):
  with self.assertRaises(ValueError): self.budget(n=-1)
 def test_float_count_rejected(self):
  with self.assertRaises(ValueError): self.budget(n=1.2)
 def test_bool_count_rejected(self):
  with self.assertRaises(ValueError): self.budget(n=True)
 def test_absent_rank_rejected(self):
  with self.assertRaises(ValueError): research_budget(self.d,'steam_2013_cleric_report',{'novice':1})
 def test_unknown_profile_rejected(self):
  with self.assertRaises(ValueError): self.budget('latest')
 def test_excessive_count_rejected(self):
  with self.assertRaises(ValueError): self.budget(n=1000001)
 def test_no_rounding_inferred(self): self.assertFalse(self.budget()['dictionary_rounding_inferred'])
 def test_recipe_candidate_requires_optin(self):
  with self.assertRaises(ValueError): recipe_reference(self.d,'papermill')
 def test_candidate_recipe_not_executable(self): self.assertFalse(recipe_reference(self.d,'papermill',True)['executable'])
 def test_papermill_water_qty(self):
  r=recipe_reference(self.d,'papermill',True);self.assertEqual(next(x for x in r['inputs'] if x['resource_id']=='water')['reported_qty'],2)
 def test_piggery_two_materials(self):
  r=recipe_reference(self.d,'piggery',True);self.assertEqual({x['resource_id']:x['reported_qty'] for x in r['inputs']},{'grain':2,'water':2})
 def test_ambiguous_coking_kept(self): self.assertIn('ambiguous_material_mapping',recipe_reference(self.d,'coking_plant',True)['blocking_reasons'])
 def test_ambiguous_blacksmith_kept(self): self.assertIn('ambiguous_material_mapping',recipe_reference(self.d,'blacksmith',True)['blocking_reasons'])
 def test_environment_not_free_resource(self): self.assertEqual(recipe_reference(self.d,'coal_miner',True)['claim']['environment_requirement'],'coal_deposit')
 def test_cycle_fields_still_null(self): self.assertTrue(all(r['cycle_seconds'] is None for r in self.d['tables']['recipes']))
 def test_combat_not_dps(self): self.assertTrue(all(r['dps'] is None and r['per_hit_damage'] is None for r in self.d['tables']['combat_value_claims']))
 def test_board_names_not_invented(self): self.assertTrue(all(r['technology_id'] is None for r in self.d['tables']['research_board_observations']))
 def test_ambiguous_board_digit(self):
  n=next(r for r in self.d['tables']['research_board_observations'] if r['id']=='n12');self.assertIsNone(n['displayed_cleric_right']);self.assertEqual(n['right_digit_candidates'],[0,9])
 def test_center_star_reading(self):
  n=next(r for r in self.d['tables']['research_board_observations'] if r['id']=='n19');self.assertEqual([n[x] for x in ['displayed_cleric_left','displayed_cleric_middle','displayed_cleric_right']],[9,7,5])
 def test_board_edges_not_prerequisites(self): self.assertTrue(all(not r['directed'] and r['prerequisite_logic'] is None for r in self.d['tables']['research_board_segments']))
 def test_named_route_not_graph(self): self.assertFalse(self.d['tables']['reported_research_routes'][0]['is_prerequisite_graph'])
 def test_runtime_export_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'out.json'
   with self.assertRaises(ValueError): export_reference(self.d,'runtime',p)
   self.assertFalse(p.exists())
 def test_reference_export_label(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'out.json';export_reference(self.d,'reference',p)
   self.assertTrue(json.loads(p.read_text())['not_runtime_data'])
 def test_validator_detects_duplicate(self):
  d=copy.deepcopy(self.d);d['tables']['combat_value_claims'].append(d['tables']['combat_value_claims'][0]);self.assertTrue(validate(d))
 def test_validator_detects_missing_source(self):
  d=copy.deepcopy(self.d);d['tables']['combat_value_claims'][0]['source_id']='missing';self.assertTrue(validate(d))
 def test_validator_detects_missing_endpoint(self):
  d=copy.deepcopy(self.d);d['tables']['research_board_segments'][0]['endpoint_b']='missing';self.assertTrue(validate(d))
 def test_v22_canonical_tables_preserved(self):
  p=Path(__file__).resolve().parents[2]/'baseline_v22/v22/data/original_master.json'
  old=json.loads(p.read_text())
  for k,rows in old['tables'].items(): self.assertEqual(rows,self.d['tables'][k],k)
 def test_actual_measurements_empty(self):
  rows=list(csv.DictReader((DATA/'actual_measurements.csv').open(encoding='utf-8-sig')));self.assertEqual(rows,[])

class MeasurementTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  content=b'SYNTHETIC TEST FIXTURE; NOT GAME EVIDENCE';(self.root/'fixture.txt').write_bytes(content)
  self.row=dict(measurement_id='synthetic_01',game_build='synthetic-test-build',edition='synthetic',subject_id='test_papermill',food_mode='none',technology_ids=[],
   work_event='processing_cycle',work_only=True,speed_constant=True,modifiers_constant=True,game_speed=1.5,start_s=10,end_s=20,time_basis='wall_seconds',
   evidence_file='fixture.txt',evidence_sha256=hashlib.sha256(content).hexdigest())
 def tearDown(self):self.tmp.cleanup()
 def test_wall_time_conversion(self):self.assertEqual(validate_measurement(self.row,self.root)['observed_simulation_seconds'],15)
 def test_sim_time_not_double_scaled(self):
  self.row['time_basis']='simulation_seconds';self.assertEqual(validate_measurement(self.row,self.root)['observed_simulation_seconds'],10)
 def test_missing_build_rejected(self):
  self.row['game_build']=''
  with self.assertRaises(ValueError): validate_measurement(self.row,self.root)
 def test_delivery_not_production(self):
  self.row['work_event']='delivery'
  with self.assertRaises(ValueError): validate_measurement(self.row,self.root)
 def test_bad_clock_rejected(self):
  self.row['time_basis']='unknown'
  with self.assertRaises(ValueError): validate_measurement(self.row,self.root)
 def test_variable_speed_rejected(self):
  self.row['speed_constant']=False
  with self.assertRaises(ValueError): validate_measurement(self.row,self.root)
 def test_changed_buff_rejected(self):
  self.row['modifiers_constant']=False
  with self.assertRaises(ValueError): validate_measurement(self.row,self.root)
 def test_bad_hash_rejected(self):
  self.row['evidence_sha256']='0'*64
  with self.assertRaises(ValueError): validate_measurement(self.row,self.root)
 def test_path_escape_rejected(self):
  self.row['evidence_file']='../outside.txt'
  with self.assertRaises(ValueError): validate_measurement(self.row,self.root)
 def test_negative_duration_rejected(self):
  self.row['end_s']=9
  with self.assertRaises(ValueError): validate_measurement(self.row,self.root)
 def test_nonfinite_rejected(self):
  self.row['game_speed']=float('nan')
  with self.assertRaises(ValueError): validate_measurement(self.row,self.root)
 def test_hash_does_not_authenticate_game(self):self.assertFalse(validate_measurement(self.row,self.root)['game_content_authenticity_verified'])
 def samples(self):return [dict(self.row,measurement_id=f'synthetic_{i}') for i in range(3)]
 def test_repeat_summary(self):
  r=summarize_cycles(self.samples(),self.root);self.assertEqual(r['mean_observed_seconds'],15);self.assertFalse(r['canonical_promotion'])
 def test_minimum_repeat_count(self):
  with self.assertRaises(ValueError): summarize_cycles(self.samples()[:2],self.root)
 def test_mixed_builds_rejected(self):
  r=self.samples();r[2]['game_build']='other-build'
  with self.assertRaises(ValueError): summarize_cycles(r,self.root)
 def test_duplicate_measurement_ids(self):
  r=self.samples();r[2]['measurement_id']=r[0]['measurement_id']
  with self.assertRaises(ValueError): summarize_cycles(r,self.root)

if __name__=='__main__':unittest.main()
