#!/usr/bin/env python3
"""Settlers 7 v23: provenance-aware reference tools. No game runtime data extraction.

All economy / combat candidates remain separate from canonical v22 fields.
Only Python standard library is required.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path
from typing import Any

HERE=Path(__file__).resolve().parent
DATA=HERE.parent/'data'
BUDGET_RESOURCES=('beer','plain_food','fancy_food','book','jewelry')
CLERICS=('novice','brother','father')

def load_data(path: Path | None=None)->dict[str,Any]:
    return json.loads((path or DATA/'reference_master.json').read_text(encoding='utf-8'))

def whole_number(value: Any, name: str)->int:
    if isinstance(value,bool) or not isinstance(value,int) or value<0 or value>1_000_000:
        raise ValueError(f'{name}: 0..1,000,000 사이 정수가 필요합니다.')
    return value

def research_budget(data:dict[str,Any],profile:str,counts:dict[str,int])->dict[str,Any]:
    if set(counts)!=set(CLERICS):
        raise ValueError('novice, brother, father 세 수량을 모두 명시해야 합니다.')
    counts={k:whole_number(counts[k],k) for k in CLERICS}
    rows=[r for r in data['tables']['research_budget_inputs'] if r['profile_id']==profile]
    if not rows:
        raise ValueError('알 수 없는 비용 프로필. 출처를 자동 혼합하지 않습니다.')
    goods={r:0 for r in BUDGET_RESOURCES}
    for row in rows:
        goods[row['requirement_id']]+=row['qty']*counts[row['unit_id']]
    return {'profile_id':profile,'counts':counts,'goods':goods,
            'unweighted_goods_total':sum(goods.values()),'headcount':sum(counts.values()),
            'population_cost_verified':False,'dictionary_rounding_inferred':False,
            'notes':'상품 단순 개수 합계이며 경제 가치·건설비·연구 선행비용을 나타내지 않습니다.'}

def recipe_reference(data:dict[str,Any],workshop:str,allow_candidate:bool=False)->dict[str,Any]:
    candidates=[r for r in data['tables']['recipe_quantity_claims'] if r['workshop_id']==workshop]
    if not candidates: raise ValueError('수량 후보가 없는 작업장입니다.')
    r=candidates[0]
    if not allow_candidate: raise ValueError('이 수량은 원작 확정값이 아닙니다. 후보 조회에는 --allow-candidate가 필요합니다.')
    ins=[x for x in data['tables']['recipe_input_claims'] if x['claim_id']==r['id']]
    return {'claim':r,'inputs':ins,'executable':False,
        'blocking_reasons':['cycle_seconds_unknown','runtime_unverified']+(['ambiguous_material_mapping'] if any(x['resource_id'] is None for x in ins) else [])}

def export_reference(data:dict[str,Any],mode:str,path:Path)->None:
    if mode!='reference':
        raise ValueError('원작 실행용 export 차단: 생산시간, 전투 의미, 연구 이름 연결 및 판본 검증 미완료.')
    out={'export_mode':'reference_only','not_runtime_data':True,'data':data}
    path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def finite_positive(value:Any,name:str)->float:
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:
        raise ValueError(f'{name}: 유한한 양수가 필요합니다.')
    return float(value)

def validate_measurement(row:dict[str,Any],evidence_root:Path)->dict[str,Any]:
    for key in ('measurement_id','game_build','edition','subject_id','food_mode','evidence_file','evidence_sha256'):
        if not isinstance(row.get(key),str) or not row[key].strip(): raise ValueError(f'{key}: 누락')
    if row.get('work_event')!='processing_cycle' or row.get('work_only') is not True:
        raise ValueError('가공 시작/완료 관측만 허용합니다. 출고/배송 시간을 생산시간으로 사용하지 않습니다.')
    if row.get('speed_constant') is not True or row.get('modifiers_constant') is not True:
        raise ValueError('속도 및 효과가 구간 내 일정해야 합니다.')
    technologies=row.get('technology_ids')
    if not isinstance(technologies,list) or any(not isinstance(x,str) for x in technologies): raise ValueError('technology_ids: 명시 배열 필요')
    speed=finite_positive(row.get('game_speed'),'game_speed')
    start=row.get('start_s');end=row.get('end_s')
    for name,value in [('start_s',start),('end_s',end)]:
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0: raise ValueError(f'{name}: 유한한 0 이상 시각 필요')
    if end<=start: raise ValueError('완료 시각이 시작 시각보다 커야 합니다.')
    basis=row.get('time_basis')
    if basis not in ('wall_seconds','simulation_seconds'): raise ValueError('time_basis 명시 필요')
    sha=row['evidence_sha256']
    if len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha.lower()): raise ValueError('SHA-256 형식 오류')
    root=evidence_root.resolve(); path=(root/row['evidence_file']).resolve()
    if root not in path.parents: raise ValueError('증거 경로가 evidence-root 밖에 있습니다.')
    if not path.is_file(): raise ValueError('증거 파일이 없습니다.')
    if hashlib.sha256(path.read_bytes()).hexdigest()!=sha.lower(): raise ValueError('증거 SHA-256 불일치')
    out=dict(row);out['observed_simulation_seconds']=(end-start)*(speed if basis=='wall_seconds' else 1)
    out['evidence_integrity_checked']=True
    out['game_content_authenticity_verified']=False
    return out

def summarize_cycles(rows:list[dict[str,Any]],evidence_root:Path)->dict[str,Any]:
    if len(rows)<3: raise ValueError('반복 관측 최소 3건이 필요합니다.')
    samples=[validate_measurement(r,evidence_root) for r in rows]
    # Never silently pool different builds, bonuses, or subjects.
    contexts={json.dumps([r['game_build'],r['edition'],r['subject_id'],r['food_mode'],sorted(r['technology_ids'])],ensure_ascii=False) for r in samples}
    if len(contexts)!=1: raise ValueError('판본·대상·식량·기술이 다른 관측을 함께 평균내지 않습니다.')
    if len({r['measurement_id'] for r in samples})!=len(samples): raise ValueError('측정 ID 중복')
    values=[r['observed_simulation_seconds'] for r in samples]
    return {'sample_count':len(values),'mean_observed_seconds':statistics.mean(values),
        'median_observed_seconds':statistics.median(values),'min_observed_seconds':min(values),
        'max_observed_seconds':max(values),'context':json.loads(next(iter(contexts))),
        'canonical_promotion':False,'notes':'증거 파일 무결성과 입력 조건만 검사합니다. 영상 진위·측정 경계 정확성은 검토자가 확인해야 합니다.'}

def validate(data:dict[str,Any])->list[str]:
    errors=[];tables=data.get('tables',{})
    for name,rows in tables.items():
        ids=[r.get('id') for r in rows]
        if len(ids)!=len(set(ids)): errors.append(f'{name}: 중복 ID')
    sources={r['id'] for n in ('sources','v23_sources') for r in tables.get(n,[])}
    profiles={r['id'] for n in ('edition_profiles','v23_profiles') for r in tables.get(n,[])}
    resources={r['id'] for r in tables['resources']}|{'plain_food','fancy_food'}
    workshops={r['id'] for r in tables['workshops']}
    recipes={r['id'] for r in tables['recipes']}
    units={r['id'] for r in tables['units']}
    techs={r['id'] for r in tables['technologies']}
    delta_names=json.loads((DATA/'reconstruction_delta.json').read_text())['tables'].keys()
    for name in delta_names:
      for r in tables[name]:
        if r.get('source_id') and r['source_id'] not in sources: errors.append(f'{name}/{r["id"]}: 출처 없음')
        if r.get('profile_id') and r['profile_id'] not in profiles: errors.append(f'{name}/{r["id"]}: 프로필 없음')
        if r.get('runtime_verified') is True: errors.append(f'{name}/{r["id"]}: 이번 작업에서 runtime_verified=true 불가')
    for r in tables['recipe_quantity_claims']:
        if r['workshop_id'] not in workshops or r['recipe_id'] not in recipes: errors.append(f'{r["id"]}: 작업장/레시피 참조 오류')
        if r['output_resource_id'] not in resources: errors.append(f'{r["id"]}: 산출물 참조 오류')
        if r['cycle_seconds'] is not None or r['executable']: errors.append(f'{r["id"]}: 미확인 주기 실행 금지')
    claims={r['id'] for r in tables['recipe_quantity_claims']}
    for r in tables['recipe_input_claims']:
        if r['claim_id'] not in claims: errors.append(f'{r["id"]}: 부모 수량 주장 없음')
        if r['resource_id'] is not None and r['resource_id'] not in resources: errors.append(f'{r["id"]}: 자원 참조 오류')
        if r['mapping_state']=='ambiguous' and r['resource_id'] is not None: errors.append(f'{r["id"]}: 모호 자원 강제 매핑')
    for r in tables['combat_value_claims']:
        if r['unit_id'] not in units: errors.append(f'{r["id"]}: 유닛 참조 오류')
        if r['dps'] is not None or r['per_hit_damage'] is not None: errors.append(f'{r["id"]}: 전투 의미 과도한 확정')
    nodes={r['id'] for r in tables['research_board_observations']}
    for r in tables['research_board_observations']:
        if r['technology_id'] is not None: errors.append(f'{r["id"]}: 화면 이름 미확정')
        if not (0<=r['x_normalized']<=1 and 0<=r['y_normalized']<=1): errors.append(f'{r["id"]}: 좌표 범위 오류')
    for r in tables['research_board_segments']:
        if r['endpoint_a'] not in nodes or r['endpoint_b'] not in nodes: errors.append(f'{r["id"]}: 연결 대상 없음')
        if r['directed'] or r['prerequisite_logic'] is not None: errors.append(f'{r["id"]}: 선행 규칙 추정 금지')
    for r in tables['reported_research_routes']:
        if any(t not in techs for t in r['ordered_technology_ids']): errors.append(f'{r["id"]}: 기술 참조 오류')
    for r in tables['research_budget_cases']:
        result=research_budget(data,r['profile_id'],{u:r[u] for u in CLERICS})
        if result['goods']!=r['goods'] or result['unweighted_goods_total']!=r['unweighted_goods_total']: errors.append(f'{r["id"]}: 예산 검산 불일치')
    if data['meta'].get('runtime_export_allowed') is not False: errors.append('원작 실행 export 차단 설정 오류')
    if any(r['cycle_seconds'] is not None for r in tables['recipes']): errors.append('원작 미실측 생산시간 필드 변경')
    return errors

def main(argv:list[str]|None=None)->int:
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('validate')
    b=sub.add_parser('research-budget');b.add_argument('--profile',required=True);b.add_argument('--novices',type=int,required=True);b.add_argument('--brothers',type=int,required=True);b.add_argument('--fathers',type=int,required=True)
    p=sub.add_parser('recipe');p.add_argument('--workshop',required=True);p.add_argument('--allow-candidate',action='store_true')
    ex=sub.add_parser('export');ex.add_argument('--mode',choices=['reference','runtime'],required=True);ex.add_argument('--output',type=Path,required=True)
    m=sub.add_parser('cycles');m.add_argument('--input',type=Path,required=True);m.add_argument('--evidence-root',type=Path,required=True)
    args=parser.parse_args(argv)
    try:
      data=load_data()
      if args.command=='validate':
        errors=validate(data);result={'passed':not errors,'errors':errors,'tables':len(data['tables'])}
        print(json.dumps(result,ensure_ascii=False,indent=2));return 1 if errors else 0
      if args.command=='research-budget': result=research_budget(data,args.profile,dict(novice=args.novices,brother=args.brothers,father=args.fathers))
      elif args.command=='recipe': result=recipe_reference(data,args.workshop,args.allow_candidate)
      elif args.command=='export': export_reference(data,args.mode,args.output);result={'written':str(args.output),'mode':'reference_only'}
      else: result=summarize_cycles(json.loads(args.input.read_text(encoding='utf-8')),args.evidence_root)
      print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (ValueError,OSError,KeyError,json.JSONDecodeError) as exc:
      print(json.dumps({'error':str(exc)},ensure_ascii=False),file=sys.stderr);return 2

if __name__=='__main__': raise SystemExit(main())
