# 04. 군사·교역·성직자·연구·승리 조건

## 분기 건물에서의 모집 비용

| 유닛 | 건물 | 필요 승급 | 물자 비용 | 인구 | 왕복 거래 횟수 |
|---|---|---|---|---|---|
| Pikeman | stronghold | 0 | coin×1, weapon×1 | 1 | 미확인 |
| Musketeer | stronghold | 0 | coin×1, weapon×1, coal×1 | 1 | 미확인 |
| Cavalier | stronghold | 1 | coin×2, weapon×1, fancy_food×1, horse×1 | 1 | 미확인 |
| Cannon | stronghold | 2 | coin×2, weapon×2, wheel×2, coal×1, fancy_food×1 | 2 | 미확인 |
| Standard Bearer | stronghold | 2 | coin×10, wood×1, iron×1 | 1 | 미확인 |
| Novice | church | 0 | beer×1, plain_food×1 | 1 | 미확인 |
| Brother | church | 1 | beer×2, plain_food×2, book×1 | 1 | 미확인 |
| Father | church | 2 | beer×3, fancy_food×2, book×3, jewelry×1 | 1 | 미확인 |
| Hawker | export_office | 0 | garment×1 | 1 | 1 |
| Salesman | export_office | 1 | garment×1, jewelry×1 | 1 | 3 |
| Merchant | export_office | 2 | garment×1, jewelry×1, horse×1, wheel×2 | 1 | 5 |


비용은 건물 표의 분기 건물 훈련 비용이다. 선술집 용병 모집 비용과 혼합하지 않는다. 상인의 1/3/5는 원료 개수가 아니라 왕복당 **거래 횟수**다. 훈련 시간과 전투 기본 능력치는 null이다. [BLD · Prima Guide / buildings](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/game-basics/buildings) / [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) p.34

## 군사 원작 구조

장군은 군대를 지휘하며 일반적으로 최대4명, 이벤트를 통한 별도1명, 군대당 최대35유닛이라는 문헌 상한을 기록했다. 대포의 인구2와 35유닛 편성 슬롯의 관계는 추측하지 않는다. 아군 부문에서 회복하고, 성채 공격에는 원거리 병력이 필요하며 탄약이 소진되면 아군 쪽으로 퇴각해 보급한다. 장군과 기수는 전투에서 군대가 전멸해도 살아서 퇴각한다. 장군을 직접 해산하면 배속 병력을 잃는다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) pp.31–34

전투 재구축에는 개별 생존 병력, 부상 상태, 병종별 근접·원거리, 성채 피해, 탄약·퇴각을 따로 둔다. 총 전력 한 번 비교로 공성·야전을 모두 해결하는 기존 방식은 프로토타입으로만 남긴다. 정확한 HP·피해·사거리·공격 간격·대형 충돌·시야는 추출하지 못했으며, 임의 숫자를 원작 칼럼에 넣지 않았다.

## 18종 기술의 효과

| 기술 | 주요 효과 연산 | 값 | 대상 |
|---|---|---|---|
| Animal Husbandry | production_time_ratio_average | 0.45 | piggery;stable;shepherd |
| Aquaculture | production_time_ratio | 0.44 | fisher |
| Architecture | constructor_speed_multiplier | 2 | constructor |
| Ballistics | ranged_damage_bonus | 0.33 | musketeer;cannon;fortification |
| Charge Attack | melee_damage_bonus | 0.4 | pikeman |
| Dictionary | cleric_cost_reduction | 0.33 | technology_research |
| Exercise | recovery_speed_multiplier | 5 | army |
| Engineering | startup_tool_required | False | worker |
| Forced March | army_speed_multiplier | 2 | army |
| Forestry | production_time_ratio_average | 0.55 | forester;woodcutter;sawmill |
| Geology | production_time_ratio | 0.4 | quarry |
| Hygiene | living_space_add | 2 | residence |
| Ornamentation | prestige_level_add | 2 | player |
| Piecework | production_speed_multiplier_average | 2 | residence;noble_residence |
| Purity Law | tavern_coin_per_beer | 2 | tavern |
| Spyglass | reveal_enemy_info | True | enemy |
| Reinforcement | fortification_damage_tolerance_bonus | 0.5 | fortification |
| Scarecrow | worker_speed_multiplier | 2 | grain_barn;windmill |


기준: [EXP · Prima Guide / expansion-methods](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/game-basics/expansion-methods). 복수 효과는 `technology_effects.csv`의 29개 행으로 분리했다. average라고 적힌 효과를 각 작업장에 동일한 정확한 배율로 확정하지 않는다. 33%라는 표기는 1/3과 동일시하지 않는다. 방어시설이 피해를 50% 더 견디는 것과 받는 피해를 50% 줄이는 것은 다르다. 비용 감소의 정수 반올림과 보너스 결합 순서는 미확인이다.

## 연구판과 교역판은 물리 도로와 다른 그래프다

연구는 이미 확보한 기술 또는 수도원에서 연결된 미연구 노드를 대상으로 한다. 연구 주문 시 성직자 이동과 타이머가 시작되고, 상대는 증가한 비용으로 연구를 가로챌 수 있다. 이전 연구자의 성직자가 반환되고 새 타이머가 시작된다. 완료된 기술은 연구판에서는 다른 플레이어가 얻을 수 없지만 이벤트 보상 경로가 예외가 될 수 있다. 전체 연결 간선·성직자 비용·연구 시간은 아직 null이다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) pp.38–39

교역소는 원정으로 확보하고 연결된 교역판을 따라 다음 거점으로 진행한다. 적 교역소 우회는 비용을 지불하는 별도 규칙이며, 물리 지도에서 적 영토를 통과할 수 있다는 뜻은 아니다. 상인은 물리적으로 적 영토를 통과하지 못한다. 성직자는 일반 규칙상 가능하지만 캠페인 스크립트가 제한하는 경우는 따로 둬야 한다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) pp.34–39; [C05 · A Formidable Adversary](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-1-a-conquest-begins/conquest-walkthrough/a-formidable-adversary)

## 승리 포인트와 판정

| 문헌 명칭 | 유형 | 측정 대상 | 알려진 최소값 |
|---|---|---|---|
| Banker | dynamic | coin_stock | 미확인 |
| Metropolis | dynamic | workers_carriers_constructors | 미확인 |
| Sun King | dynamic | prestige_level | 5 |
| Emperor | dynamic | owned_sector_count | 미확인 |
| Field Marshal | dynamic | military_strength_formula_unknown | 미확인 |
| Fountain of Knowledge | dynamic | technology_count | 3 |
| Most Trading Outposts | dynamic | outpost_count | 미확인 |
| Generalissimo | 미확인 | 미확인 | 미확인 |
| Special Sector | dynamic | specific_sector_ownership | 미확인 |
| Special Trading Outpost | permanent | outpost_acquired | 미확인 |
| Genius | permanent | specific_technology_acquired | 미확인 |
| Abbey | permanent | church_upgrade_objective_details_unknown | 미확인 |
| Event Victory Point | permanent | quest_completed | 미확인 |
| Bishop’s See | permanent | first_player_final_church_upgrade | 미확인 |


14행은 **문헌 명칭 레코드 수**이다. Abbey와 Bishop’s See는 동일 기능일 가능성을 해결하지 못해 병합하지 않았으며, 이를 14종의 독립된 VP라고 세어서는 안 된다. 모든 미션이 모든 VP를 사용하는 것도 아니다. Sun King 최소5명성 레벨과 Fountain of Knowledge 최소3기술은 확인했지만, 다른 항목의 최소 임계값을 추정하지 않았다. Metropolis는 총인구가 아니라 노동자·운반자·건설자를 센다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) pp.24,40–41; [DEV · Developer Tips: From Inside The Studio](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/essentials/developer-tips/from-inside-the-studio) Special Victory Point Details; [C10 · The Father's Revenge](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/the-fathers-revenge)

점수 목표에 도달하면 카운트다운이 시작되고 목표 아래로 떨어지면 새 카운트다운이 필요하다. 임의의 180초를 모든 맵에 적용하지 않는다. 이번 데이터에서 180초는 M09 공략에 명시된 미션 범위 값이다. 동점 정책도 Sun King의 기존 소유자 유지 사례 외에는 확인 전까지 null이다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) p.40; [C06 · Expanding an Empire](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-1-a-conquest-begins/conquest-walkthrough/expanding-an-empire); [C09 · 100 Years of Peace](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/100-years-of-peace)
