# Settlers 7 역기획서 v14

기존 v13 파일을 보존하고 56~63 상세 기획서, 생산 용량 예시 CSV, 원작 조사 레지스트리 CSV, 데이터 계약 JSON을 추가했다.

**중요:** v14는 기획 문서 고도화이며 기존 웹 프로토타입 코드는 수정하지 않았다. 새 수치와 규칙은 원작 고증값이 아닌 설계 예시다.

## 신규 문서
- 56_Economy_Production_Capacity.md
- 57_Building_Placement_and_Upgrades.md
- 58_Logistics_Dispatch_and_MultiWarehouse.md
- 59_Strategy_VP_and_Counterplay.md
- 60_AI_Economy_Strategy_Planner.md
- 61_Campaign_Scenario_Data.md
- 62_Balance_Experiment_and_Telemetry.md
- 63_Original_Research_Protocol.md
