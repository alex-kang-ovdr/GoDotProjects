# 02. 원작 건설·생산 체계 재구축

## 본관과 부속 작업장을 분리한다

| 본관 | 편집용 한국어 | 초기 건설비 | 생활 공간 | 연결 가능한 작업장 |
|---|---|---|---|---|
| Residence | 주택 | plank×2, stone×1 | 4 | Papermill; Weaving Mill; Brewery; Bakery; Wheelwright; Toolmaker |
| Noble Residence | 귀족 주택 | plank×3, stone×2 | 5 | Bookbindery; Mint; Blacksmith; Goldsmith; Tailor; Butcher’s |
| Farm | 농장 | plank×3 | 1 | Grain Barn; Piggery; Shepherd; Stable; Windmill |
| Lodge | 산림 오두막 | plank×3 | 1 | Fisher; Hunter; Sawmill; Woodcutter; Forester |
| Mountain Shelter | 산악 오두막 | 미확인 | 미확인 | Coal Miner; Iron Miner; Gold Miner; Iron Smelter; Quarry; Coking Plant |
| Storehouse | 창고 | plank×1 | 1 | 서비스/분기 건물 |
| Stronghold | 군사 거점 | plank×10, stone×10 | 미확인 | 서비스/분기 건물 |
| Church | 교회 | plank×10, stone×10 | 미확인 | 서비스/분기 건물 |
| Export Office | 무역 사무소 | plank×10, stone×10 | 미확인 | 서비스/분기 건물 |
| Constructor | 건설 사무소 | plank×1, stone×1 | 미확인 | 서비스/분기 건물 |
| Well | 우물 | stone×4 | 미확인 | 서비스/분기 건물 |


기준: [BLD · Prima Guide / buildings](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/game-basics/buildings). 산악 오두막 비용과 생활 공간은 확보한 건물 표에서 누락되어 null이다. 서비스 건물의 생활 공간이 null이라고 0인 것은 아니다. 전체 본관 최대 슬롯을 모두 실측한 상태도 아니다. `observed_workyards_per_base=3`은 세 작업장을 배치한 문헌 사례이고, `workyard_slot_max=3`과는 구별한다.

주택은 4→8→12, 귀족 주택은 5→10→15 생활 공간으로 증분 계산했다. 기본·1차·2차 승급비는 별도 행으로 보관한다. 신규 작업장이 완공되어도 거주 여유, 작업자 이동, 도구 공급을 충족하기 전에는 생산하지 않는다. 도구는 가동 개시 비용이며 생산 매회 소비하는 레시피 원료가 아니다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) p.12; [BLD · Prima Guide / buildings](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/game-basics/buildings)

## 생산 관계와 수량의 분리

`recipes`는 누가 무엇을 만드는지, `recipe_inputs`는 어떤 물자가 필요한지 기록한다. 일반·고급 식량은 별도 정책 테이블로 주입한다. 무기 공방의 원료에 `bread`를 고정하면 생선 대체와 고급 식량 효과를 재현하지 못한다. `plain_food`는 빵 또는 생선의 선택 요구이며 창고에 존재하는 새 상품이 아니다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) pp.21–23

| 생산자 | 입력 재료(식량 별도) | 출력 | 수량 확인 | 가공 시간 |
|---|---|---|---|---|
| papermill | wood × 미확인, water × 미확인 | paper × 미확인 | 의존 관계 확인 | 미확인 |
| weaving_mill | wool × 미확인 | cloth × 미확인 | 의존 관계 확인 | 미확인 |
| brewery | grain × 미확인, water × 미확인 | beer × 미확인 | 의존 관계 확인 | 미확인 |
| bakery | flour × 미확인 | bread × 미확인 | 의존 관계 확인 | 미확인 |
| wheelwright | wood × 미확인, iron × 미확인 | wheel × 미확인 | 의존 관계 확인 | 미확인 |
| toolmaker | wood × 1, iron × 1 | tool × 1 | 재료 수량 확인 | 미확인 |
| bookbindery | paper × 미확인 | book × 미확인 | 의존 관계 확인 | 미확인 |
| mint | gold × 미확인, coal × 미확인 | coin × 미확인 | 의존 관계 확인 | 미확인 |
| blacksmith | wood × 미확인, iron × 미확인 | weapon × 미확인 | 의존 관계 확인 | 미확인 |
| goldsmith | gold × 미확인, iron × 미확인 | jewelry × 미확인 | 의존 관계 확인 | 미확인 |
| tailor | cloth × 미확인 | garment × 미확인 | 의존 관계 확인 | 미확인 |
| butcher | animal × 미확인 | meat × 미확인 | 의존 관계 확인 | 미확인 |
| grain_barn | 환경: fertile_land | grain × 미확인 | 의존 관계 확인 | 미확인 |
| piggery | grain × 미확인, water × 미확인 | animal × 미확인 | 의존 관계 확인 | 미확인 |
| shepherd | water × 미확인 | wool × 미확인 | 의존 관계 확인 | 미확인 |
| stable | grain × 미확인, water × 미확인 | horse × 미확인 | 의존 관계 확인 | 미확인 |
| windmill | grain × 미확인 | flour × 미확인 | 의존 관계 확인 | 미확인 |
| fisher | 환경: fish_deposit | fish × 미확인 | 의존 관계 확인 | 미확인 |
| hunter | 환경: wildlife | animal × 미확인 | 의존 관계 확인 | 미확인 |
| sawmill | wood × 미확인 | plank × 미확인 | 의존 관계 확인 | 미확인 |
| woodcutter | 환경: trees | wood × 미확인 | 의존 관계 확인 | 미확인 |
| coal_miner | 환경: coal_deposit | coal × 미확인 | 의존 관계 확인 | 미확인 |
| iron_miner | 환경: iron_deposit | iron_ore × 미확인 | 의존 관계 확인 | 미확인 |
| gold_miner | 환경: gold_deposit | gold × 미확인 | 의존 관계 확인 | 미확인 |
| iron_smelter | iron_ore × 1, coal × 1 | iron × 1 | 재료 수량 확인 | 미확인 |
| quarry | 환경: stone_deposit | stone × 미확인 | 의존 관계 확인 | 미확인 |
| coking_plant | wood × 미확인 | coal × 미확인 | 의존 관계 확인 | 미확인 |
| well | 별도 반입 원료 없음 | water × 미확인 | 의존 관계 확인 | 미확인 |


재료 종류의 근거는 각 레시피 행의 `source_id`와 `locator`로 연결한다. 도구의 1통나무+1철괴→1도구, 제련의 1철광석+1석탄→1철괴는 본문에 수량이 명시된 사례이다. 그 외 수량을 관행적으로 1이라고 채우지 않았다. 생산 시간은 28개 모두 미확인이다. 웰의 물 생산은 부속 작업장과 다른 생산자 유형이고, Forester의 조림은 상품 생산이 아니라 월드 상태 변경이다.

## 식량 정책

| 정책 | 식량 그룹 | 산출 배율 | 매 주기 식량 수량 |
|---|---|---|---|
| std_none | 미확인 | 1 | 0 |
| std_plain | plain_food | 2 | 미확인 |
| std_fancy | fancy_food | 3 | 미확인 |
| noble_plain | plain_food | 1 | 1 |
| noble_fancy | fancy_food | 2 | 미확인 |
| forester_no_boost | 미확인 | 1 | 0 |


일반 작업장과 귀족 주택을 같은 배율로 처리하지 않는다. 귀족 주택은 무식량 모드에서 정상 생산한다고 가정하지 않는다. 선택한 식량이 없거나 다른 작업자에게 예약되어 있으면 생산이 멈춘다. 조림 작업자는 식량 부스트를 받지 않는다. Farm은 매뉴얼 해당 본관 열거에서 빠져 있지만 개발팀의 Piggery 식량 부스트 사례가 있으므로 해당 출처를 별도로 연결했다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) pp.22–23; [DEV · Developer Tips: From Inside The Studio](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/essentials/developer-tips/from-inside-the-studio)

귀족 도축장의 고급 식량 1 소비→고급 식량 2 산출 예시는 자체 순증1이지만, 동물 투입량과 공정 시간까지 확인한 완전한 레시피는 아니다. 이 예시를 다른 귀족 작업장의 모든 수량에 일반화하지 않는다.

## 환경·배치 조건

곡물 농사·양치기·조림은 비옥한 땅 조건을 갖고, 광부·어부·사냥꾼은 월드 자원 공급원과 연결된다. 통나무를 베어 사냥터를 줄이는 선택은 단순 재고 생산표만으로 설명되지 않는다. 채집 범위 중심은 작업장 선택에서 재지정할 수 있다. 광맥 매장량과 창고 광석은 다른 장부이다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) pp.14–17,24

## 재구축 구현 계약 — 제안 명세

가동은 `완공 → 인구 배정 → 도구 도착 → 원료/식량 요구 → 반입 → 가공 → 산출 → 반출`의 분리된 상태로 구현한다. 이는 관찰 가능한 규칙을 구현하기 위한 재구성 구조이며 원본 소스코드의 상태명 복원은 아니다. 생산시간 미확인 상태에서는 UI 카탈로그와 의존 관계 탐색만 활성화하고, 실행용 프로토타입 수치는 별도 프로필로 명시한다.
