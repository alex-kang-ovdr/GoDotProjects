"""Behavioral tests with explicit expected outcomes, including in-transit recovery."""
import copy
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from network_sim import Graph, Simulation, load_config, validate
from run_experiments import fleet


def micro(carriers=1, quantity=3, capacity=20):
    c = load_config()
    c.update(id='micro', nodes=[dict(id=x) for x in ('src','mid','dst')],
      edges=[dict(id='first',a='src',b='mid',length=3),dict(id='second',a='mid',b='dst',length=4)],
      stores=[dict(id='source',kind='workshop',node='src',capacity=20,recipe='saw',warehouse='dest',initial={'plank':quantity},mode='paused'),
              dict(id='dest',kind='warehouse',node='dst',capacity=capacity,initial={})],
      carriers=[dict(id=f'c{i}',node='src',capacity=3) for i in range(carriers)],
      sinks=[dict(id='delivery',warehouse='dest',resource='plank',quantity=3,every=1,target=3,reserve=0)],events=[])
    return c


class ValidationTests(unittest.TestCase):
    def test_valid_baseline(self): validate(load_config())
    def test_unknown_resource_rejected(self):
        c=load_config();c['recipes'][0]['outputs']={'missing':1}
        with self.assertRaises(ValueError):Simulation(c)
    def test_duplicate_store_rejected(self):
        c=load_config();c['stores'].append(copy.deepcopy(c['stores'][0]))
        with self.assertRaises(ValueError):Simulation(c)
    def test_zero_recipe_duration_rejected(self):
        c=load_config();c['recipes'][0]['seconds']=0
        with self.assertRaises(ValueError):Simulation(c)
    def test_negative_stock_rejected(self):
        c=load_config();c['stores'][0]['initial']={'grain':-1}
        with self.assertRaises(ValueError):Simulation(c)
    def test_overfull_initial_stock_rejected(self):
        c=micro(quantity=21)
        with self.assertRaises(ValueError):Simulation(c)
    def test_nonfinite_speed_rejected(self):
        c=micro();c['edges'][0]['speed']=float('inf')
        with self.assertRaises(ValueError):Simulation(c)
    def test_bad_warehouse_reference_rejected(self):
        c=micro();c['stores'][0]['warehouse']='missing'
        with self.assertRaises(ValueError):Simulation(c)
    def test_parallel_edges_rejected(self):
        c=micro();c['edges'].append(dict(id='dup',a='mid',b='src',length=2))
        with self.assertRaises(ValueError):Simulation(c)
    def test_negative_duration_rejected(self):
        with self.assertRaises(ValueError):Simulation(micro()).run(-1)


class RoutingTests(unittest.TestCase):
    def graph(self):
        return Graph([dict(id=x) for x in 'abcd'],[dict(id='ab',a='a',b='b',length=9),dict(id='ac',a='a',b='c',length=2),dict(id='cb',a='c',b='b',length=2)])
    def test_weighted_not_fewest_edges(self):
        self.assertEqual(self.graph().route('a','b'),(4,['ac','cb']))
    def test_cache_invalidation_on_closure(self):
        g=self.graph();g.route('a','b');g.set_open('cb',False)
        self.assertEqual(g.route('a','b'),(9,['ab']))
        g.set_open('cb',True);self.assertEqual(g.route('a','b')[0],4)
    def test_unreachable_node(self):self.assertIsNone(self.graph().route('a','d'))
    def test_same_node_zero_distance(self):self.assertEqual(self.graph().route('a','a'),(0,[]))
    def test_empty_and_loaded_travel_are_counted(self):
        c=micro();c['carriers'][0]['node']='dst';s=Simulation(c);s.run(25)
        self.assertEqual(s.carriers[0]['empty_ticks'],7)
        self.assertEqual(s.carriers[0]['loaded_ticks'],7)
        j=next(iter(s.jobs.values()));self.assertEqual(j['completed_tick']-j['assigned_tick'],16)
    def test_blocked_cargo_waits_and_resumes(self):
        c=micro();c['events']=[dict(tick=3,edge='second',open=False),dict(tick=20,edge='second',open=True)]
        s=Simulation(c);s.run(15)
        self.assertEqual(s.fulfilled['delivery'],0)
        self.assertEqual(s.carriers[0]['cargo']['qty'],3)
        self.assertGreater(s.carriers[0]['blocked_ticks'],0)
        s.run(20);self.assertEqual(s.fulfilled['delivery'],3);s.audit()
    def test_route_uses_detour_after_closure(self):
        c=micro();c['nodes'].append(dict(id='alt'))
        c['edges'] += [dict(id='detour_a',a='mid',b='alt',length=2),dict(id='detour_b',a='alt',b='dst',length=5)]
        c['events']=[dict(tick=3,edge='second',open=False)]
        s=Simulation(c);s.run(20)
        self.assertEqual(s.fulfilled['delivery'],3);self.assertEqual(s.carriers[0]['loaded_ticks'],10)
    def test_disconnected_source_not_dispatched(self):
        c=micro();c['edges'][0]['open']=False;s=Simulation(c);s.run(20)
        self.assertEqual(len(s.jobs),0);self.assertEqual(s.stores['source']['stock']['plank'],3)


class InventoryTests(unittest.TestCase):
    def test_destination_slots_reserved_once(self):
        c=micro(carriers=8,quantity=12,capacity=1);c['sinks']=[];s=Simulation(c);s.run(1)
        self.assertEqual(s.stores['dest']['reserved_in']['plank'],1)
        self.assertEqual(sum(j['qty'] for j in s.jobs.values()),1)
    def test_source_reserved_once(self):
        s=Simulation(micro(carriers=8,quantity=2));s.run(1)
        self.assertEqual(s.stores['source']['reserved_out']['plank'],2)
        self.assertEqual(sum(j['qty'] for j in s.jobs.values()),2)
    def test_cancel_unpicked_releases_reservations(self):
        s=Simulation(micro());s.run(1);jid=next(iter(s.jobs));before=s.inventory()
        self.assertTrue(s.cancel_unpicked(jid));self.assertEqual(s.inventory(),before)
        self.assertEqual(s.stores['dest']['reserved_in']['plank'],0)
        self.assertEqual(s.stores['source']['reserved_out']['plank'],0)
        self.assertFalse(s.cancel_unpicked(jid))
    def test_loaded_cancellation_does_not_erase_or_refund(self):
        s=Simulation(micro());s.run(3);jid=next(iter(s.jobs))
        self.assertEqual(s.jobs[jid]['status'],'carrying');before=s.inventory()
        self.assertFalse(s.cancel_unpicked(jid));self.assertEqual(s.inventory(),before)
        s.run(30);self.assertEqual(s.fulfilled['delivery'],3)
    def test_multiinput_start_is_atomic(self):
        c=load_config();c['carriers']=[]
        for w in c['stores']:
            if w['kind']=='workshop':w['mode']='paused'
            if w.get('recipe')=='smelt':w['mode']='always';w['initial']={'ore':1}
        s=Simulation(c);s.run(100)
        self.assertEqual(s.stores['ws_smelter']['stock']['ore'],1)
        self.assertEqual(s.consumed_production['ore'],0)
        self.assertEqual(s.produced['iron'],0)
    def test_capacity_is_per_resource_not_total(self):
        c=micro();c['stores'][1]['capacity']=2;c['stores'][1]['initial']={'ore':2,'coal':2}
        s=Simulation(c);self.assertEqual(s.free('dest','plank'),2)
        self.assertEqual(sum(s.stores['dest']['stock'].values()),4)
    def test_full_output_stops_production(self):
        c=load_config();c['carriers']=[];s=Simulation(c);s.run(200)
        self.assertEqual(s.stores['ws_farm']['stock']['grain'],6)
        self.assertEqual(s.produced['grain'],6)
        self.assertEqual(s.stores['ws_farm']['state'],'output_blocked')
    def test_finite_deposit_depletes(self):
        c=load_config();c['carriers']=[]
        next(w for w in c['stores'] if w['id']=='ws_farm')['deposit']=2
        s=Simulation(c);s.run(100)
        self.assertEqual(s.produced['grain'],2);self.assertEqual(s.stores['ws_farm']['state'],'depleted')
    def test_zero_carrier_no_terminal_deliveries(self):
        c=load_config();c['carriers']=[];r=Simulation(c).run(200)
        self.assertTrue(all(n==0 for n in r['fulfilled'].values()))
    def test_no_farm_supply_no_flour_or_bread(self):
        c=load_config();next(w for w in c['stores'] if w['id']=='ws_farm')['deposit']=0
        r=Simulation(c).run(500);self.assertEqual(r['produced']['flour'],0);self.assertEqual(r['produced']['bread'],0)
    def test_mass_accounting_every_resource(self):
        s=Simulation(load_config());s.run(500);current=s.inventory()
        for r in s.resources:
            self.assertEqual(current[r],s.initial[r]+s.produced[r]-s.consumed_production[r]-s.consumed_sink[r])
    def test_paused_workshop_no_new_production(self):
        c=load_config()
        for w in c['stores']:
            if w['kind']=='workshop':w['mode']='paused'
        r=Simulation(c).run(100);self.assertEqual(sum(r['produced'].values()),0)
    def test_target_stock_pauses_at_threshold(self):
        c=load_config();c['carriers']=[];w=next(w for w in c['stores'] if w['id']=='ws_farm');w['mode']='target_stock';w['target']=2
        s=Simulation(c);s.run(100);self.assertEqual(s.produced['grain'],2)
        self.assertEqual(s.stores['ws_farm']['state'],'target_reached')


class IntegrationTests(unittest.TestCase):
    def test_all_three_chains_run_from_zero_stock(self):
        r=Simulation(fleet(load_config(),8)).run(1200)
        for x in ('bread','plank','iron','weapon','tool'):self.assertGreater(r['produced'][x],0)
        self.assertGreater(r['fulfilled']['deliver_weapon'],0)
    def test_exact_determinism(self):
        a=Simulation(load_config());b=Simulation(load_config())
        self.assertEqual(a.run(400),b.run(400));self.assertEqual(a.trace,b.trace)
    def test_mid_cargo_save_load_matches_uninterrupted(self):
        c=micro();c['events']=[dict(tick=3,edge='second',open=False),dict(tick=20,edge='second',open=True)]
        a=Simulation(c);a.run(10);self.assertIsNotNone(a.carriers[0]['cargo'])
        b=Simulation.restore(json.loads(json.dumps(a.snapshot())))
        self.assertEqual(a.run(30),b.run(30));self.assertEqual(a.trace,b.trace)
    def test_network_save_load_matches_uninterrupted(self):
        a=Simulation(load_config());a.run(321)
        b=Simulation.restore(json.loads(json.dumps(a.snapshot())))
        self.assertEqual(a.run(279),b.run(279))
    def test_corrupt_save_is_rejected(self):
        s=Simulation(micro()).snapshot();s['stores']['source']['stock']['plank']=-1
        with self.assertRaises(AssertionError):Simulation.restore(s)
    def test_unknown_save_version_rejected(self):
        s=Simulation(micro()).snapshot();s['schema']='future'
        with self.assertRaises(ValueError):Simulation.restore(s)
    def test_unexpected_save_field_rejected(self):
        s=Simulation(micro()).snapshot();s['run']='malformed'
        with self.assertRaises(ValueError):Simulation.restore(s)
    def test_zero_second_run_keeps_inventory(self):
        s=Simulation(micro());before=s.inventory();r=s.run(0)
        self.assertEqual(s.inventory(),before);self.assertEqual(r['seconds'],0)
    def test_more_carriers_improve_total_in_named_fixture(self):
        a=Simulation(fleet(load_config(),2)).run(700)
        b=Simulation(fleet(load_config(),8)).run(700)
        self.assertGreater(sum(b['fulfilled'].values()),sum(a['fulfilled'].values()))
        # This is NOT an assertion that each product is monotone under all schedulers.

if __name__=='__main__':unittest.main(verbosity=2)
