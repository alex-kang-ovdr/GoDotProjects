"""Optional browser QA. Requires Playwright and an installed Chromium.
Reference viewer only; these are NOT original-game tests.
"""
import argparse, json
from pathlib import Path
from playwright.sync_api import sync_playwright

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--chromium',default='/usr/bin/chromium')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    tests=[]; errors=[]
    def check(name,condition):
        tests.append({'test':name,'passed':bool(condition)})
        if not condition: raise AssertionError(name)
    with sync_playwright() as p:
        b=p.chromium.launch(executable_path=args.chromium,headless=True,args=['--no-sandbox'])
        page=b.new_page(viewport={'width':1440,'height':1000},accept_downloads=True)
        page.on('pageerror',lambda e:errors.append(str(e)))
        # file:// navigation is restricted by this environment; load the identical HTML bytes.
        page.set_content((root/'report.html').read_text(encoding='utf-8'),wait_until='load')
        page.wait_for_function('window.v22Ready===true')
        check('ready_and_five_tabs',page.locator('nav button').count()==5)
        check('42_table_options',page.locator('#tableSelect option').count()==42)
        page.locator('button[data-tab="calculator"]').click()
        def vals():return page.locator('#outputs strong').all_text_contents()
        check('six_default_formula_values',vals()==['23','9','4','9.7','2.8','0.9'])
        for key in ['musketeers','cavaliers','cannons','wooden_towers','stone_towers']:
            page.locator('#n_'+key).fill('0')
        check('pikemen_only_recalculation',vals()==['13','0','0','6','0','0'])
        page.locator('#n_pikemen').fill('-1')
        check('reject_negative',page.locator('#outputs strong').count()==0 and bool(page.locator('#error').inner_text()))
        page.locator('#n_pikemen').fill('1.5')
        check('reject_fractional_input',page.locator('#outputs strong').count()==0)
        page.locator('#n_pikemen').fill('')
        check('reject_empty_input',page.locator('#outputs strong').count()==0)
        page.locator('#n_pikemen').fill('4')
        page.locator('button[data-tab="recruit"]').click()
        page.locator('#costProfile').select_option('pre_108_documented')
        before=page.locator('#recruitRows tbody tr').all_text_contents()
        page.locator('#costProfile').select_option('patch_108_documented')
        after=page.locator('#recruitRows tbody tr').all_text_contents()
        check('recruit_profile_switch',len(before)==14 and len(after)==14 and before!=after)
        page.locator('button[data-tab="catalog"]').click()
        page.locator('#tableSelect').select_option('versioned_unit_costs')
        page.locator('#search').fill('musketeer')
        check('filtered_rows',page.locator('#dataTable tbody tr').count()==6)
        with page.expect_download() as d:
            page.locator('#exportCsv').click()
        download=d.value
        path=root/'reports/browser_download_sample.csv'
        download.save_as(path)
        check('csv_download',download.suggested_filename=='versioned_unit_costs_v22.csv' and len(path.read_text(encoding='utf-8-sig').splitlines())==7)
        page.locator('button[data-tab="sources"]').click()
        check('seven_new_sources',page.locator('#sourceTable tbody tr').count()==7)
        check('nine_new_unknowns',page.locator('#unknownTable tbody tr').count()==9)
        page.set_viewport_size({'width':390,'height':844})
        page.locator('button[data-tab="overview"]').click()
        check('mobile_page_width',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
        check('no_js_errors',not errors)
        b.close()
    out={'passed':all(t['passed'] for t in tests),'test_count':len(tests),'tests':tests,'page_errors':errors,'load_method':'Chromium set_content of actual report.html bytes','file_url_test':'blocked by environment policy; not verified','scope':'data viewer only; not game playback'}
    (root/'reports/browser_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
