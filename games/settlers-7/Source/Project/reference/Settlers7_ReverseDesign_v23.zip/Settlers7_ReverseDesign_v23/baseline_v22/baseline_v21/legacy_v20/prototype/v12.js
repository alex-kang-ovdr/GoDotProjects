// v12: Road topology editor, reachable-workshop audit and save migration.
// This module does not replace the v11 courier scheduler; it exposes and validates its road graph.
(() => {
'use strict';
const S=window.S7Spatial;
const panel=document.createElement('section');panel.className='panel';panel.style.margin='14px';
panel.innerHTML=`<h2>v12 · 도로 네트워크 편집 및 물류 진단</h2>
<p class="hint">도로를 제거할 때 작업장 연결이 끊기는지 검사합니다. 선택한 지역의 모든 작업장에 대해 허브 도달 가능성과 최단 도로 거리를 계산합니다. 운반자의 기존 진행 중 배송은 v11 규칙을 유지합니다.</p>
<div><label>지역 <select id="v12sector"></select></label><button id="v12mode">도로 철거 모드: 꺼짐</button><button id="v12audit">물류 진단</button><button id="v12test">v12 자동 검사</button></div>
<div id="v12summary" class="pill"></div><div id="v12details" style="max-height:240px;overflow:auto"></div><div id="v12results"></div>`;
document.querySelector('.layout').insertAdjacentElement('beforebegin',panel);
const sel=panel.querySelector('#v12sector');for(let i=0;i<6;i++){let o=document.createElement('option');o.value=i;o.textContent=SECTOR_NAMES[i];sel.append(o)}
let demolish=false;const key=(x,y)=>`${x},${y}`;
function graph(sector,excluded){const road=S.roads.filter(r=>r.sector===sector&&r!==excluded);const nodes=new Map(road.map(r=>[key(r.x,r.y),r]));const hub=road.find(r=>r.hub);const dist=new Map();if(hub){let q=[hub];dist.set(key(hub.x,hub.y),0);for(let h=0;h<q.length;h++){let a=q[h],d=dist.get(key(a.x,a.y));for(let [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){let k=key(a.x+dx,a.y+dy),n=nodes.get(k);if(n&&!dist.has(k)){dist.set(k,d+1);q.push(n)}}}}return {hub,nodes,dist,roads:road}}
function distance(g,b){let values=[[b.x,b.y],[b.x-1,b.y],[b.x+1,b.y],[b.x,b.y-1],[b.x,b.y+1]].map(([x,y])=>g.dist.get(key(x,y))).filter(x=>x!==undefined);return values.length?Math.min(...values)+1:Infinity}
function audit(sector){const g=graph(sector),bs=S.buildings.filter(b=>b.sector===sector),unreachable=bs.filter(b=>!Number.isFinite(distance(g,b)));return {sector,roads:g.roads.length,reachable:g.dist.size,buildings:bs.length,unreachable,distances:bs.map(b=>({b,d:distance(g,b)}))}}
function renderAudit(){const s=Number(sel.value),a=audit(s);panel.querySelector('#v12summary').textContent=`${SECTOR_NAMES[s]} · 도로 ${a.roads}칸 · 허브 연결 ${a.reachable}칸 · 작업장 ${a.buildings}개 · 연결 불가 ${a.unreachable.length}개`;
panel.querySelector('#v12details').innerHTML=a.distances.map(({b,d})=>`<div class="pill" style="margin:4px 0">${b.kind} #${b.id} (${b.x},${b.y}) · ${Number.isFinite(d)?'거리 '+d:'⚠ 도로 연결 없음'}</div>`).join('')||'작업장 없음';return a}
function removeRoad(x,y){let r=S.roads.find(r=>r.x===x&&r.y===y);if(!r){log('도로가 아닌 타일입니다');return}if(r.hub){log('지역 허브는 철거할 수 없습니다');return}if(kingdom.sectors[r.sector]!==0){log('자신의 지역만 편집할 수 있습니다');return}let old=audit(r.sector),g=graph(r.sector,r);let newly=old.distances.filter(({b,d})=>Number.isFinite(d)&&!Number.isFinite(distance(g,b))).length;if(newly){log(`철거 취소: 작업장 ${newly}개가 도로망에서 고립됩니다`);return}S.roads.splice(S.roads.indexOf(r),1);log('도로 1칸 철거 완료');render();renderAudit()}
const map=document.getElementById('v10map');map.addEventListener('click',e=>{if(!demolish)return;const box=map.getBoundingClientRect();let x=Math.floor((e.clientX-box.left)/box.width*S.COLS),y=Math.floor((e.clientY-box.top)/box.height*S.ROWS);removeRoad(x,y)},true);
// Capture phase: v10 also handles clicks; prevent a demolition click from constructing a road.
map.addEventListener('click',e=>{if(demolish){e.stopImmediatePropagation();e.preventDefault()}},true);
panel.querySelector('#v12mode').onclick=()=>{demolish=!demolish;panel.querySelector('#v12mode').textContent='도로 철거 모드: '+(demolish?'켜짐':'꺼짐');};
panel.querySelector('#v12audit').onclick=renderAudit;sel.onchange=renderAudit;
function verify(){const checks=[['허브 6개',Array.from({length:6},(_,s)=>graph(s).hub).every(Boolean)],['도로 중복 없음',new Set(S.roads.map(r=>key(r.x,r.y))).size===S.roads.length],['도로 좌표 유효',S.roads.every(r=>Number.isInteger(r.x)&&Number.isInteger(r.y)&&r.x>=0&&r.x<S.COLS&&r.y>=0&&r.y<S.ROWS)],['모든 작업장 좌표 유효',S.buildings.every(b=>b.x>=0&&b.x<S.COLS&&b.y>=0&&b.y<S.ROWS)],['도로 허브 연결 진단 가능',Array.from({length:6},(_,s)=>audit(s)).every(a=>a.reachable>=1)]];panel.querySelector('#v12results').innerHTML=checks.map(([n,v])=>`<div>${v?'✅':'❌'} ${n}</div>`).join('');return checks.every(x=>x[1])}
panel.querySelector('#v12test').onclick=verify;
// Store the complete v11 snapshot, including spatial roads and couriers, under a v12 key.
const oldSave=document.getElementById('save').onclick,oldLoad=document.getElementById('load').onclick;
document.getElementById('save').onclick=()=>{oldSave();const d=localStorage.getItem('settlers7_v11');if(d)localStorage.setItem('settlers7_v12',d);};
document.getElementById('load').onclick=()=>{const d=localStorage.getItem('settlers7_v12');if(d)localStorage.setItem('settlers7_v11',d);oldLoad();renderAudit()};
window.S7RoadAudit={audit,graph,distance,verify};renderAudit();
})();