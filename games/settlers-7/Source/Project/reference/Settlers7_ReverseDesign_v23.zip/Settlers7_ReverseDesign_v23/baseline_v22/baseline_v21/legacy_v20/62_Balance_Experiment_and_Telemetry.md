# 밸런스 실험·자동 계측 설계

> v14 상세 설계 / 원작 미검증 수치는 예시 또는 제안으로 명시

## 실험 단위
동일 맵·시드·AI 조합에서 매개변수 한 개만 변경해 100회 이상 시뮬레이션을 비교한다. 테스트 반복 횟수는 제안값이며 통계적 검정력에 따라 조정한다.

## 계측 이벤트
BuildingPlaced, ProductionStarted, ProductionBlocked, DeliveryCreated, DeliveryCompleted, SectorCaptured, VPChanged, MatchEnded. 모든 이벤트는 tick, playerId, entityId, reason, dataVersion 포함.

## 주요 지표
생산 가동률, 물류 배송 지연 P50/P95, 원료 부족 시간, 창고 평균 재고, 전략별 승률, 경기 길이 P50/P90, 플레이어별 VP 역전 횟수.

## 밸런스 가드레일(제안)
동일 실력 AI의 3경로 승률 격차 10%p 이내, 시작 5분 내 필수 자원 고갈 비율 5% 미만, 작업장 90% 이상이 장시간 정지한 경기 비율 2% 미만. 지표는 원작 값이 아닌 개발 목표다.

## 테스트 절차
파라미터 변경 → 데이터 유효성 검사 → 결정적 시뮬레이션 → 결과 CSV 생성 → 전후 비교 → 승인 또는 롤백. 빌드 버전과 데이터 해시를 기록한다.
