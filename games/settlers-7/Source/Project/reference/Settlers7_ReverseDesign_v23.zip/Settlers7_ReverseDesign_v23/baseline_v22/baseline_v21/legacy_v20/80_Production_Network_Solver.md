# v17 생산 네트워크 수요 계산 명세

## 정의
레시피 r의 실행률 x_r (회/분), 자원 i의 외부 수요 d_i, 재고 변화량 Δ_i:

Δ_i = Σ_r output(i,r) × x_r − Σ_r input(i,r) × x_r − d_i

생산능력 제약: 0 ≤ x_r ≤ workshop_count_r × 60 / cycle_seconds_r × uptime_r.

목표 산출물을 만족하도록 원재료→중간재→최종재 순서로 요구량을 역산한다. 순환 레시피는 위상 정렬 대신 선형 제약 또는 반복 수렴을 사용한다.

## 병목 판단
- 생산 부족: capacity < required_rate
- 원료 부족: available_rate < consumption_rate
- 물류 부족: delivered_rate < produced_rate 또는 요청 대기시간 초과
- 저장 부족: output_buffer >= capacity

## 수용 기준
- 모든 입력과 출력은 동일한 단위(개/분)를 사용한다.
- 생산 중단·배송 중인 재고·예약된 재고를 중복 계산하지 않는다.
- 목표를 0으로 설정하면 불필요한 건물 추천이 발생하지 않는다.
- 분모가 0인 경우 무한대가 아닌 '공급 불가'로 보고한다.
