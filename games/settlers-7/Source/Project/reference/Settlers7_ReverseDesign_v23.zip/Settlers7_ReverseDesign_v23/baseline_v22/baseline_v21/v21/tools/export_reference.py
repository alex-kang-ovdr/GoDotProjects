#!/usr/bin/env python3
"""Reference export only; never fills unknown fields with prototype defaults."""
import argparse,json,sys
from pathlib import Path
from validate import load,validate,readiness

def export(master, output:Path, mode:str='reference'):
    errors=validate(master)
    if errors:raise ValueError('Invalid reference data: '+str(errors[:3]))
    if mode=='runtime':
        raise ValueError('Original runtime export BLOCKED: unknown production/combat/research values and unresolved source conflicts. No output written.')
    output.parent.mkdir(parents=True,exist_ok=True)
    payload={'format':'reference_only','must_not_fill_nulls':True,'readiness':readiness(master),'catalog':master}
    output.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    return payload

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['reference','runtime'],default='reference');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    try:export(load(),a.output,a.mode)
    except ValueError as e:print(str(e),file=sys.stderr);return 2
    print('Reference catalog written:',a.output);return 0
if __name__=='__main__':sys.exit(main())
