from pathlib import Path
import unittest,json,sys,time
ROOT=Path(__file__).resolve().parents[1]
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_*.py')
class LogResult(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.rows=[]
    def addSuccess(self,test):super().addSuccess(test);self.rows.append({'test':test.id(),'status':'passed'})
    def addFailure(self,test,err):super().addFailure(test,err);self.rows.append({'test':test.id(),'status':'failed'})
    def addError(self,test,err):super().addError(test,err);self.rows.append({'test':test.id(),'status':'error'})
t0=time.monotonic();r=unittest.TextTestRunner(verbosity=2,resultclass=LogResult).run(suite)
report={'test_count':r.testsRun,'passed':r.wasSuccessful(),'failures':len(r.failures),'errors':len(r.errors),'seconds':round(time.monotonic()-t0,3),'scope':'reference calculations and schema; not original-game tests','tests':r.rows}
(ROOT/'reports/test_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(0 if r.wasSuccessful() else 1)
