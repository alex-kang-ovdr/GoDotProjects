# 03. 운송·인구·우선순위 재구축

## 세 역할은 서로 다르다

| 역할 | 출발·귀속 | 하는 일 | 잘못된 혼합 |
|---|---|---|---|
| 작업자(worker) | 작업장 | 주변 창고에서 원료 반입, 완제품 반출 | 모든 작업자를 공용 배달원으로 취급 |
| 창고 운반자(carrier) | 창고 | 도로를 따라 창고 사이 중계 | 상인 거래 횟수를 화물 적재량으로 사용 |
| 상인(trader) | 무역 사무소 | 교역·이벤트 납품·뇌물 전달 | 원료 배송을 상인 임무로 대체 |

매뉴얼은 생산품을 가까운 창고에 놓고 수요가 생기면 창고 사슬을 통해 이동시킨다고 설명한다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) pp.18–19,34–37

```text
작업장 A ⇄ 가까운 창고 A ⇄ 중간 창고 B ⇄ 가까운 창고 C ⇄ 작업장 C
  작업자        창고 소속 운반자         창고 소속 운반자        작업자
```

중간 창고 인계와 운반자 귀속은 원작형 재구축의 중요한 차이이다. 이전 v20의 전역 운반자 풀은 실험용 모델로 보존하며 이 구조와 같은 것으로 취급하지 않는다.

## 용량과 문헌 프로필

BLD 건물 표에서 창고는 상품 종류별 기본20, 첫승급50, 두번째 승급 무제한이다. 운반자 수는 2→3→4다. 다만 개발팀 팁 일부의 첫승급20 표기와 충돌하여 용량은 `BLD_buildings` 프로필로만 유지한다. 운반 1회 적재량은 매뉴얼3/개발팀팁5가 충돌하므로 공통 확정값은 null이다. [BLD · Prima Guide / buildings](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/game-basics/buildings) / [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) / [DEV · Developer Tips: From Inside The Studio](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/essentials/developer-tips/from-inside-the-studio)

무제한은 0이 아니라 `unlimited_storage=true, capacity_per_resource=null`이다. 처음부터 완전 승급된 시작 창고와 새로 건설한 기본 창고를 구별해야 한다. 신규 창고 2운반자와 생활 공간1은 같지 않으며, 운반자 역시 전체 거주 공간을 소비한다.

## 도로

맵에 처음 놓인 inter-sector road와 플레이어가 추가하는 street를 구별한다. 추가 street는 무료이고 철거 가능하다. 기존 road는 철거할 수 없다. 포장에는 명성 해금과 석재가 필요하지만 길이당 비용과 속도 계수는 복원하지 못했다. 포장 비용을 일반 도로 건설 비용으로 가져오지 않는다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) p.18

## 수요·예약·생산 모드

원작의 Idle은 일하지 않기, On Demand는 다른 건물·명령의 수요가 있을 때만 작업하기, Always는 필요한 원료가 있을 때 계속 생산하기이다. On Demand를 임의의 최소/최대 창고 재고량으로 바꾸지 않는다. 우선순위는 물류 패널의 위쪽 큐부터, 큐 내부에서는 왼쪽 항목부터 적용한다. 최고 우선순위 건물이 재료를 기다린다고 다른 모든 공사를 영구 정지시키지 않는다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) pp.12–13

최종 승급 창고의 물자 끌어오기는 생산 수요에 우선하지 않는다. 물자를 많이 소유해도 특정 작업장에 예약되어 다른 공정이 굶을 수 있다는 개발자 설명을 반영한다. [DEV · Developer Tips: From Inside The Studio](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/essentials/developer-tips/from-inside-the-studio)

## 제안 구현 인터페이스

```text
Demand(owner, inputGroup, quantity, queueRank, itemRank)
Reservation(stockLocation, resource, quantity, demandId)
Leg(sourceWarehouse, destinationWarehouse, carrierOwner, cargo)
ProductionJob(workyard, inputsReserved, foodPolicy, outputReservation)
```

위 엔티티와 예약 순서는 신규 구현 계약이다. 원본 내부 자료구조를 추출한 것이 아니다. 수요 취소·건물 철거·점령·도로 단절 시 원천/운송/도착 재고 중 정확히 한 곳만 소유권을 갖도록 처리한다. 도로 단절 시 우회·대기·반납 정책의 세부는 미실측이므로 원작 행동으로 단정하지 않는다.

## 필수 검증 관찰

같은 창고 2개와 같은 생산자/소비자를 두고 거리만 바꾼다. 운반자가 다른 창고 사이 이동을 연속 담당하는지, 한 운반에 다른 상품을 섞는지, 빈손 귀환 여부, 가까운 창고의 선택 기준, 가득 찬 창고의 대체 선택을 기록한다. 화면에 표시된 이동 시간 전체를 생산 가공 시간으로 쓰지 않는다.
