#!/usr/bin/env python3
import json
import platform
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class RecordedResult(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test);self.outcomes.append(dict(test=test.id(),status='running'))
    def addSuccess(self,test):
        super().addSuccess(test);self.outcomes[-1]['status']='passed'
    def addFailure(self,test,err):
        super().addFailure(test,err);self.outcomes[-1].update(status='failed',message=self._exc_info_to_string(err,test))
    def addError(self,test,err):
        super().addError(test,err);self.outcomes[-1].update(status='error',message=self._exc_info_to_string(err,test))
    def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.outcomes=[]
def main():
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_*.py')
    result=unittest.TextTestRunner(verbosity=2,resultclass=RecordedResult).run(suite)
    report=dict(python=platform.python_version(),total=result.testsRun,passed=sum(x['status']=='passed' for x in result.outcomes),failures=len(result.failures),errors=len(result.errors),tests=result.outcomes)
    (ROOT/'reports'/'test_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return 0 if result.wasSuccessful() else 1
if __name__=='__main__':sys.exit(main())
