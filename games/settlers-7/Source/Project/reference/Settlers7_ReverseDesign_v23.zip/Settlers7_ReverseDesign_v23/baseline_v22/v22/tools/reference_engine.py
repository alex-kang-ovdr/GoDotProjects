#!/usr/bin/env python3
"""Version-scoped reference calculations, NOT an emulation of the original engine.
Uses only stdlib. All quantities originate in data/original_master.json.
"""
from __future__ import annotations
import argparse, json
from decimal import Decimal
from pathlib import Path
from typing import Any

DATA=Path(__file__).resolve().parents[1]/'data'/'original_master.json'
VARIABLES=('pikemen','musketeers','cavaliers','cannons','wooden_towers','stone_towers')
PROFILES=('pre_108_documented','patch_108_documented')

class ReferenceError(ValueError): pass

def load(path: str|Path=DATA)->dict:
    return json.loads(Path(path).read_text(encoding='utf-8'))

def _count(value: Any, field: str)->int:
    if type(value) is not int or value<0:
        raise ReferenceError(f'{field} must be a non-negative integer (bool is not accepted).')
    return value

def _profile(profile: str)->None:
    if profile not in PROFILES:
        raise ReferenceError(f'Explicit supported profile required: {PROFILES}. No History Edition fallback.')

def _decimal_text(v: Decimal)->str:
    return format(v.normalize(),'f') if v else '0'

def expansion_quote(counts: dict[str,int], profile: str='patch_108_documented', *,
                    ownership: str='neutral', modifiers: list|None=None, master:dict|None=None)->dict:
    if profile!='patch_108_documented':
        raise ReferenceError('The recovered formula is only documented for patch 1.08.')
    if ownership!='neutral':
        raise ReferenceError('This recovered cost formula is not an enemy-player capture rule.')
    if modifiers:
        raise ReferenceError('Modifier composition/order is unverified; do not apply guessed reductions.')
    if not isinstance(counts,dict): raise ReferenceError('counts must be an object')
    if set(counts)-set(VARIABLES): raise ReferenceError('Unknown count field; use surviving tower counts only.')
    c={v:_count(counts.get(v,0),v) for v in VARIABLES}
    t=(master or load())['tables'];result={}
    for r in t['expansion_formulas']:
        val=Decimal(r['constant'])+sum((Decimal(coef)*c[var] for var,coef in r['coefficients'].items()),Decimal(0))
        result[r['output_id']]=_decimal_text(val)
    return dict(profile_id=profile,input_surviving_counts=c,raw_cost=result,payable_integer_cost=None,
                rounding_policy=None,engine_equivalence_verified=False,
                source_ids=['P108'],status='document_formula_only',
                warning='성직자 소수점 처리·효과 합성·스크립트 예외 미확인. 실제 지불 비용으로 자동 적용하지 마세요.')

def recruitment_quote(profile:str,unit_id:str,location:str,count:int=1,*,master:dict|None=None)->dict:
    _profile(profile);_count(count,'count')
    rows=[r for r in (master or load())['tables']['versioned_unit_costs']
          if r['profile_id']==profile and r['unit_id']==unit_id and r['recruitment_location']==location]
    if not rows: raise ReferenceError('No verified scoped cost; no fallback to another building or unit.')
    return dict(profile_id=profile,unit_id=unit_id,location=location,count=count,
                resource_cost={r['requirement_id']:r['qty']*count for r in rows},
                population_cost=None,training_seconds=None,runtime_verified=False,source_ids=['P108'])

def general_bonus(profile:str,general_id:str,*,master:dict|None=None)->dict:
    _profile(profile);side='before' if profile==PROFILES[0] else 'after'
    rows=[r for r in (master or load())['tables']['general_revisions'] if r['general_id']==general_id]
    if not rows: raise ReferenceError('Unknown general in the patch record')
    return dict(profile_id=profile,general_id=general_id,documented_attributes={r['attribute']:r[side] for r in rows},
                damage_composition=None,runtime_verified=False,source_ids=['P108'])

def generalissimo_metric(events:list[dict],*,master:dict|None=None)->dict:
    """Proposed event adapter for documented eligibility, not original event format."""
    seen=set();n=0
    for e in events:
        if not isinstance(e,dict) or set(e)!={'id','victim_relation','killer_kind','count'}:
            raise ReferenceError('Event requires id, victim_relation, killer_kind, count')
        if not isinstance(e['id'],str) or not e['id'] or e['id'] in seen: raise ReferenceError('Missing/duplicate event id')
        seen.add(e['id'])
        if e['victim_relation'] not in ['hostile','neutral','allied','self']: raise ReferenceError('Unknown relation')
        if e['killer_kind'] not in ['army','fortification']: raise ReferenceError('Unknown killer kind')
        amount=_count(e['count'],'count')
        if e['victim_relation']=='hostile' and e['killer_kind']=='army': n+=amount
    threshold=next(r['value'] for r in (master or load())['tables']['patch_rules'] if r['id']=='generalissimo_threshold')
    return dict(eligible_kills=n,minimum_threshold=threshold,threshold_met=n>=threshold,
                awarded_vp=None,tie_rule=None,note='Counts only; does not award the victory point.')

def validate(master:dict)->list[str]:
    errors=[]
    if master.get('meta',{}).get('runtime_export_allowed') is not False: errors.append('runtime export must remain blocked')
    tables=master.get('tables',{})
    for table,rows in tables.items():
        ids=[r.get('id') for r in rows]
        if None in ids or len(set(ids))!=len(ids): errors.append(f'{table}: duplicate/missing id')
    src={r['id'] for r in tables.get('sources',[])}
    resources={r['id'] for r in tables.get('resources',[])}
    groups={r['id'] for r in tables.get('resource_groups',[])}
    units={r['id'] for r in tables.get('units',[])}
    techs={r['id'] for r in tables.get('technologies',[])}
    generals={r['id'] for r in tables.get('generals',[])}
    profiles={r['id'] for r in tables.get('edition_profiles',[])}
    for table,rows in tables.items():
        for r in rows:
            if 'source_id' in r and r['source_id'] not in src: errors.append(f'{table}/{r["id"]}: source missing')
            if r.get('runtime_verified') is True: errors.append(f'{table}/{r["id"]}: no runtime observation supplied')
    for r in tables.get('versioned_unit_costs',[]):
        if r['unit_id'] not in units:errors.append('cost unit missing')
        if r['profile_id'] not in profiles:errors.append('cost profile missing')
        pool=groups if r['requirement_kind']=='group' else resources
        if r['requirement_id'] not in pool:errors.append('cost resource missing')
        if type(r['qty']) is not int or r['qty']<=0:errors.append('cost quantity invalid')
        if r['recruitment_location']=='cannon_foundry':errors.append('ambiguous foundry row must be quarantined')
    for r in tables.get('technology_effects',[]):
        if r['technology_id'] not in techs: errors.append('technology effect reference missing')
    for r in tables.get('general_revisions',[]):
        if r['general_id'] not in generals: errors.append('general missing')
    for r in tables.get('expansion_formulas',[]):
        if r['rounding_policy'] is not None:errors.append('rounding not verified')
        if r['profile_id']!='patch_108_documented':errors.append('formula scope invalid')
        if set(r['coefficients'])-set(VARIABLES):errors.append('formula variable invalid')
        for x in [r['constant'],*r['coefficients'].values()]:
            try:
                if not Decimal(x).is_finite() or Decimal(x)<0:errors.append('coefficient invalid')
            except Exception:errors.append('coefficient unparsable')
    form={r['id']:r for r in tables.get('expansion_formulas',[])}
    coeffs={}
    for r in tables.get('formula_coefficients',[]):
        coeffs.setdefault(r['formula_id'],{})[r['variable']]=r['coefficient']
    for id,r in form.items():
        if coeffs.get(id)!={'constant':r['constant'],**r['coefficients']}:errors.append('coefficient table/master mismatch')
    for r in tables.get('edition_profiles',[]):
        if r['runtime_export'] is not False:errors.append('profile runtime export must be false')
    for r in tables.get('quarantined_claims',[]):
        if r['entity_id'] is not None or r['runtime_export']:errors.append('quarantine leak')
    # Existing baseline facts are not overwritten by generic starting-stock deltas.
    if len(tables.get('initial_stock',[]))!=211:errors.append('campaign stock baseline changed')
    if any(r.get('cycle_seconds') is not None for r in tables.get('recipes',[])):errors.append('unmeasured cycle time filled')
    return errors

def main()->int:
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='cmd',required=True)
    q=sub.add_parser('expansion');q.add_argument('--profile',default='patch_108_documented')
    for v in VARIABLES:q.add_argument('--'+v.replace('_','-'),type=int,default=0)
    r=sub.add_parser('recruit');r.add_argument('--profile',required=True);r.add_argument('--unit',required=True);r.add_argument('--location',required=True);r.add_argument('--count',type=int,default=1)
    g=sub.add_parser('general');g.add_argument('--profile',required=True);g.add_argument('--id',required=True)
    sub.add_parser('validate');sub.add_parser('export-runtime')
    a=p.parse_args()
    try:
        if a.cmd=='expansion':result=expansion_quote({v:getattr(a,v) for v in VARIABLES},a.profile)
        elif a.cmd=='recruit':result=recruitment_quote(a.profile,a.unit,a.location,a.count)
        elif a.cmd=='general':result=general_bonus(a.profile,a.id)
        elif a.cmd=='validate':
            e=validate(load());print(json.dumps({'errors':e,'passed':not e},ensure_ascii=False,indent=2));return 1 if e else 0
        else:
            print(json.dumps({'blocked':True,'reason':'Incomplete original runtime data; reference exports only.','missing':['production_times','unit_combat_stats','research_costs_and_graph','rounding','edition_runtime_verification']},ensure_ascii=False,indent=2));return 2
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (ReferenceError,KeyError,ValueError) as e:
        p.exit(2,str(e)+'\n')
if __name__=='__main__':raise SystemExit(main())
