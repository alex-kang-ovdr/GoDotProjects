#!/usr/bin/env python3
"""Deterministic 1-second network-economy laboratory, not the original game's engine.
Python 3.10+, standard library only. All timing, routing and dispatch parameters
are experimental. Inventories have PER-RESOURCE capacities. Carriers are a
shared experimental fleet (not original storehouse-bound relays/workers).
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import heapq
import json
import math
from collections import Counter
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parents[1]
SCHEMA = 'settlers7.network-lab.v20.1'


def positive(value: Any, name: str, zero: bool = False) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < (0 if zero else 1):
        raise ValueError(f'{name}: expected {"nonnegative" if zero else "positive"} integer')


def unique(rows: list[dict], name: str) -> dict:
    result = {}
    for row in rows:
        if not isinstance(row.get('id'), str) or not row['id'] or row['id'] in result:
            raise ValueError(f'{name}: missing or duplicate id')
        result[row['id']] = row
    return result


def validate(config: dict) -> None:
    if config.get('schema') != SCHEMA:
        raise ValueError('Unsupported configuration schema')
    resources = unique(config['resources'], 'resources')
    nodes = unique(config['nodes'], 'nodes')
    edges = unique(config['edges'], 'edges')
    recipes = unique(config['recipes'], 'recipes')
    stores = unique(config['stores'], 'stores')
    agents = unique(config['carriers'], 'carriers')
    sinks = unique(config.get('sinks', []), 'sinks')
    if not resources or not nodes or not stores:
        raise ValueError('Resources, nodes and stores must not be empty')
    edge_pairs = set()
    for e in edges.values():
        if e['a'] not in nodes or e['b'] not in nodes or e['a'] == e['b']:
            raise ValueError('Invalid edge endpoint')
        key = tuple(sorted((e['a'], e['b'])))
        if key in edge_pairs:
            raise ValueError('Parallel edges unsupported in v20')
        edge_pairs.add(key)
        positive(e['length'], 'edge length')
        speed = e.get('speed', 1)
        if isinstance(speed, bool) or not isinstance(speed, (int, float)) or not math.isfinite(speed) or speed <= 0:
            raise ValueError('Edge speed must be finite and positive')
        if 'open' in e and not isinstance(e['open'], bool):
            raise ValueError('Edge open must be boolean')
    for r in recipes.values():
        positive(r['seconds'], 'recipe seconds')
        if not r['outputs']:
            raise ValueError('Recipe must produce something')
        for values in (r['inputs'], r['outputs']):
            for rid, q in values.items():
                if rid not in resources:
                    raise ValueError(f'Unknown recipe resource {rid}')
                positive(q, 'recipe quantity')
    for s in stores.values():
        if s['node'] not in nodes or s['kind'] not in ('warehouse', 'workshop'):
            raise ValueError('Invalid store')
        positive(s['capacity'], 'per-resource capacity')
        for rid, q in s.get('initial', {}).items():
            if rid not in resources:
                raise ValueError(f'Unknown initial resource {rid}')
            positive(q, 'initial quantity', zero=True)
            if q > s['capacity']:
                raise ValueError('Initial stock exceeds per-resource capacity')
        if s['kind'] == 'workshop':
            if s['recipe'] not in recipes:
                raise ValueError('Unknown recipe')
            w = stores.get(s['warehouse'], {})
            if w.get('kind') != 'warehouse':
                raise ValueError('Workshop needs an existing warehouse')
            positive(s.get('buffer_cycles', 2), 'buffer cycles')
            if s.get('mode', 'always') not in ('always', 'paused', 'target_stock'):
                raise ValueError('Invalid workshop mode')
            positive(s.get('target', 6), 'target stock')
            if 'deposit' in s:
                positive(s['deposit'], 'deposit batches', zero=True)
            for amounts in (recipes[s['recipe']]['inputs'], recipes[s['recipe']]['outputs']):
                if any(q > s['capacity'] for q in amounts.values()):
                    raise ValueError('One production batch cannot fit in workshop')
    for c in agents.values():
        if c['node'] not in nodes:
            raise ValueError('Unknown carrier node')
        positive(c['capacity'], 'carrier capacity')
    for k in sinks.values():
        if k['warehouse'] not in stores or stores[k['warehouse']]['kind'] != 'warehouse' or k['resource'] not in resources:
            raise ValueError('Invalid sink')
        for field in ('quantity', 'every', 'target'):
            positive(k[field], f'sink {field}')
        positive(k.get('reserve', 0), 'sink reserve', zero=True)
    for e in config.get('events', []):
        positive(e['tick'], 'event tick', zero=True)
        if e['edge'] not in edges or not isinstance(e['open'], bool):
            raise ValueError('Invalid topology event')
    policy = config.get('policy', {})
    positive(policy.get('handling_seconds', 1), 'handling seconds')
    positive(policy.get('aging_seconds', 10), 'aging seconds')


class Graph:
    def __init__(self, nodes: list[dict], edges: list[dict]):
        self.nodes = {n['id'] for n in nodes}
        self.edges = {e['id']: dict(e, open=e.get('open', True)) for e in edges}
        self.revision = 0
        self.cache: dict[tuple, Any] = {}

    def set_open(self, edge_id: str, value: bool) -> None:
        if self.edges[edge_id]['open'] != value:
            self.edges[edge_id]['open'] = value
            self.revision += 1
            self.cache.clear()

    def route(self, a: str, b: str) -> tuple[int, list[str]] | None:
        key = (a, b, self.revision)
        if key in self.cache:
            return self.cache[key]
        adjacency = {n: [] for n in self.nodes}
        for e in self.edges.values():
            if e['open']:
                t = max(1, math.ceil(e['length'] / e.get('speed', 1)))
                adjacency[e['a']].append((e['b'], t, e['id']))
                adjacency[e['b']].append((e['a'], t, e['id']))
        heap = [(0, (), a)]
        best = {}
        while heap:
            d, path, n = heapq.heappop(heap)
            if n in best:
                continue
            best[n] = d
            if n == b:
                answer = (d, list(path))
                self.cache[key] = answer
                return answer
            for other, w, eid in sorted(adjacency[n]):
                if other not in best:
                    heapq.heappush(heap, (d + w, path + (eid,), other))
        self.cache[key] = None
        return None


class Simulation:
    def __init__(self, config: dict):
        validate(config)
        self.config = copy.deepcopy(config)
        self.resources = sorted(r['id'] for r in config['resources'])
        self.recipes = {r['id']: copy.deepcopy(r) for r in config['recipes']}
        self.graph = Graph(config['nodes'], config['edges'])
        self.time = 0
        self.stores = {}
        for s in config['stores']:
            store = copy.deepcopy(s)
            for field in ('stock', 'reserved_out', 'reserved_in', 'reserved_production'):
                store[field] = {r: 0 for r in self.resources}
            store['stock'].update(s.get('initial', {}))
            store.update(remaining=0, production_ticks=0, starved_ticks=0,
                         output_blocked_ticks=0, cycles=0, state='idle', extraction_started=0)
            self.stores[s['id']] = store
        self.carriers = []
        for c in sorted(config['carriers'], key=lambda x: x['id']):
            self.carriers.append(dict(c, job=None, cargo=None, phase='idle',
                                     edge=None, next_node=None, remaining=0, handling=0,
                                     busy_ticks=0, empty_ticks=0, loaded_ticks=0,
                                     blocked_ticks=0, completed=0))
        self.jobs: dict[str, dict] = {}
        self.next_job = 1
        self.initial = self.inventory()
        self.produced = {r: 0 for r in self.resources}
        self.consumed_production = {r: 0 for r in self.resources}
        self.consumed_sink = {r: 0 for r in self.resources}
        self.fulfilled = {s['id']: 0 for s in config.get('sinks', [])}
        self.first_delivery: dict[str, int] = {}
        self.demand_since: dict[str, int] = {}
        self.trace: list[dict] = []
        self.samples: list[dict] = []
        self.max_candidate_backlog = 0
        self.audit()

    def log(self, event_type: str, **values: Any) -> None:
        self.trace.append(dict(tick=self.time, event=event_type, **values))

    def available(self, sid: str, resource: str) -> int:
        s = self.stores[sid]
        return s['stock'][resource] - s['reserved_out'][resource]

    def free(self, sid: str, resource: str) -> int:
        s = self.stores[sid]
        return s['capacity'] - s['stock'][resource] - s['reserved_in'][resource] - s['reserved_production'][resource]

    def inventory(self) -> dict:
        result = {r: sum(s['stock'][r] for s in self.stores.values()) for r in self.resources}
        for c in getattr(self, 'carriers', []):
            if c['cargo']:
                result[c['cargo']['resource']] += c['cargo']['qty']
        return result

    def _advance_carriers(self) -> None:
        for c in self.carriers:
            if c['job'] is not None or c['edge'] is not None:
                c['busy_ticks'] += 1
            if c['edge'] is not None:
                c['loaded_ticks' if c['cargo'] else 'empty_ticks'] += 1
                c['remaining'] -= 1
                if c['remaining'] <= 0:
                    c['node'] = c['next_node']
                    c['edge'] = c['next_node'] = None
                continue
            if c['job'] is None:
                c['phase'] = 'idle'
                continue
            j = self.jobs[c['job']]
            if c['phase'] in ('to_pickup', 'to_drop'):
                target = self.stores[j['source'] if c['phase'] == 'to_pickup' else j['destination']]['node']
                if c['node'] == target:
                    c['phase'] = 'loading' if c['phase'] == 'to_pickup' else 'unloading'
                    c['handling'] = self.config.get('policy', {}).get('handling_seconds', 1)
            if c['phase'] in ('loading', 'unloading'):
                c['handling'] -= 1
                if c['handling'] > 0:
                    continue
                if c['phase'] == 'loading':
                    s = self.stores[j['source']]
                    s['stock'][j['resource']] -= j['qty']
                    s['reserved_out'][j['resource']] -= j['qty']
                    c['cargo'] = dict(resource=j['resource'], qty=j['qty'])
                    c['phase'] = 'to_drop'
                    j['status'] = 'carrying'
                    j['picked_tick'] = self.time
                    self.log('pickup', job=j['id'], source=j['source'], qty=j['qty'])
                else:
                    d = self.stores[j['destination']]
                    d['stock'][j['resource']] += j['qty']
                    d['reserved_in'][j['resource']] -= j['qty']
                    j['status'] = 'completed'
                    j['completed_tick'] = self.time
                    c['cargo'] = None
                    c['job'] = None
                    c['phase'] = 'idle'
                    c['completed'] += 1
                    self.log('dropoff', job=j['id'], destination=j['destination'], qty=j['qty'])
                continue
            target = self.stores[j['source'] if c['phase'] == 'to_pickup' else j['destination']]['node']
            route = self.graph.route(c['node'], target)
            if route is None:
                c['blocked_ticks'] += 1
                continue
            e = self.graph.edges[route[1][0]]
            c['edge'] = e['id']
            c['next_node'] = e['b'] if c['node'] == e['a'] else e['a']
            c['remaining'] = max(1, math.ceil(e['length'] / e.get('speed', 1))) - 1
            c['loaded_ticks' if c['cargo'] else 'empty_ticks'] += 1
            if c['remaining'] == 0:
                c['node'] = c['next_node']
                c['edge'] = c['next_node'] = None

    def _production(self) -> None:
        for sid, w in sorted(self.stores.items()):
            if w['kind'] != 'workshop':
                continue
            r = self.recipes[w['recipe']]
            if w['remaining'] > 0:
                w['remaining'] -= 1
                w['production_ticks'] += 1
                if w['remaining'] == 0:
                    for res, qty in r['outputs'].items():
                        w['reserved_production'][res] -= qty
                        w['stock'][res] += qty
                        self.produced[res] += qty
                    w['cycles'] += 1
                    self.log('produced', workshop=sid, recipe=r['id'], outputs=r['outputs'])
                else:
                    continue
            mode = w.get('mode', 'always')
            if mode == 'paused':
                w['state'] = 'paused'
                continue
            if mode == 'target_stock' and all(
                w['stock'][res] + self.stores[w['warehouse']]['stock'][res]
                + self.stores[w['warehouse']]['reserved_in'][res] >= w.get('target', 6)
                for res in r['outputs']
            ):
                w['state'] = 'target_reached'
                continue
            if not r['inputs'] and w.get('deposit', 1) == 0:
                w['state'] = 'depleted'
                continue
            if not all(self.free(sid, res) >= qty for res, qty in r['outputs'].items()):
                w['state'] = 'output_blocked'
                w['output_blocked_ticks'] += 1
                continue
            if not all(self.available(sid, res) >= qty for res, qty in r['inputs'].items()):
                w['state'] = 'starved'
                w['starved_ticks'] += 1
                continue
            # All inputs and output slots are checked before changing any account.
            for res, qty in r['inputs'].items():
                w['stock'][res] -= qty
                self.consumed_production[res] += qty
            for res, qty in r['outputs'].items():
                w['reserved_production'][res] += qty
            if not r['inputs'] and 'deposit' in w:
                w['deposit'] -= 1
                w['extraction_started'] += 1
            w['remaining'] = r['seconds']
            w['state'] = 'producing'

    def _sinks(self) -> None:
        for s in sorted(self.config.get('sinks', []), key=lambda x: x['id']):
            if self.time % s['every']:
                continue
            n = min(s['quantity'], max(0, self.available(s['warehouse'], s['resource']) - s.get('reserve', 0)))
            if n:
                self.stores[s['warehouse']]['stock'][s['resource']] -= n
                self.consumed_sink[s['resource']] += n
                self.fulfilled[s['id']] += n
                self.first_delivery.setdefault(s['id'], self.time)
                self.log('sink_delivery', sink=s['id'], resource=s['resource'], qty=n)

    def candidates(self) -> list[dict]:
        result = []
        warehouses = [s for s in self.stores.values() if s['kind'] == 'warehouse']
        targets: dict[tuple[str, str], int] = Counter()

        def add(kind: str, src: str, dst: str, res: str, need: int, priority: int) -> None:
            qty = min(need, self.available(src, res), self.free(dst, res))
            if qty <= 0:
                return
            route = self.graph.route(self.stores[src]['node'], self.stores[dst]['node'])
            if route is None:
                return
            key = f'{kind}|{src}|{dst}|{res}'
            result.append(dict(key=key, kind=kind, source=src, destination=dst,
                               resource=res, qty=qty, priority=priority, loaded_distance=route[0]))

        for sid, w in sorted(self.stores.items()):
            if w['kind'] != 'workshop':
                continue
            r = self.recipes[w['recipe']]
            wh = w['warehouse']
            for res in r['outputs']:
                add('output', sid, wh, res, self.available(sid, res), 80)
            if w.get('mode', 'always') == 'paused':
                continue
            for res, qty in r['inputs'].items():
                desired = min(w['capacity'], qty * w.get('buffer_cycles', 2))
                shortage = max(0, desired - w['stock'][res] - w['reserved_in'][res])
                targets[(wh, res)] += shortage
                add('input', wh, sid, res, shortage, 70)
        for s in self.config.get('sinks', []):
            targets[(s['warehouse'], s['resource'])] += s['target']
        for (dest, res), target in sorted(targets.items()):
            target = min(target, self.stores[dest]['capacity'])
            need = max(0, target - self.available(dest, res) - self.stores[dest]['reserved_in'][res])
            # Carriers pick one supplier per request, based on reachable road distance.
            suppliers = []
            for source in warehouses:
                if source['id'] == dest or self.available(source['id'], res) <= 0:
                    continue
                path = self.graph.route(source['node'], self.stores[dest]['node'])
                if path:
                    suppliers.append((path[0], source['id']))
            if suppliers and need:
                add('transfer', min(suppliers)[1], dest, res, need, 65)
        return result

    def _dispatch(self) -> None:
        initial = self.candidates()
        keys = {j['key'] for j in initial}
        self.demand_since = {k: t for k, t in self.demand_since.items() if k in keys}
        for j in initial:
            self.demand_since.setdefault(j['key'], self.time)
        self.max_candidate_backlog = max(self.max_candidate_backlog, len(initial))
        aging = self.config.get('policy', {}).get('aging_seconds', 10)
        for c in self.carriers:
            if c['job'] is not None or c['edge'] is not None:
                continue
            scored = []
            for j in self.candidates():
                empty = self.graph.route(c['node'], self.stores[j['source']]['node'])
                if empty is None:
                    continue
                age = self.time - self.demand_since.setdefault(j['key'], self.time)
                # Aging is intentionally unbounded; distance has a small tie-break weight.
                score = j['priority'] + age / aging - (empty[0] + j['loaded_distance']) * 0.1
                scored.append((-score, empty[0] + j['loaded_distance'], j['key'], j))
            if not scored:
                continue
            candidate = min(scored, key=lambda x: x[:3])[3]
            q = min(c['capacity'], candidate['qty'])
            jid = f'j{self.next_job:07d}'
            self.next_job += 1
            job = dict(candidate, id=jid, qty=q, status='assigned',
                       assigned_tick=self.time, carrier=c['id'])
            self.jobs[jid] = job
            self.stores[job['source']]['reserved_out'][job['resource']] += q
            self.stores[job['destination']]['reserved_in'][job['resource']] += q
            c['job'] = jid
            c['phase'] = 'to_pickup'
            self.demand_since.pop(candidate['key'], None)
            self.log('assigned', job=jid, kind=job['kind'], resource=job['resource'], qty=q,
                     source=job['source'], destination=job['destination'], carrier=c['id'])

    def cancel_unpicked(self, job_id: str) -> bool:
        j = self.jobs[job_id]
        if j['status'] != 'assigned':
            return False  # Loaded cargo is never erased/refunded by cancellation.
        c = next(c for c in self.carriers if c['job'] == job_id)
        self.stores[j['source']]['reserved_out'][j['resource']] -= j['qty']
        self.stores[j['destination']]['reserved_in'][j['resource']] -= j['qty']
        j['status'] = 'cancelled'
        j['cancelled_tick'] = self.time
        c['job'] = None
        c['phase'] = 'idle'
        c['handling'] = 0
        # An occupied edge still finishes at its next node; no position teleport.
        self.log('cancelled', job=job_id)
        self.audit()
        return True

    def audit(self) -> None:
        expected_out = {sid: Counter() for sid in self.stores}
        expected_in = {sid: Counter() for sid in self.stores}
        for j in self.jobs.values():
            if j['status'] in ('assigned', 'carrying'):
                expected_in[j['destination']][j['resource']] += j['qty']
                if j['status'] == 'assigned':
                    expected_out[j['source']][j['resource']] += j['qty']
        for sid, s in self.stores.items():
            r = self.recipes[s['recipe']] if s['kind'] == 'workshop' else None
            for res in self.resources:
                vals = [s[k][res] for k in ('stock', 'reserved_out', 'reserved_in', 'reserved_production')]
                if any(not isinstance(v, int) or v < 0 for v in vals):
                    raise AssertionError(f'Negative/noninteger account: {sid}/{res}')
                if s['reserved_out'][res] > s['stock'][res] or self.free(sid, res) < 0:
                    raise AssertionError(f'Over-reservation/capacity: {sid}/{res}')
                if s['reserved_out'][res] != expected_out[sid][res] or s['reserved_in'][res] != expected_in[sid][res]:
                    raise AssertionError(f'Reservation ledger mismatch: {sid}/{res}')
                promised = r['outputs'].get(res, 0) if r and s['remaining'] > 0 else 0
                if s['reserved_production'][res] != promised:
                    raise AssertionError('Production capacity reservation mismatch')
        active = [c['job'] for c in self.carriers if c['job'] is not None]
        jobs_active = {j['id'] for j in self.jobs.values() if j['status'] in ('assigned', 'carrying')}
        if len(active) != len(set(active)) or set(active) != jobs_active:
            raise AssertionError('Job assignment mismatch')
        for c in self.carriers:
            if c['cargo']:
                if c['job'] is None:
                    raise AssertionError('Orphan cargo')
                j = self.jobs[c['job']]
                if j['status'] != 'carrying' or c['cargo'] != dict(resource=j['resource'], qty=j['qty']):
                    raise AssertionError('Cargo/job mismatch')
                if c['cargo']['qty'] > c['capacity']:
                    raise AssertionError('Carrier overloaded')
            elif c['job'] and self.jobs[c['job']]['status'] == 'carrying':
                raise AssertionError('Missing cargo')
        if hasattr(self, 'produced'):
            current = self.inventory()
            for res in self.resources:
                expected = self.initial[res] + self.produced[res] - self.consumed_production[res] - self.consumed_sink[res]
                if current[res] != expected:
                    raise AssertionError(f'Conservation failed: {res}: {current[res]} != {expected}')

    def step(self) -> None:
        for e in self.config.get('events', []):
            if e['tick'] == self.time:
                self.graph.set_open(e['edge'], e['open'])
                self.log('topology', edge=e['edge'], open=e['open'], revision=self.graph.revision)
        self._advance_carriers()
        self._production()
        self._sinks()
        self._dispatch()
        self.audit()
        self.time += 1
        if self.time % 60 == 0:
            self.samples.append(dict(tick=self.time, fulfilled=copy.deepcopy(self.fulfilled),
                                     in_transit=sum(c['cargo']['qty'] for c in self.carriers if c['cargo']),
                                     production=copy.deepcopy(self.produced)))

    def run(self, seconds: int) -> dict:
        positive(seconds, 'simulation seconds', zero=True)
        for _ in range(seconds):
            self.step()
        return self.report()

    def report(self) -> dict:
        self.audit()
        elapsed = max(1, self.time)
        done = [j for j in self.jobs.values() if j['status'] == 'completed']
        latencies = sorted(j['completed_tick'] - j['assigned_tick'] for j in done)
        p95 = latencies[max(0, math.ceil(.95 * len(latencies)) - 1)] if latencies else None
        ws = {sid: dict(recipe=w['recipe'], cycles=w['cycles'], state=w['state'],
                        utilization=round(w['production_ticks']/elapsed, 6),
                        starved_seconds=w['starved_ticks'], output_blocked_seconds=w['output_blocked_ticks'])
              for sid, w in sorted(self.stores.items()) if w['kind'] == 'workshop'}
        return dict(schema=SCHEMA, scenario=self.config.get('id', 'custom'), seconds=self.time,
                    carrier_count=len(self.carriers), fulfilled=copy.deepcopy(self.fulfilled),
                    throughput_per_min={k: round(v*60/elapsed, 4) for k, v in self.fulfilled.items()},
                    first_delivery_tick=copy.deepcopy(self.first_delivery),
                    produced=copy.deepcopy(self.produced), inventory=self.inventory(),
                    carrier_busy_ratio=round(sum(c['busy_ticks'] for c in self.carriers)/max(1, elapsed*len(self.carriers)), 6),
                    empty_travel_seconds=sum(c['empty_ticks'] for c in self.carriers),
                    loaded_travel_seconds=sum(c['loaded_ticks'] for c in self.carriers),
                    blocked_carrier_seconds=sum(c['blocked_ticks'] for c in self.carriers),
                    completed_jobs=len(done), active_jobs=sum(j['status'] in ('assigned','carrying') for j in self.jobs.values()),
                    completed_job_latency_p95_seconds=p95, max_dispatchable_backlog=self.max_candidate_backlog,
                    inventory_balance_error={r: 0 for r in self.resources}, workshops=ws,
                    state_sha256=self.digest())

    def snapshot(self) -> dict:
        return copy.deepcopy(dict(schema=SCHEMA, config=self.config, time=self.time,
            stores=self.stores, carriers=self.carriers, jobs=self.jobs, next_job=self.next_job,
            initial=self.initial, produced=self.produced, consumed_production=self.consumed_production,
            consumed_sink=self.consumed_sink, fulfilled=self.fulfilled, first_delivery=self.first_delivery,
            demand_since=self.demand_since, trace=self.trace, samples=self.samples,
            max_candidate_backlog=self.max_candidate_backlog,
            graph_edges=self.graph.edges, graph_revision=self.graph.revision))

    @classmethod
    def restore(cls, snapshot: dict) -> Simulation:
        if snapshot.get('schema') != SCHEMA:
            raise ValueError('Unsupported save schema')
        s = cls(snapshot['config'])
        if set(snapshot) != set(s.snapshot()):
            raise ValueError('Save fields do not match the versioned contract')
        for key, value in snapshot.items():
            if key not in ('schema', 'config', 'graph_edges', 'graph_revision'):
                if not hasattr(s, key):
                    raise ValueError(f'Unexpected save field {key}')
                setattr(s, key, copy.deepcopy(value))
        s.graph.edges = copy.deepcopy(snapshot['graph_edges'])
        s.graph.revision = snapshot['graph_revision']
        s.graph.cache.clear()
        s.audit()
        return s

    def digest(self) -> str:
        raw = json.dumps(self.snapshot(), sort_keys=True, separators=(',', ':'), ensure_ascii=False)
        return hashlib.sha256(raw.encode()).hexdigest()


def load_config(path: str | Path | None = None) -> dict:
    return json.loads(Path(path or HERE/'data'/'baseline.json').read_text(encoding='utf-8'))


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', type=Path, default=HERE/'data'/'baseline.json')
    p.add_argument('--seconds', type=int, default=1200)
    p.add_argument('--output', type=Path)
    p.add_argument('--save', type=Path)
    p.add_argument('--resume', type=Path)
    args = p.parse_args()
    try:
        sim = Simulation.restore(json.loads(args.resume.read_text(encoding='utf-8'))) if args.resume else Simulation(load_config(args.config))
        report = sim.run(args.seconds)
        text = json.dumps(report, ensure_ascii=False, indent=2)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(text+'\n', encoding='utf-8')
        else:
            print(text)
        if args.save:
            args.save.parent.mkdir(parents=True, exist_ok=True)
            args.save.write_text(json.dumps(sim.snapshot(), ensure_ascii=False), encoding='utf-8')
    except (ValueError, KeyError, OSError) as exc:
        p.exit(2, f'Configuration/save error: {exc}\n')

if __name__ == '__main__':
    main()
