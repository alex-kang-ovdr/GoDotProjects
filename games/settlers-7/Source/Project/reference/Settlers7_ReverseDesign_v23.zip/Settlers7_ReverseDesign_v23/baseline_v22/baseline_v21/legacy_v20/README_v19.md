# Settlers 7 역기획 v19

v18 전체 자료 보존 + 92~96 문서와 경제 시뮬레이션 코드 추가.

실행:
```bash
python tools/economy_sim_v19.py --recipe bake_bread --seconds 600 --carriers 2 --workshops 2 --travel 5 --initial 100
python tools/test_v19.py
```

**범위**: 단일 레시피, 단일 창고, 운반자 1화물, 고정 운송 시간. 브라우저 게임과 연결되지 않음. 레시피 수치는 원작 실측이 아닌 prototype 데이터.
