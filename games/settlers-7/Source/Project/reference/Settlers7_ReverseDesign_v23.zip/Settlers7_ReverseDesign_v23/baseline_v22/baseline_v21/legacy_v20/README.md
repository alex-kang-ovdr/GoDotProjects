# The Settlers 7 역기획 v20
## 원작 근거 정정 + 공간 경제망 실험

**v20은 기획·데이터·Python 검증 도구 고도화다. 새 전략 게임 버전이 아니다.**

### 먼저 읽기
- `START_HERE_v20.md`: 변경 요약과 실행 방법
- `97_Fidelity_Corrections_v20.md`: 원작 근거와 기존 단순화의 정정
- `98_Network_Logistics_Contract_v20.md`: 구현된 알고리즘·장부·예외 계약
- `99_Experiment_Results_v20.md`: 10종 실제 실험 결과 및 해석
- `100_Playable_Slice_and_UI_v20.md`: 향후 게임 통합·UX 상세 기획
- `101_QA_and_Release_Audit_v20.md`: 실제 40개 테스트와 남은 검증 범위

### 실행
압축을 해제하고 이 README가 있는 폴더에서 실행한다. Python 3.10 이상 문법을 사용하며 실행 검증 환경은 `v20/reports/test_results.json`에 기록한다. 표준 라이브러리만 사용하므로 추가 패키지 설치는 없다.

```bash
python v20/tools/run_tests.py
python v20/tools/run_experiments.py
python v20/tools/network_sim.py --seconds 1200 --output my_result.json
```

Windows에서 `python` 명령이 없고 Python Launcher가 설치되어 있으면 같은 명령의 `python`을 `py -3`으로 바꾼다.

```bash
python v20/tools/network_sim.py --seconds 300 --save save.json
python v20/tools/network_sim.py --resume save.json --seconds 900 --output resumed_result.json
```

### 브라우저로 읽기 / 이전 게임
`v20/report.html`은 새 실험 결과를 읽는 오프라인 보고서다. 외부 라이브러리·네트워크 요청이 없다. 새 실험을 실행한 뒤 HTML은 자동 재생성되지 않으므로 최신 결과는 CSV/JSON을 확인한다.

`prototype/index.html`은 v17 ZIP에서 복구한 **기존 v12 계열 게임**이다. v20 경제 분석기와 별개이며 게임 코드를 변경하지 않았다. Python 도구가 게임을 자동으로 실행하거나 세이브를 이식하지 않는다.

### 정본 우선순위
v20 실험 값은 `v20/data/*.json`, 현재 구현 상태는 `implementation_matrix.csv`, 원작 근거는 `evidence_registry.csv`가 우선한다. 01~96번 문서와 이전 CSV는 이력 자료이다. 원작 확인 범위와 실험용 수치를 섞지 않는다.
