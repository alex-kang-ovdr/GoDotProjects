# 4. 후속 연구판·협동·지도 데이터

## 오컬트 연구판
2010-12-07 Steam 공지는 The Occult Science의6기술을 설명한다. 기본18기술과 합치면 카탈로그 명칭24개가 되지만 한 판에서 동시에24개를 연구할 수 있다는 뜻이 아니다.

| 기술 | 문헌 효과 | 남은 미확인 |
|---|---|---|
| Necromancy | 전사 병력이 일시적으로 돌아옴 | 유지시간·대상·중복 처치 집계 |
| Evil Eye | 포교 성직자 요구 감소 | 감소율·정수화 |
| Deal with the Devil | 병력 처치에 코인 보상 | 보상량·처치 필터 |
| Demonic Bargaining | 항구/시장의 의복·장신구 판매 코인 증가 | 증가량·합성 |
| Dark Aura | 진영 성직자 효과 +5% | 5%p와 상대5%의 구별 |
| Hidden Persuasion | 항구/시장의 거래마다10% 무대가 획득 가능성 | 난수·추첨 단위·절차 |

The Pentacle 교역판 이름도 확인하지만 교역소 배치·연결·비용은 null이다. 모든 오컬트 기술의 연구비·시간·선행 연결은 미확인이다.

## 협동 모드와 과거 동맹은 분리
1.12 협동 모드에서는 기술·교역소·VP·VP 산정 수치가 팀에 공유된다. 영토 기부와 자원/상품 보내기도 제공된다. '자원을 보낼 수 있다'를 '모든 창고 재고가 자동 공동 장부'로 바꾸지 않는다. 배송 시간·수단·실패 정책은 미확인이다. 이전 캠페인 공략의 비공유 문장은 그 문맥으로만 보존한다.

동맹 지도 표시는CTRL+좌클릭이며 중립/적 지역에 표시를 놓으면 아군AI의 공격 가능성이 증가하고 반복 표시가 효과를 키운다. 정확한 가중치는 공개되지 않아 수치화하지 않았다.

## 새 승리 포인트
1.10 공지의 지급 버그 수정으로 Pacifist와 Ascetic의 존재를 확인했다. 언제 처음 도입되었는지, 정적/동적인지, 임계값·경과시간·점수·상실 조건은 이 공지로 확정할 수 없다. 기존14개 명칭+신규2개=16개 명칭 레코드이며 Abbey/Bishop’s See 중복 후보가 있으므로 독립16종 완전복원이라고 쓰지 않는다.

## 지도 범위
1.05·1.07·1.09·1.12는 캠페인 지도를 스커미시/멀티플레이에 맞게 바꾼 콘텐츠를 명시한다. 같은 지명이어도 원본 캠페인의 시작 재고·이벤트·VP 요구를 그대로 복사하지 않는다. map_revisions에는 도입/수정16개 레코드가 있으며 중복 지명을 포함하므로16개 고유 지도라는 뜻이 아니다. 지형 좌표·자원 배치·진영 연결은 미복원이다.

- [OCCULT] Steam product update — Occult Science — https://store.steampowered.com/oldnews/4743
- [P112] Steam product update — Version 1.12 — https://store.steampowered.com/oldnews/5383
- [P110] Steam product update — Version 1.10 — https://store.steampowered.com/oldnews/4392
- [P109] Steam product update — Version 1.09 — https://store.steampowered.com/oldnews/4288
- [P105] Steam product update — Version 1.05 — https://store.steampowered.com/oldnews/3911