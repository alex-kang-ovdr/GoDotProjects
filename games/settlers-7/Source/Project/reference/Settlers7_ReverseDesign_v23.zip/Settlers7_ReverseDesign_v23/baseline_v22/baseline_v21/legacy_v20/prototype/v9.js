// v9: Shared capital inventory and sector-specific workshop simulation.
// Original prototype rules, not verified Settlers 7 source mechanics.
(() => {
'use strict';
window.SETTLERS_V9=true;
const TYPES={wood:{name:'벌목소',out:'wood',input:{},time:7},stone:{name:'채석장',out:'stone',input:{},time:9},farm:{name:'농장',out:'grain',input:{},time:8},saw:{name:'제재소',out:'plank',input:{wood:1},time:11},mill:{name:'제분소',out:'flour',input:{grain:1},time:12},bakery:{name:'제빵소',out:'bread',input:{flour:1},time:13}};
const LABEL={wood:'원목',stone:'석재',plank:'판자',grain:'곡물',flour:'밀가루',bread:'빵'};
let nextWorkshopId=0,completed9=0,produced9={};
const previousInit=init,previousRestore=restore,previousTick=tick,previousRender=render,previousSnapshot=snapshot,previousTests=tests;
function linkCapital(){if(!Array.isArray(sectors8)||!sectors8[0])return;const old=sectors8[0].inventory; // Capital is one inventory, not two copies.
 sectors8[0].inventory=stock;
 if(!sectors8[0].buildings)sectors8[0].buildings=[];
}
function initialize9(){nextWorkshopId=0;completed9=0;produced9={};linkCapital();for(const s of sectors8){s.buildings=s.buildings||[];s.progress=0}}
function createWorkshop(i,kind){const s=sectors8[i],spec=TYPES[kind];if(!spec||kingdom.sectors[i]!==0)return log('내 영토만 작업장을 건설할 수 있습니다');if(i===0)return log('수도 작업장은 왼쪽 타일 지도에서 본관에 부착하세요');if(s.buildings.length>=12)return log('지역 작업장 한도 12개');const cost={wood:2,stone:1};if(!Object.entries(cost).every(([r,n])=>(s.inventory[r]||0)>=n))return log('지역 건설 재료 부족 (원목2·석재1)');for(const [r,n] of Object.entries(cost))s.inventory[r]-=n;s.buildings.push({id:++nextWorkshopId,type:kind,progress:0,produced:0,blocked:false});log(`${SECTOR_NAMES[i]}: ${spec.name} 건설`);render()}
function production9(dt){for(const s of sectors8){if(s.id===0||kingdom.sectors[s.id]!==0)continue;for(const b of s.buildings){const def=TYPES[b.type];if(!def)continue;const available=Object.entries(def.input).every(([r,n])=>(s.inventory[r]||0)>=n);b.blocked=!available;if(!available)continue;b.progress+=dt;while(b.progress>=def.time&&Object.entries(def.input).every(([r,n])=>(s.inventory[r]||0)>=n)){b.progress-=def.time;for(const [r,n] of Object.entries(def.input))s.inventory[r]-=n;s.inventory[def.out]=(s.inventory[def.out]||0)+1;b.produced++;completed9++;produced9[def.out]=(produced9[def.out]||0)+1}}}}
function repairTransit(){// Cancel shipments that cannot arrive, restoring cargo to origin if it still belongs to player.
 const remaining=[];for(const c of caravans){if(kingdom.sectors[c.to]!==0&&kingdom.sectors[c.from]===0){sectors8[c.from].inventory[c.item]=(sectors8[c.from].inventory[c.item]||0)+c.qty;log('영토 상실로 운송 취소: 화물 출발지 반환')}else remaining.push(c)}caravans=remaining}
init=function(){previousInit();initialize9()};
restore=function(data){previousRestore(data?.version===9?{...data,version:8}:data);if(data?.version===9){for(let i=0;i<6;i++)sectors8[i].buildings=data.sectors8?.[i]?.buildings||[];nextWorkshopId=data.nextWorkshopId||0;completed9=data.completed9||0;produced9=data.produced9||{}}linkCapital()};
tick=function(dt){repairTransit();previousTick(dt);production9(dt)};
snapshot=function(){return {...previousSnapshot(),version:9,nextWorkshopId,completed9,produced9}};
const panel=document.createElement('section');panel.className='panel';panel.style.marginTop='12px';panel.id='v9panel';document.querySelector('aside.panel').appendChild(panel);
function render9(){linkCapital();const s=sectors8[selected8];if(!s)return;const capital=selected8===0;const own=kingdom.sectors[selected8]===0;const buildings=s.buildings||[];
 panel.innerHTML=`<h3>v9 · 통합 경제 및 작업장</h3><div class="pill">${SECTOR_NAMES[selected8]} · ${capital?'수도: 타일 물류 창고와 재고 공유':'지역 독립 재고'} · 작업장 ${buildings.length}</div><p class="hint">수도 재고는 상단 창고 재고와 동일한 객체입니다. 다른 지역은 운송대로 연결하며, 각 지역의 생산 작업장은 해당 지역 재고만 사용합니다.</p><label>지역 작업장 <select id="v9kind">${Object.entries(TYPES).map(([k,v])=>`<option value="${k}">${v.name}</option>`).join('')}</select></label><button id="v9build" ${own&&!capital?'':'disabled'}>작업장 건설 (원목2·석재1)</button><div class="pill">누적 지역 생산 ${completed9}회 · ${Object.entries(produced9).map(([r,n])=>`${LABEL[r]} ${n}`).join(' / ')||'없음'}</div><div style="max-height:180px;overflow:auto">${buildings.map(b=>{const d=TYPES[b.type];return `<div class="pill" style="margin:4px 0">${d?.name||b.type} · ${b.blocked?'원료 부족':'생산 중'} · ${Math.round(100*b.progress/(d?.time||1))}% · 누적 ${b.produced||0}</div>`}).join('')}</div>`;
 panel.querySelector('#v9build').onclick=()=>createWorkshop(selected8,panel.querySelector('#v9kind').value);
}
render=function(){previousRender();render9()};
tests=function(){previousTests();const checks=[['수도 재고 단일 원장',sectors8[0].inventory===stock],['지역 작업장 생산 정의',sectors8.every(s=>(s.buildings||[]).every(b=>!!TYPES[b.type]))],['재고 음수 없음',sectors8.every(s=>Object.values(s.inventory).every(v=>Number.isFinite(v)&&v>=0))],['운송 화물 양수',caravans.every(c=>c.qty>0)],['v9 저장 직렬화',!!JSON.stringify(snapshot())]];document.getElementById('tests').innerHTML+=checks.map(([n,ok])=>`<div>${ok?'✅':'❌'} ${n}</div>`).join('')};
document.getElementById('save').onclick=()=>{localStorage.setItem('settlers7_v9',JSON.stringify(snapshot()));log('v9 저장 완료');render()};
document.getElementById('load').onclick=()=>{try{let d=localStorage.getItem('settlers7_v9');if(!d)throw Error('v9 저장 없음');restore(JSON.parse(d));log('v9 불러오기 완료')}catch(e){log('불러오기 실패: '+e.message)}render()};
document.getElementById('reset').onclick=()=>{init();render()};document.getElementById('test').onclick=tests;
initialize9();render();
})();
