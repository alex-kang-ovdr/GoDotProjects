// v7: Strategy-map simulation layer. Prototype balance, not verified original values.
(() => {
'use strict';
const board=document.getElementById('regions'),g=board.getContext('2d');
const coords=[[240,145],[110,75],[367,75],[240,245],[75,218],[407,218]];
const colors=['#68b98a','#d56d64','#d8c69e'];
let expeditions=[], discovered=new Set([0,1,2,3]), notices=[], expeditionId=0, lastTick=clock;
const oldTake=takeSector,oldTickV7=tick,oldRenderV7=render,oldInitV7=init,oldSnapshotV7=snapshot,oldRestoreV7=restore,oldEnemyV7=enemyAI,oldTestsV7=tests;
function resetV7(){expeditions=[];discovered=new Set([0,1,2,3]);notices=[];expeditionId=0;lastTick=clock;}
function sourceFor(s,owner){return SECTOR_NEIGHBORS[s].find(n=>kingdom.sectors[n]===owner)}
function issue(s,method){
 if(kingdom.winner||s<1||s>5||kingdom.sectors[s]===0){log('해당 지역에 원정을 보낼 수 없습니다');return}
 if(expeditions.some(e=>e.to===s&&e.owner===0)){log('이미 해당 지역으로 원정 중입니다');return}
 const from=sourceFor(s,0);if(from===undefined){log('인접한 소유 지역이 없습니다');return}
 const d=kingdom.defenders[s],old=kingdom.sectors[s];
 if(method==='army'&&kingdom.army+(hasTech('tools')?1:0)<=d){log('공격 전력 부족');return}
 if(method==='trade'&&kingdom.coins<8+(old===1?4:0)-(hasTech('commerce')?2:0)){log('교역 자금 부족');return}
 if(method==='faith'&&kingdom.clergy<3+(old===1?1:0)-(hasTech('faith')?1:0)){log('성직자 부족');return}
 const distance=Math.hypot(coords[s][0]-coords[from][0],coords[s][1]-coords[from][1]);
 expeditions.push({id:++expeditionId,from,to:s,owner:0,method,progress:0,duration:Math.max(6,distance/15),started:clock});
 discovered.add(s);log(`${SECTOR_NAMES[s]}: ${method==='army'?'군대':method==='trade'?'상단':'성직자'} 출발`);
}
takeSector=function(s,method){issue(s,method);render()};
function complete(e){
 if(kingdom.sectors[e.from]!==e.owner){log('원정 출발지 상실로 원정 취소');return}
 if(e.owner===0){
  if(kingdom.sectors[e.to]===0){log('이미 확보한 지역: 원정 취소');return}
  // Revalidate on arrival: another expedition or AI may have changed the world.
  oldTake(e.to,e.method);
 }else if(kingdom.sectors[e.to]!==1){
  kingdom.sectors[e.to]=1;kingdom.aiTurn++;recount();log(`상대 원정대가 ${SECTOR_NAMES[e.to]} 점령`);
 }
 discovered.add(e.to);for(const n of SECTOR_NEIGHBORS[e.to])discovered.add(n);
 notices.push({s:e.to,age:0,owner:e.owner});
}
tick=function(dt){
 oldTickV7(dt);
 for(const e of expeditions)e.progress+=dt/e.duration;
 const done=expeditions.filter(e=>e.progress>=1);expeditions=expeditions.filter(e=>e.progress<1);
 for(const e of done)complete(e);
 for(const n of notices)n.age+=dt;notices=notices.filter(n=>n.age<3);
};
// Enemy launches expeditions rather than instantly claiming territory.
enemyAI=function(){
 if(kingdom.winner||expeditions.some(e=>e.owner===1))return;
 const targets=kingdom.sectors.map((v,i)=>({v,i})).filter(o=>o.i!==0&&o.v!==1&&sourceFor(o.i,1)!==undefined);
 if(!kingdom.sectors.includes(1)){
  // Initial AI foothold is predesignated, matching v6's simplified opponent setup.
  kingdom.sectors[5]=1;kingdom.aiTurn++;discovered.add(5);log('상대 AI가 수도원 고지에 거점을 확보');recount();return;
 }
 if(!targets.length){kingdom.enemyArmy++;log('상대 AI가 병력을 증강');return}
 const target=targets.sort((a,b)=>a.v-b.v||a.i-b.i)[0].i,from=sourceFor(target,1);
 expeditions.push({id:++expeditionId,from,to:target,owner:1,method:'army',progress:0,duration:12,started:clock});
 log(`상대 원정대 출발: ${SECTOR_NAMES[target]}`);
};
function drawBoard(){
 g.clearRect(0,0,480,290);g.fillStyle='#213a31';g.fillRect(0,0,480,290);
 g.lineWidth=4;g.strokeStyle='#7e977e';
 for(let s=0;s<6;s++)for(const n of SECTOR_NEIGHBORS[s])if(n>s){g.beginPath();g.moveTo(...coords[s]);g.lineTo(...coords[n]);g.stroke()}
 for(let s=0;s<6;s++){
  const [x,y]=coords[s],known=discovered.has(s),owner=kingdom.sectors[s];
  g.beginPath();g.arc(x,y,31,0,Math.PI*2);g.fillStyle=known?colors[owner===0?0:owner===1?1:2]:'#3c4b46';g.fill();
  g.lineWidth=2;g.strokeStyle='#e4dcb6';g.stroke();g.fillStyle='#182a23';g.textAlign='center';g.font='bold 14px sans-serif';g.fillText(known?String(s+1):'?',x,y+5);
  g.font='12px sans-serif';g.fillStyle='#f3e6c4';g.fillText(known?SECTOR_NAMES[s]:'미탐색',x,y+47);
  for(const n of notices.filter(n=>n.s===s)){g.strokeStyle='#ffe09a';g.lineWidth=4-n.age;g.beginPath();g.arc(x,y,33+n.age*8,0,Math.PI*2);g.stroke()}
 }
 for(const e of expeditions){const a=coords[e.from],b=coords[e.to],x=a[0]+(b[0]-a[0])*e.progress,y=a[1]+(b[1]-a[1])*e.progress;g.beginPath();g.arc(x,y,8,0,Math.PI*2);g.fillStyle=e.owner===0?'#ffdf75':'#fa8076';g.fill();g.strokeStyle='#1e3028';g.lineWidth=2;g.stroke();g.font='13px sans-serif';g.fillText(e.method==='army'?'⚔':e.method==='trade'?'◆':'✦',x,y-12)}
}
render=function(){oldRenderV7();drawBoard();document.getElementById('expeditionStatus').textContent=expeditions.length?expeditions.map(e=>`${e.owner===0?'아군':'적군'} ${SECTOR_NAMES[e.to]} ${Math.round(e.progress*100)}%`).join(' · '):'진행 중인 원정 없음 · 아래 영토 버튼 또는 지도 클릭으로 출정';};
board.addEventListener('click',ev=>{const r=board.getBoundingClientRect(),x=(ev.clientX-r.left)/r.width*480,y=(ev.clientY-r.top)/r.height*290;let s=coords.findIndex(([a,b])=>Math.hypot(x-a,y-b)<32);if(s<0)return;selectedSector=s;const owned=kingdom.sectors[s];if(owned===0){log(`${SECTOR_NAMES[s]}: 내 영토`);render();return}if(!adjacentOwned(s,0)){log('인접한 내 영토가 없어 원정을 보낼 수 없습니다');render();return}issue(s,document.getElementById('v7Method').value);render()});
let selectedSector=0;
const method=document.createElement('div');method.innerHTML='<label>지도 클릭 원정 방식 <select id="v7Method"><option value="army">군사</option><option value="trade">무역</option><option value="faith">포교</option></select></label><small> · 원정대는 이동 시간이 필요합니다. 이동 중에도 경제 생산은 계속됩니다.</small>';
board.insertAdjacentElement('afterend',method);
init=function(){oldInitV7();resetV7()};
snapshot=function(){return {...oldSnapshotV7(),version:7,expeditions,discovered:[...discovered],notices,expeditionId}};
restore=function(s){if(!s||![6,7].includes(s.version))throw Error('v6/v7 저장만 지원합니다');oldRestoreV7({...s,version:6});expeditions=Array.isArray(s.expeditions)?s.expeditions:[];discovered=new Set(s.discovered||[0,1,2,3]);notices=Array.isArray(s.notices)?s.notices:[];expeditionId=s.expeditionId||0;};
tests=function(){oldTestsV7();const result=[['원정 목적지 유효성',expeditions.every(e=>e.to>=1&&e.to<6)],['원정 진행률 유효성',expeditions.every(e=>e.progress>=0&&e.progress<1)],['탐색 영역 유효성',[...discovered].every(s=>s>=0&&s<6)],['전략 맵 연결 대칭성',SECTOR_NEIGHBORS.every((ns,i)=>ns.every(n=>SECTOR_NEIGHBORS[n].includes(i)))]];document.querySelector('#tests').innerHTML+=result.map(([n,ok])=>`<div>${ok?'✅':'❌'} ${n}</div>`).join('')};
// Replace old v6 save/load handlers: v7 uses a separate storage key.
document.getElementById('save').onclick=()=>{localStorage.setItem('settlers7_v7',JSON.stringify(snapshot()));log('v7 저장 완료');render()};
document.getElementById('load').onclick=()=>{try{const data=localStorage.getItem('settlers7_v7')||localStorage.getItem('settlers7_v5');restore(JSON.parse(data));log('불러오기 완료')}catch(e){log('불러오기 실패: '+e.message)}render()};
document.getElementById('reset').onclick=()=>{init();render()};document.getElementById('test').onclick=tests;
// A v6 timer already runs every 100ms and calls the redefined tick/render functions.
resetV7();render();
})();
