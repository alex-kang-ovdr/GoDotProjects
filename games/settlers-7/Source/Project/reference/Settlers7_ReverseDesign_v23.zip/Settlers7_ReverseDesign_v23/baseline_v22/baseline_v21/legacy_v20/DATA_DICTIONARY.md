# 데이터 사전 v3

모든 CSV의 `source_status`는 원작 확인 여부를 뜻한다. `prototype`은 임의 테스트 값이며 원작 수치로 인용하면 안 된다. `reconstructed`는 공개 설명을 기반으로 한 구조적 재구성으로, 건물별 조합은 확인이 필요하다.

- `building_definitions.csv`: 기본 건물/물류/군사 시설 후보와 배치 조건
- `workshop_definitions.csv`: 부속 작업장과 레시피 연결의 **가설 데이터**
- `sector_definitions.csv`: 가상 테스트 월드의 연결 그래프
- `military_units.csv`: 전투 시뮬레이션용 가상 수치
- `technology_tree.csv`: 연구 의존성 검증용 가상 트리
- `victory_points.csv`: VP 평가 엔진용 가상 조건
- `test_scenarios.csv`: 자동 테스트 요구사항

## 검증 우선순위
1. 원작 건물/부속 작업장 종류 및 실제 배치 제약
2. 원작 자원과 생산 체인 및 식량 보너스
3. 교역·포교·전투의 섹터 점령 방식
4. 실제 승리 포인트 종류 및 조건
5. 유닛·연구·캠페인별 수치
