# Settlers 7 역기획서 v15 — 데이터·규칙 명세 고도화

기존 v14 파일을 보존하고 64~71 상세 기획서 및 CSV/JSON 데이터를 추가했다.

## 신규 기획서
- 64_Master_Data_Model.md
- 65_Building_Workshop_Data_Rules.md
- 66_Production_Recipes_Balance.md
- 67_Logistics_Dispatch_Contracts.md
- 68_Military_Trade_Religion_Tech_Data.md
- 69_Victory_Point_Rule_Engine.md
- 70_AI_Balance_QA_Plan.md
- 71_Original_Evidence_and_Implementation_Backlog.md

## 신규 데이터
- v15_resources.csv
- v15_buildings.csv
- v15_recipes.csv
- v15_data_contract.json

**중요:** v15 데이터는 구조 검증용 샘플이며 원작의 확정 수치가 아니다. 기존 웹 프로토타입 코드는 변경하지 않았다.
