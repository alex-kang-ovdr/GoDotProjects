# 101. QA 및 배포 감사

## 1. 이번에 실제 실행한 범위
Python 3.13.5 환경에서 `v20/tools/run_tests.py`를 실행했다. 자동 테스트 **40개 중 40개 통과**, 실패 0개, 오류 0개다. 여기에는 다중 입력 원자성, 자원별 용량, 중복 예약, 픽업 전 취소, 운송 중 취소 거절, 빈손 이동, 우회, 연결 복구, 저장·재개 동일성이 포함된다.

| ID | 영역 | 테스트 이름 | 결과 |
|---|---|---|---|
| QA-001 | IntegrationTests | test_all_three_chains_run_from_zero_stock | passed |
| QA-002 | IntegrationTests | test_corrupt_save_is_rejected | passed |
| QA-003 | IntegrationTests | test_exact_determinism | passed |
| QA-004 | IntegrationTests | test_mid_cargo_save_load_matches_uninterrupted | passed |
| QA-005 | IntegrationTests | test_more_carriers_improve_total_in_named_fixture | passed |
| QA-006 | IntegrationTests | test_network_save_load_matches_uninterrupted | passed |
| QA-007 | IntegrationTests | test_unexpected_save_field_rejected | passed |
| QA-008 | IntegrationTests | test_unknown_save_version_rejected | passed |
| QA-009 | IntegrationTests | test_zero_second_run_keeps_inventory | passed |
| QA-010 | InventoryTests | test_cancel_unpicked_releases_reservations | passed |
| QA-011 | InventoryTests | test_capacity_is_per_resource_not_total | passed |
| QA-012 | InventoryTests | test_destination_slots_reserved_once | passed |
| QA-013 | InventoryTests | test_finite_deposit_depletes | passed |
| QA-014 | InventoryTests | test_full_output_stops_production | passed |
| QA-015 | InventoryTests | test_loaded_cancellation_does_not_erase_or_refund | passed |
| QA-016 | InventoryTests | test_mass_accounting_every_resource | passed |
| QA-017 | InventoryTests | test_multiinput_start_is_atomic | passed |
| QA-018 | InventoryTests | test_no_farm_supply_no_flour_or_bread | passed |
| QA-019 | InventoryTests | test_paused_workshop_no_new_production | passed |
| QA-020 | InventoryTests | test_source_reserved_once | passed |
| QA-021 | InventoryTests | test_target_stock_pauses_at_threshold | passed |
| QA-022 | InventoryTests | test_zero_carrier_no_terminal_deliveries | passed |
| QA-023 | RoutingTests | test_blocked_cargo_waits_and_resumes | passed |
| QA-024 | RoutingTests | test_cache_invalidation_on_closure | passed |
| QA-025 | RoutingTests | test_disconnected_source_not_dispatched | passed |
| QA-026 | RoutingTests | test_empty_and_loaded_travel_are_counted | passed |
| QA-027 | RoutingTests | test_route_uses_detour_after_closure | passed |
| QA-028 | RoutingTests | test_same_node_zero_distance | passed |
| QA-029 | RoutingTests | test_unreachable_node | passed |
| QA-030 | RoutingTests | test_weighted_not_fewest_edges | passed |
| QA-031 | ValidationTests | test_bad_warehouse_reference_rejected | passed |
| QA-032 | ValidationTests | test_duplicate_store_rejected | passed |
| QA-033 | ValidationTests | test_negative_duration_rejected | passed |
| QA-034 | ValidationTests | test_negative_stock_rejected | passed |
| QA-035 | ValidationTests | test_nonfinite_speed_rejected | passed |
| QA-036 | ValidationTests | test_overfull_initial_stock_rejected | passed |
| QA-037 | ValidationTests | test_parallel_edges_rejected | passed |
| QA-038 | ValidationTests | test_unknown_resource_rejected | passed |
| QA-039 | ValidationTests | test_valid_baseline | passed |
| QA-040 | ValidationTests | test_zero_recipe_duration_rejected | passed |

## 2. 이 테스트가 보장하지 않는 것
원작 수치 정확성, 원작형 운반 인력 소속, 브라우저 게임 전체 플레이, 멀티플레이 동기화, 승리 조건 밸런스, 장시간 대규모 성능, 임의 설정에 대한 최적 배차는 검증하지 않았다. 사례 하나에서 운반자 증설이 개선되었다는 테스트는 모든 품목이 언제나 비감소한다는 뜻이 아니다.

기본 생산망에는 실제 플레이어 입력이나 군대가 없다. `Sink`는 실험용 최종 주문 소비 대역이다. 새로운 GUI 게임을 완성했다고 설명하면 안 된다.

## 3. 보존 및 복구
실제 v19 ZIP에는 `prototype/`가 없었다. v20에서는 v17 ZIP에 들어 있던 브라우저 파일 7개를 같은 바이트로 복구했다. 이 파일들은 v12 계열 구현이며 v20 경제 분석기를 호출하지 않는다. 대응 파일의 SHA-256 비교는 `v20/reports/prototype_recovery.json`에 기록한다.

기존 v19 파일은 캐시를 제외하고 보존한다. 루트 README는 새 안내로 교체하되 원본을 `README_v19_original.md`로 별도 남긴다. 이전 버전의 README에 적힌 ‘모든 자료 포함’ 표현과 실제 ZIP 구성이 다른 경우 이번 검사 기록을 우선한다.

## 4. 회귀 검증
신규 모델은 같은 설정을 두 번 실행하고 보고서·이벤트 로그를 비교한다. 중간 화물과 도로 폐쇄 상태에서 JSON 저장 후 재개한 결과를 중단 없는 실행과 비교한다. 예약 장부는 매 틱 진행 중 Job 목록으로 다시 합산하여 대조한다. 오류가 있으면 조용히 재고를 보정하지 않고 실패한다.

## 5. 배포 전 확인
JSON 전 파일 파싱, Python 컴파일, 내부 링크 유효성, 레시피·엔티티 참조, ZIP CRC를 별도로 검사한다. 파일 수는 배포 시점에 계산한다. 시험용 캐시와 로컬 연구 PDF는 ZIP에서 제외한다. 실행 환경은 Python 표준 라이브러리이며 pip 설치가 필요하지 않다.

## 6. 남은 고위험 항목
픽업 후 목적지 삭제/소유권 변경의 반송 정책, 동일 상품의 지역 간 반복 수송 방지, 전체 수요 대기시간 측정, 지역별 인력 귀속, 신규 건설을 포함한 경제의 시작 가능성, 전체 게임의 브라우저 회귀 시험이 남아 있다. 이는 테스트에서 발견되지 않았다는 뜻이 아니라 현재 모델/시험 범위에 포함하지 않았다는 뜻이다.
