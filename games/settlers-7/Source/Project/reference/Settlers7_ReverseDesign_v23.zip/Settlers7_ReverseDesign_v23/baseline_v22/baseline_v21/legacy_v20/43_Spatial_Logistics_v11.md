# v11 — Spatial Logistics Implementation

## Scope
The v10 continuous map is extended with road-path couriers for **spatially placed non-capital workshops**. This is an experimental prototype inspired by The Settlers 7, not a verified reproduction.

## Core state
- `S7Spatial`: exposes roads, spatial workshops, sector lookup and grid scale.
- Two couriers per non-capital sector, with `task`, `route`, `index`, `progress`, and `load`.
- Workshop `transport`: `input`, `inTransit`, `output`, `outReserved`, `progress`, `phase`.
- `sectors8[sector].inventory` is the authoritative stock ledger; the capital uses the pre-existing v5 stock object.

## Transport loop
1. Determine a sector hub and compute BFS route across that sector's roads to a workshop.
2. Reserve one input in the regional ledger, enqueue courier delivery, and increment `inTransit`.
3. Courier physically traverses road segments and deposits the input into the workshop buffer.
4. Workshop production advances only when the input buffer contains the recipe's input (or the recipe is a raw-resource producer).
5. Output accumulates in the workshop buffer. A courier retrieves it and returns it to the sector hub, incrementing the regional ledger on arrival.
6. Output buffer capacity is two units; full buffers stop production.

## Integration rule
The v9 producer runs only for non-spatial workshops. Spatial workshops are temporarily excluded from the v9 producer's iteration and processed by the v11 producer, preventing duplicate production. Existing v9 direct-built workshops retain the legacy economy model.

## Limits
- The courier allocator currently uses two couriers per sector and a simple scan priority, not optimal dispatch.
- The sector hub is a logical store at the road origin. The system does not yet place individually constructible warehouses per sector.
- Capital still uses the legacy 18×13 tile system.
- Cross-sector caravans still use v8 transport timing rather than the road graph.
- Road deletion and cancellation of already-reserved in-flight jobs are not exposed in this prototype.
- No browser end-to-end test has been run; use the in-game verification button and test by building a connected road/workshop in a captured sector.

## Acceptance scenarios
- A workshop next to a connected road produces only after a delivery (if it requires input).
- The sector ledger decreases when a courier reserves input, and increases only when a finished item returns.
- A workshop without a connected road cannot receive inputs or export products.
- Two couriers cannot reserve the same output simultaneously.
- Save/load restores courier tasks and workshop buffers.
- `v11 물류 검증` checks basic invariants; it is not a comprehensive simulation test.
