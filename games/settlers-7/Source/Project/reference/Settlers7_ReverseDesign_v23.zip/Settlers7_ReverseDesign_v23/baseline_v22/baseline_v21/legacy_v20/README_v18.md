# Settlers 7 Reverse Design v18

기존 v17 자료 전체 보존. 신규 문서 86~91은 생산 역산, 물류 예외, 세 전략의 기회비용, AI 추적, 원작 고증, QA에 집중한다.

## 실행
`python tools/production_planner_v18.py --target resource.bread --rate 6`

`python tools/test_v18.py`

주의: 계산은 v15의 prototype 레시피 5개에만 적용. 생산·물류 시뮬레이터 전체 구현이나 원작 수치 재현을 의미하지 않는다. 기존 웹 프로토타입 코드는 변경하지 않았다.
