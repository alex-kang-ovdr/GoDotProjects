#!/usr/bin/env python3
"""Optional read-only local inventory. Does not decode archives or bypass DRM."""
import argparse,hashlib,json,os,sys
from pathlib import Path
CANDIDATE_SUFFIXES={'.xml','.json','.csv','.ini','.cfg','.lua','.db','.sqlite','.sqlite3','.dat','.pak','.bba','.s7d','.exe'}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--output',type=Path,default=Path('installation_manifest.json'));p.add_argument('--hash',action='store_true',help='Hash candidate files; can read large files.');a=p.parse_args()
    root=a.root.resolve()
    if not root.is_dir():p.error('Provide an existing game-installation folder.')
    if a.output.resolve().is_relative_to(root):p.error('Output must be outside the game folder; this tool is read-only for the installation.')
    records=[];errors=[]
    for base,dirs,names in os.walk(root,followlinks=False):
        dirs[:]=sorted(d for d in dirs if not (Path(base)/d).is_symlink())
        for name in sorted(names):
            f=Path(base)/name
            if f.is_symlink() or f.suffix.lower() not in CANDIDATE_SUFFIXES:continue
            try:
                r={'relative_path':str(f.relative_to(root)),'suffix':f.suffix.lower(),'bytes':f.stat().st_size,'sha256':None,'content_parsed':False}
                if a.hash:
                    h=hashlib.sha256()
                    with f.open('rb') as stream:
                        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
                    r['sha256']=h.hexdigest()
                records.append(r)
            except OSError as e:errors.append({'file':str(f.relative_to(root)),'error':str(e)})
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps({'files':records,'errors':errors,'raw_game_values_extracted':False,'note':'File suffixes are candidates, not claims about this game storage format.'},ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{len(records)} candidate files listed; {len(errors)} read errors. No game files changed.')
    return bool(errors)
if __name__=='__main__':sys.exit(main())
