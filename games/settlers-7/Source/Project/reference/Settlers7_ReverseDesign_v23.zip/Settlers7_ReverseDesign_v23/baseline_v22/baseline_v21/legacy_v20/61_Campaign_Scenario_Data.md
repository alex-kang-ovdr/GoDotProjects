# 캠페인·미션·이벤트 데이터 명세

> v14 상세 설계 / 원작 미검증 수치는 예시 또는 제안으로 명시

## 시나리오 구조
Scenario(id, mapId, startingResources, playerSlots, victoryRules, defeatRules, tutorials, triggers, rewards). Trigger(id, condition, once, cooldown, priority, actions). 대사·이벤트 원문을 임의로 원작 내용이라 주장하지 않는다.

## 튜토리얼 단계
1. 카메라·영토 이해 2. 도로와 창고 연결 3. 본관·부속 작업장 4. 원료 부족 해결 5. 섹터 확보 6. 군사·무역·종교 중 하나 선택 7. VP 목표 확인.

## 미션 예시(창작 프로토타입)
M01: 10분 이내 목재 20개 생산. M02: 농업·제분·제빵 체인을 완성하고 빵 10개 확보. M03: 인접 중립 섹터를 군사·무역·종교 중 하나로 획득. M04: 동적 VP를 획득하고 3분간 유지.

## 이벤트 엔진
이벤트는 시나리오 틱 경계에서 평가하며, 한번 실행되는 이벤트는 eventId+scenarioId로 중복 방지한다. 선택지 적용은 트랜잭션 처리한다.

## 난이도 조정
시작 자원·상대 AI 의사결정·맵 자원량·VP 목표를 분리한다. 튜토리얼 스킵 시에도 세이브 구조가 정상 유지돼야 한다.
