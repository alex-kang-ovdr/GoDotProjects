// v8: sector economy, stock transfers, outpost development and timed skirmishes.
// This is an original prototype model, not a verified recreation of Settlers 7 internals.
(() => {
'use strict';
const RESOURCES=['wood','stone','plank','grain','flour','bread'];
const LABEL={wood:'원목',stone:'석재',plank:'판자',grain:'곡물',flour:'밀가루',bread:'빵'};
const POS=[[240,145],[110,75],[367,75],[240,245],[75,218],[407,218]];
let sectors8=[],caravans=[],battles=[],selected8=0,caravanId=0,battleId=0,aiEconomyClock=0;
const parentTick=tick,parentRender=render,parentInit=init,parentSnapshot=snapshot,parentRestore=restore,parentTests=tests;
const parentEnemyAI=enemyAI;
const blank=()=>Object.fromEntries(RESOURCES.map(r=>[r,0]));
function init8(){sectors8=SECTOR_NAMES.map((name,i)=>({id:i,level:i===0?2:0,inventory:{...blank(),...(i===0?{wood:12,stone:6,grain:4}: {})},progress:0,buildings:[],productionEnabled:i===0}));caravans=[];battles=[];selected8=0;caravanId=0;battleId=0;aiEconomyClock=0;}
function canDevelop(i){return kingdom.sectors[i]===0}
function costLocal(i,cost){let inv=sectors8[i].inventory;return Object.entries(cost).every(([r,n])=>(inv[r]||0)>=n)}
function spendLocal(i,cost){for(const [r,n] of Object.entries(cost))sectors8[i].inventory[r]-=n}
function develop(i){if(!canDevelop(i))return log('내 영토만 개발할 수 있습니다');const cost={wood:3,stone:2};if(!costLocal(i,cost))return log('지역 창고에 원목3, 석재2 필요');spendLocal(i,cost);sectors8[i].level++;sectors8[i].productionEnabled=true;sectors8[i].buildings.push('생산 거점');log(`${SECTOR_NAMES[i]} 생산 거점 Lv.${sectors8[i].level}`);render()}
function dispatch(from,to,item,qty){qty=Number(qty);if(!Number.isInteger(qty)||qty<1||qty>20)return log('운송 수량은 1~20');if(from===to||!canDevelop(from)||!canDevelop(to))return log('소유한 서로 다른 지역 사이에서만 운송 가능');if(!SECTOR_NEIGHBORS[from].includes(to))return log('운송은 인접 지역 사이에서만 가능');if((sectors8[from].inventory[item]||0)<qty)return log('출발지 재고 부족');sectors8[from].inventory[item]-=qty;const dist=Math.hypot(POS[from][0]-POS[to][0],POS[from][1]-POS[to][1]);caravans.push({id:++caravanId,from,to,item,qty,progress:0,duration:Math.max(5,dist/14)});log(`${SECTOR_NAMES[from]} → ${SECTOR_NAMES[to]} ${LABEL[item]} ${qty} 운송 출발`);render()}
function startBattle(i){if(kingdom.winner||kingdom.sectors[i]===0||!adjacentOwned(i,0))return log('공격할 수 없는 지역');if(battles.some(b=>b.to===i))return log('이미 전투 진행 중');if(kingdom.army<2)return log('병사 2명 이상 필요');const from=SECTOR_NEIGHBORS[i].find(n=>kingdom.sectors[n]===0);const committed=Math.min(kingdom.army,Math.max(2,kingdom.defenders[i]+2));kingdom.army-=committed;battles.push({id:++battleId,from,to:i,attack:committed+(hasTech('tools')?1:0),defense:kingdom.defenders[i],progress:0,duration:10});log(`${SECTOR_NAMES[i]} 교전 시작: 아군 ${committed}명 투입`);render()}
function resolveBattle(b){let attack=b.attack,defense=b.defense;let win=attack>defense;let survivors=Math.max(0,attack-Math.ceil(defense*.65)-(hasTech('tools')?1:0));kingdom.army+=survivors;if(win){kingdom.sectors[b.to]=0;sectors8[b.to].productionEnabled=true;log(`${SECTOR_NAMES[b.to]} 전투 승리 · 생존 ${survivors}`)}else{kingdom.defenders[b.to]=Math.max(1,defense-Math.floor(attack*.5));log(`${SECTOR_NAMES[b.to]} 전투 패배 · 방어 병력 감소`)}recount()}
function tick8(dt){for(const s of sectors8){if(window.SETTLERS_V9)continue;if(kingdom.sectors[s.id]!==0||!s.productionEnabled||s.level===0)continue;s.progress+=dt;const period=Math.max(5,18-s.level*2);while(s.progress>=period){s.progress-=period;const res=s.id===1?'wood':s.id===2?'stone':s.id===3?'grain':s.id===4?'plank':s.id===5?'flour':'wood';s.inventory[res]++;if(s.id===0&&s.inventory.wood>=2&&s.inventory.grain>=1){s.inventory.wood-=2;s.inventory.grain--;s.inventory.bread++}}}
for(const c of caravans)c.progress+=dt/c.duration;for(const c of caravans.filter(c=>c.progress>=1)){if(kingdom.sectors[c.to]===0)sectors8[c.to].inventory[c.item]+=c.qty;else log('목적지 상실로 운송 화물 손실');log(`${SECTOR_NAMES[c.to]} 운송 도착: ${LABEL[c.item]} ${c.qty}`)}caravans=caravans.filter(c=>c.progress<1);
for(const b of battles)b.progress+=dt/b.duration;for(const b of battles.filter(b=>b.progress>=1))resolveBattle(b);battles=battles.filter(b=>b.progress<1);
aiEconomyClock+=dt;if(aiEconomyClock>=18){aiEconomyClock-=18;for(const s of sectors8)if(kingdom.sectors[s.id]===1){s.level=Math.max(1,s.level);s.inventory.wood++;s.inventory.stone++;} }
}
tick=function(dt){parentTick(dt);tick8(dt)};
// Replace immediate military resolution with a visible timed battle, leaving trade/faith expeditions intact.
const oldTake8=takeSector;takeSector=function(i,method){if(method==='army'){startBattle(i);return}oldTake8(i,method)};
// v7 captures a reference to v6's takeSector for arriving expeditions; military arrival still
// resolves under v7's simplified rule. The separate '교전' command below uses v8 combat.
const panel=document.createElement('section');panel.className='panel';panel.id='v8panel';panel.style.marginTop='12px';document.querySelector('aside.panel').appendChild(panel);
function render8(){const s=sectors8[selected8];if(!s)return;const owned=kingdom.sectors[selected8]===0;const stockText=RESOURCES.map(r=>`${LABEL[r]} ${s.inventory[r]||0}`).join(' · ');
panel.innerHTML=`<h3>지역별 경제 · v8</h3><div class="pill">선택: ${SECTOR_NAMES[selected8]} · ${owned?'내 영토':kingdom.sectors[selected8]===1?'적 영토':'중립'} · 생산 거점 Lv.${s.level}</div><p><small>지역 지도에서 내 영토를 클릭하면 지역 경제를 선택합니다. 자원은 지역별로 독립 보관됩니다. 상단의 기존 물류 창고는 v7 호환 경제입니다.</small></p><div class="pill">${stockText}</div><p><button id="v8develop" ${owned?'':'disabled'}>생산 거점 개발 (원목3·석재2)</button><button id="v8battle" ${owned?'disabled':''}>선택 지역 교전</button></p><div><label>보낼 지역 <select id="v8dest">${SECTOR_NAMES.map((n,i)=>`<option value="${i}">${n}</option>`).join('')}</select></label><label>자원 <select id="v8item">${RESOURCES.map(r=>`<option value="${r}">${LABEL[r]}</option>`).join('')}</select></label><label>수량 <input id="v8qty" type="number" min="1" max="20" value="2"></label><button id="v8send" ${owned?'':'disabled'}>운송</button></div><p class="hint">운송 중 ${caravans.length}건 · 교전 중 ${battles.length}건</p><div>${caravans.map(c=>`<div class="pill">🚚 ${SECTOR_NAMES[c.from]} → ${SECTOR_NAMES[c.to]} ${LABEL[c.item]} ${c.qty} · ${Math.min(100,Math.round(c.progress*100))}%</div>`).join('')}${battles.map(b=>`<div class="pill">⚔ ${SECTOR_NAMES[b.to]} 전투 · ${Math.min(100,Math.round(b.progress*100))}%</div>`).join('')}</div>`;
panel.querySelector('#v8develop').onclick=()=>develop(selected8);panel.querySelector('#v8battle').onclick=()=>startBattle(selected8);panel.querySelector('#v8send').onclick=()=>dispatch(selected8,+panel.querySelector('#v8dest').value,panel.querySelector('#v8item').value,+panel.querySelector('#v8qty').value);
}
render=function(){parentRender();render8()};
const board8=document.getElementById('regions');board8.addEventListener('click',e=>{const r=board8.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*480,y=(e.clientY-r.top)/r.height*290;let i=POS.findIndex(([a,b])=>Math.hypot(a-x,b-y)<32);if(i<0)return;selected8=i;if(kingdom.sectors[i]===0){e.stopImmediatePropagation();render()}},true);
init=function(){parentInit();init8()};
snapshot=function(){return {...parentSnapshot(),version:8,sectors8,caravans,battles,selected8,caravanId,battleId,aiEconomyClock}};
restore=function(data){if(!data||![7,8].includes(data.version))throw Error('v7/v8 저장만 지원');parentRestore({...data,version:7});init8();if(data.version===8){sectors8=data.sectors8;caravans=data.caravans||[];battles=data.battles||[];selected8=data.selected8||0;caravanId=data.caravanId||0;battleId=data.battleId||0;aiEconomyClock=data.aiEconomyClock||0;}};
tests=function(){parentTests();const checks=[['지역 경제 6개 생성',sectors8.length===6],['지역 재고 음수 없음',sectors8.every(s=>RESOURCES.every(r=>s.inventory[r]>=0))],['운송 목적지 유효성',caravans.every(c=>c.from>=0&&c.from<6&&c.to>=0&&c.to<6)],['교전 진행률 유효성',battles.every(b=>b.progress>=0&&b.progress<1)],['v8 저장 데이터 직렬화',!!JSON.stringify(snapshot())]];document.getElementById('tests').innerHTML+=checks.map(([name,ok])=>`<div>${ok?'✅':'❌'} ${name}</div>`).join('')};
document.getElementById('save').onclick=()=>{localStorage.setItem('settlers7_v8',JSON.stringify(snapshot()));log('v8 저장 완료');render()};
document.getElementById('load').onclick=()=>{try{let d=localStorage.getItem('settlers7_v8')||localStorage.getItem('settlers7_v7');restore(JSON.parse(d));log('불러오기 완료')}catch(e){log('불러오기 실패: '+e.message)}render()};
document.getElementById('reset').onclick=()=>{init();render()};document.getElementById('test').onclick=tests;
init8();render();
})();
