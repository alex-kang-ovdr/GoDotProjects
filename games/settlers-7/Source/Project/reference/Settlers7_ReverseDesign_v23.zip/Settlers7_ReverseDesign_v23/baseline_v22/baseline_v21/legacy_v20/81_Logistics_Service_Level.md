# v17 물류 서비스 수준 및 배차 정책

## 운송 요청 상태
Created → Reserved → Assigned → Pickup → Transit → Delivered → Closed.
실패: Cancelled, RouteInvalid, SourceEmpty, DestinationFull.

## 우선순위(프로토타입 가정)
score = 5×critical_chain + 3×starvation + 2×age_minutes − 0.1×travel_seconds.
동점: 요청 생성 순서, 이후 고정된 request_id로 결정.

## 불변조건
- 창고 재고 >= 0; 예약 수량 <= 실재고
- 운반자 한 명은 동시에 화물 한 건만 운반
- 경로가 끊기면 진행 중인 운송은 재경로 탐색 또는 원위치 복귀
- 건물 철거 시 관련 요청·예약을 원자적으로 해제
- 동일 화물은 배송 완료 이벤트를 두 번 발생시키지 않음

## 관측 지표
p50/p95 배송시간, 요청 큐 길이, 작업장 원료 대기율, 창고 체류시간, 운반자 유휴율, 분실·중복 자원 건수.
