# 통합 데이터 모델 v15

## 1. 데이터 식별 규칙
- 모든 정적 정의는 불변 문자열 ID (`building.farm`, `resource.grain`)를 사용한다.
- 모든 런타임 객체는 별도 UUID/정수 instanceId를 사용한다.
- 참조 필드가 존재하지 않으면 데이터 로딩 실패로 처리한다. 임의 기본값으로 조용히 대체하지 않는다.
- 원작 고증 필드 `evidence`는 `confirmed / inferred / prototype` 중 하나이며, `confirmed`는 증거 자료와 버전 기록이 있어야 한다.

## 2. 정적 테이블
| 테이블 | PK | 필수 참조 | 주요 필드 |
|---|---|---|---|
| resources | id | 없음 | category, stackSize, transportable |
| buildings | id | 없음 | footprint, cost, sectorRules, slots |
| workshops | id | buildings.id | parentTypes, recipeIds, capacity |
| recipes | id | resources.id | inputs, outputs, cycleSeconds |
| units | id | resources.id | cost, health, damage, role |
| technologies | id | technologies.id | prerequisites, cost, modifiers |
| victory_rules | id | 없음 | type, condition, points, tiePolicy |

## 3. 런타임 엔티티
- Sector: owner, terrainMask, roadGraphVersion, buildingIds, warehouseIds.
- Warehouse: stock, reservedOutbound, reservedInbound, capacity, deliveryPolicy.
- Workshop: parentBuildingId, slotIndex, recipeId, inputBuffer, outputBuffer, state, progress.
- Carrier: position, path, cargo, jobId, state.
- Shipment: source, destination, resourceId, quantity, reservationId, status.
- Army: owner, units, targetSector, travelProgress, combatState.

## 4. 불변 조건
1. `stock >= 0`, `reservedOutbound <= stock`.
2. 예약은 단 한 번 소비되거나 취소된다.
3. 모든 운송 자원은 `창고+작업장+운반중+생산/소비 누계`에 계상한다.
4. 점령 변경은 건설 권한과 경로 그래프를 무효화한다.
5. 저장 파일에는 schemaVersion과 콘텐츠 버전을 모두 기록한다.

## 5. 원작 고증 분리
현재 테이블 예시는 시스템 구현용이며 원작의 정확한 건설 비용, 생산 주기, 병력 수치가 아니다.
