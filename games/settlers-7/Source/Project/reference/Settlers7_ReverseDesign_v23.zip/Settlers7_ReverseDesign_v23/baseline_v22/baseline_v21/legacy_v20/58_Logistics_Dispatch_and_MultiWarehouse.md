# 복수 창고와 물류 배차 정책

> v14 상세 설계 / 원작 미검증 수치는 예시 또는 제안으로 명시

## 원칙
재고 원장(창고별), 예약 원장, 운반자 화물, 작업장 입력 버퍼를 분리한다. 운반 중 화물은 창고 재고가 아니며 전체 자원 보존 합계에 포함한다.

## 요청 모델
DeliveryRequest(id, resourceId, amount, sourceCandidates, destination, priority, createdTick, deadlineTick, state). 상태 NEW → RESERVED → ASSIGNED → PICKED_UP → DELIVERED / CANCELLED / FAILED.

## 배차 평가 함수
score = priorityWeight × 우선순위 - pickupDistanceWeight × 픽업거리 - deliveryDistanceWeight × 배송거리 - congestionWeight × 경로 혼잡 + starvationBonus × 대기시간. 동일 점수는 요청 생성 틱과 ID로 결정해 재현성을 확보한다.

## 복수 창고 선택
후보 창고 중 실제 가용재고, 연결성, 운송 시간, 다른 예약을 반영해 출고처를 선택한다. 창고를 단순한 공유 전역 재고로 취급하지 않는다.

## 도로 단절 처리
도로 그래프 버전 증가 → 해당 경로를 가진 운반자만 재탐색 → 재탐색 실패 시 화물 임시 보관 또는 출발지 복귀 → 예약·요청 복구. 그래프 갱신 중 프레임 전체 경로 탐색 폭증을 피하도록 틱당 재계산 예산을 둔다.

## 교착 방지
입력 버퍼 용량, 출력 버퍼 용량, 창고 용량, 운반자 수를 동시에 제한한다. 배송 대기 상한 초과 시 우선순위 상승; 생산품 회수와 필수 원료 배송에 최소 배차 몫을 보장한다.

## 테스트
두 창고 동시 예약, 동일 운반자 중복 할당, 운송 중 도로 단절, 목적 작업장 철거, 저장·로드 중복 배송, 1만 건 요청 처리.
