# AI 경제 병목 복구 플레이북

## 관측
매 15초에 생산 수요, 재고, 미처리 운송 큐, 작업장 유휴 시간, 승리 점수 차이를 샘플링한다.

## 행동 후보
1. 원료 생산 건물 추가
2. 운반자 증설
3. 창고 접근 경로 개선
4. 비핵심 생산 일시 정지
5. 목표 전략에 필요한 생산 체인으로 전환

## Utility 예시
score = expected_throughput_gain * strategic_weight - resource_cost * scarcity_weight - completion_time * urgency_weight - disruption_risk

동일 행동 반복 방지: 30초 cooldown, 최소 개선량 임계치, 최근 실패한 행동 감점. 모든 AI 행동은 관측값·후보 점수·선택 이유를 로그로 남긴다.

## 원작 고증
AI의 실제 의사결정 구조는 공개적으로 검증되지 않았으므로 재구성 구현안으로 분류한다.
