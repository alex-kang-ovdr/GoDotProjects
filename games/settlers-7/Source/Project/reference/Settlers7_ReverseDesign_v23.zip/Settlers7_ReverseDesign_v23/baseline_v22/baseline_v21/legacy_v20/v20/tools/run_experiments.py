#!/usr/bin/env python3
"""Run controlled 20-minute experiments. No random seed or external dependencies."""
from __future__ import annotations
import copy
import csv
import json
from pathlib import Path
from network_sim import Simulation, load_config, HERE


def fleet(config: dict, count: int) -> dict:
    config['carriers'] = [dict(id=f'carrier_{i+1:02}', node='west' if i%2==0 else 'east', capacity=3) for i in range(count)]
    return config


def scenarios() -> list[tuple[str, str, dict]]:
    base = load_config()
    items = []
    def add(id: str, description: str, config: dict) -> None:
        config['id'] = id
        items.append((id, description, config))
    for n in (2, 4, 8, 12):
        add(f'fleet_{n}', f'운반자 {n}명 / 기본 도로 / 창고별 자원당 20개', fleet(copy.deepcopy(base), n))
    short = copy.deepcopy(base)
    next(e for e in short['edges'] if e['id'] == 'bridge')['length'] = 10
    add('near_warehouse', '운반자 4명 / 창고 연결 거리 30→10', short)
    paved = copy.deepcopy(base)
    next(e for e in paved['edges'] if e['id'] == 'bridge')['speed'] = 2
    add('paved_bridge', '운반자 4명 / 창고 연결도로 속도 1→2', paved)
    small = copy.deepcopy(base)
    for s in small['stores']:
        if s['kind'] == 'warehouse': s['capacity'] = 3
    add('small_storage', '운반자 4명 / 창고별 자원당 용량 20→3', small)
    closed = copy.deepcopy(base)
    closed['events'] = [dict(tick=300,edge='bridge',open=False), dict(tick=600,edge='bridge',open=True)]
    add('closure_reopen', '운반자 4명 / 300~599초 연결도로 단절', closed)
    detour = copy.deepcopy(closed)
    detour['nodes'].append(dict(id='bypass',x=15,y=20))
    detour['edges'] += [dict(id='detour_w',a='west',b='bypass',length=25,speed=1,open=True),dict(id='detour_e',a='bypass',b='east',length=25,speed=1,open=True)]
    add('closure_detour', '운반자 4명 / 단절 구간 우회로 50거리', detour)
    boosted = fleet(copy.deepcopy(base),8)
    for s in boosted['stores']:
        if s.get('recipe') == 'forge': s['mode'] = 'paused'
    add('food_priority', '운반자 8명 / 무기 생산 중단, 다른 조건 동일', boosted)
    return items


def main() -> None:
    output = HERE/'reports'
    output.mkdir(exist_ok=True)
    all_reports = []
    rows = []
    for id, note, config in scenarios():
        sim = Simulation(config)
        r = sim.run(1200)
        r['description_ko'] = note
        all_reports.append(r)
        row = dict(scenario=id, description_ko=note, seconds=r['seconds'], carriers=r['carrier_count'],
            bread_produced=r['produced']['bread'], bread_delivered=r['fulfilled']['deliver_bread'],
            plank_delivered=r['fulfilled']['deliver_plank'], weapon_delivered=r['fulfilled']['deliver_weapon'],
            tool_delivered=r['fulfilled']['deliver_tool'], carrier_busy=r['carrier_busy_ratio'],
            empty_seconds=r['empty_travel_seconds'], loaded_seconds=r['loaded_travel_seconds'],
            blocked_seconds=r['blocked_carrier_seconds'], completed_jobs=r['completed_jobs'],
            active_jobs=r['active_jobs'], completed_latency_p95=r['completed_job_latency_p95_seconds'],
            balance_error=sum(abs(v) for v in r['inventory_balance_error'].values()), state_sha256=r['state_sha256'])
        rows.append(row)
        print(id, {k: row[k] for k in ('bread_produced','bread_delivered','plank_delivered','weapon_delivered','tool_delivered','blocked_seconds')})
        (HERE/'data'/f'scenario_{id}.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        if id == 'fleet_4':
            (output/'baseline_trace.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in sim.trace),encoding='utf-8')
            (output/'baseline_timeseries.json').write_text(json.dumps(sim.samples,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            (output/'baseline_final_snapshot.json').write_text(json.dumps(sim.snapshot(),ensure_ascii=False)+'\n',encoding='utf-8')
    with (output/'experiment_summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w = csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    (output/'experiment_results.json').write_text(json.dumps(all_reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

if __name__ == '__main__': main()
