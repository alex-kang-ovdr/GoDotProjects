# The Settlers 7 Reverse Design v11

This archive extends v10 with a prototype spatial logistics layer.

## Launch
Open `prototype/index.html` in Chrome or Edge (no server needed).

## New in v11
- Courier movement on a per-sector road graph
- Workshop input and output buffers
- Production stalls on missing delivered inputs or full output buffers
- One regional inventory ledger for these workshops
- Legacy v9 workshops remain supported
- v11 local save/load and validation UI

See `43_Spatial_Logistics_v11.md` for algorithm and limitations.

**Important:** This is not a faithful reproduction of original Settlers 7 numeric balance, UI, combat, or full world simulation. Browser end-to-end tests have not been executed.
