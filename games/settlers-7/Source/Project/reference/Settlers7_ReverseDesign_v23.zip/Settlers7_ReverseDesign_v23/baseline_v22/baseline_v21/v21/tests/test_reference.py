import copy,json,sys,tempfile,unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'tools'))
from validate import load,validate,indexes,readiness
from export_reference import export

class ReferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m=load();cls.t=cls.m['tables'];cls.i=indexes(cls.m)
        cls.proof=[json.loads(x) for x in (BASE/'data/field_provenance.jsonl').read_text(encoding='utf-8').splitlines()]
    def bad(self,mutate):
        m=copy.deepcopy(self.m);mutate(m['tables']);self.assertTrue(validate(m))
    def test_01_full_integrity(self):self.assertEqual(validate(self.m,self.proof),[])
    def test_02_26_inventory_goods(self):self.assertEqual(len(self.t['resources']),26)
    def test_03_food_groups_not_goods(self):self.assertNotIn('plain_food',self.i['resources']);self.assertEqual(self.i['resource_groups']['plain_food']['members'],['bread','fish'])
    def test_04_28_workshops(self):self.assertEqual(len(self.t['workshops']),28)
    def test_05_workshop_parent_counts(self):
        self.assertEqual([sum(x['parent_building_id']==b for x in self.t['workshops']) for b in ['residence','noble_residence','farm','lodge','mountain_shelter']],[6,6,5,5,6])
    def test_06_smelter_exact_components(self):
        self.assertEqual({r['resource_id']:r['qty'] for r in self.t['recipe_inputs'] if r['recipe_id']=='produce_iron_iron_smelter'},{'iron_ore':1,'coal':1})
    def test_07_tool_exact_components(self):
        self.assertEqual({r['resource_id']:r['qty'] for r in self.t['recipe_inputs'] if r['recipe_id']=='produce_tool_toolmaker'},{'wood':1,'iron':1})
    def test_08_no_fabricated_cycle_times(self):self.assertTrue(all(r['cycle_seconds'] is None for r in self.t['recipes']))
    def test_09_no_implicit_zero_for_unknown_quantity(self):self.assertTrue(any(x['qty'] is None for x in self.t['recipe_inputs']));self.assertFalse(any(x['qty']==0 for x in self.t['recipe_inputs']))
    def test_10_noble_food_required_not_hardcoded_bread(self):
        self.assertEqual(self.i['workshops']['blacksmith']['food_class'],'noble')
        self.assertNotIn('bread',[x['resource_id'] for x in self.t['recipe_inputs'] if x['recipe_id']=='produce_weapon_blacksmith'])
        self.assertNotIn('noble_none',self.i['food_policies'])
    def test_11_food_output_not_cycle_multiplier(self):
        self.assertEqual(self.i['food_policies']['std_fancy']['output_multiplier'],3);self.assertIsNone(self.i['food_policies']['std_fancy']['cycle_time_multiplier'])
    def test_12_forester_world_action(self):self.assertFalse(any(x['producer_id']=='forester' for x in self.t['recipes']));self.assertIn('plant_trees',self.i['world_actions'])
    def test_13_storehouse_profile_totals(self):
        self.assertEqual([self.i['building_levels'][f'storehouse_L{n}']['carriers'] for n in range(3)],[2,3,4])
        self.assertEqual(self.i['building_levels']['storehouse_L1']['capacity_per_resource'],50)
        self.assertEqual(self.i['building_levels']['storehouse_L1']['capacity_cross_source_state'],'conflicting')
    def test_14_unlimited_not_zero(self):r=self.i['building_levels']['storehouse_L2'];self.assertIsNone(r['capacity_per_resource']);self.assertTrue(r['unlimited_storage'])
    def test_15_carrier_conflict_preserved(self):r=self.i['rules']['carrier_capacity'];self.assertIsNone(r['value']);self.assertEqual(r['candidates'],[3,5])
    def test_16_units_branch_counts(self):self.assertEqual([sum(x['branch']==b for x in self.t['units']) for b in ['military','clergy','trade']],[5,3,3])
    def test_17_cannon_population_two(self):self.assertEqual(self.i['units']['cannon']['population_cost'],2)
    def test_18_cannon_training_cost(self):self.assertEqual({x['requirement_id']:x['qty'] for x in self.t['unit_costs'] if x['unit_id']=='cannon'},{'coin':2,'weapon':2,'wheel':2,'coal':1,'fancy_food':1})
    def test_19_trades_are_exchange_counts(self):self.assertEqual([self.i['units'][x]['trades_per_trip'] for x in ['hawker','salesman','merchant']],[1,3,5])
    def test_20_combat_not_invented(self):self.assertTrue(all(x['hp'] is None and x['attack_interval_seconds'] is None for x in self.t['units']))
    def test_21_tech_tree_unknown_not_empty(self):self.assertEqual(len(self.t['technologies']),18);self.assertTrue(all(x['prerequisite_ids'] is None for x in self.t['technologies']))
    def test_22_average_modifier_semantics(self):self.assertEqual(self.i['technology_effects']['forestry_main']['operation'],'production_time_ratio_average')
    def test_23_engineering_is_not_geologist(self):self.assertFalse(self.i['technology_effects']['engineering_main']['value']);self.assertEqual(self.i['technology_effects']['geology_main']['value'],.4)
    def test_24_vp_conflict_not_silently_filled(self):r=self.i['missions']['m10'];self.assertIsNone(r['required_vp']);self.assertEqual(r['required_vp_candidates'],[6,7])
    def test_25_countdown_not_global(self):self.assertEqual(sum(x['countdown_seconds']==180 for x in self.t['missions']),1);self.assertEqual(self.i['missions']['m09']['countdown_seconds'],180)
    def test_26_abbreviated_stock_unknown(self):self.assertNotIn('m01__horse',self.i['initial_stock']);self.assertEqual(len(self.t['initial_stock']),211)
    def test_27_event_combat_is_defender_not_payment(self):
        combat={x['id'] for x in self.t['events'] if x['interaction']=='combat'}
        self.assertTrue(all(x['meaning']=='defending_army_to_defeat' for x in self.t['event_requirements'] if x['event_id'] in combat))
    def test_28_wool_context_not_confirmed(self):
        e=next(x for x in self.t['events'] if x['name_en']=='Kingsized Wool');self.assertEqual(e['evidence_state'],'context_reconstructed')
        self.assertEqual(next(x for x in self.t['event_requirements'] if x['event_id']==e['id'])['evidence_state'],'context_reconstructed')
    def test_29_base_event_cost_not_runtime_cost(self):self.assertTrue(all(x['cost_basis']=='documented_base_not_current_dynamic_cost' for x in self.t['events']))
    def test_30_alias_does_not_erase_iron_ore(self):self.assertIn('iron_ore',self.i['resources']);self.assertIn('iron',self.i['resources'])
    def test_31_recipe_outputs_cover_goods(self):self.assertEqual({r['output_resource_id'] for r in self.t['recipes']},set(self.i['resources']))
    def test_32_strict_runtime_export_blocked_without_file(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.json'
            with self.assertRaises(ValueError):export(self.m,p,'runtime')
            self.assertFalse(p.exists())
    def test_33_reference_export_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'ok.json';export(self.m,p);out=json.loads(p.read_text(encoding='utf-8'));self.assertEqual(out['catalog'],self.m)
    def test_34_ready_count_zero(self):r=readiness(self.m);self.assertEqual(r['fully_parameterized_recipes'],0);self.assertEqual(r['recipes_with_complete_material_quantities'],2)
    def test_35_reject_duplicate_resource(self):self.bad(lambda t:t['resources'].append(copy.deepcopy(t['resources'][0])))
    def test_36_reject_dangling_material(self):self.bad(lambda t:t['recipe_inputs'][0].update(resource_id='unobtainium'))
    def test_37_reject_negative_quantity(self):self.bad(lambda t:t['unit_costs'][0].update(qty=-1))
    def test_38_reject_nan(self):self.bad(lambda t:t['recipe_inputs'][0].update(qty=float('nan')))
    def test_39_reject_zero_cycle(self):self.bad(lambda t:t['recipes'][0].update(cycle_seconds=0))
    def test_40_reject_unlimited_with_number(self):self.bad(lambda t:next(x for x in t['building_levels'] if x['id']=='storehouse_L2').update(capacity_per_resource=0))
    def test_41_reject_missing_source(self):self.bad(lambda t:t['recipes'][0].update(source_id='missing'))
    def test_42_reject_missing_locator(self):self.bad(lambda t:t['recipes'][0].update(locator=''))
    def test_43_reject_silent_conflict_resolution(self):self.bad(lambda t:next(x for x in t['missions'] if x['id']=='m10').update(required_vp=6))
    def test_44_reject_fake_runtime_verification(self):self.bad(lambda t:t['resources'][0].update(runtime_verified=True))
    def test_45_provenance_mutation_detected(self):
        p=copy.deepcopy(self.proof);p[0]['value']='WRONG';self.assertTrue(validate(self.m,p))
    def test_46_missing_field_provenance_detected(self):self.assertTrue(validate(self.m,self.proof[1:]))
    def test_47_duplicate_input_detected(self):
        def mutate(t):r=copy.deepcopy(t['recipe_inputs'][0]);r['id']='new_id_same_input';t['recipe_inputs'].append(r)
        self.bad(mutate)
    def test_48_event_references_detected(self):self.bad(lambda t:t['event_requirements'][0].update(event_id='missing'))
    def test_49_unsupported_upgrade_not_zero(self):self.assertIsNone(self.i['buildings']['farm']['max_upgrade_index'])
    def test_50_fountain_minimum_three(self):self.assertEqual(self.i['victory_points']['fountain_of_knowledge']['minimum_threshold'],3)

if __name__=='__main__':unittest.main(verbosity=2)
