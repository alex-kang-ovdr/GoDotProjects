# 건설 및 배치 규칙

> Settlers 7 역기획 v4 — 원작 확인 내용과 구현 제안을 분리합니다.

## 건설 명령 처리
`ValidateTerrain → ValidateSectorOwnership → ValidateCollision → ValidateRoadAccess → ValidateResources → ReserveCost → Construct → Activate`. 모든 검사에는 사용자에게 표시할 실패 사유 코드를 부여한다.

## 본관·부속 작업장
본관 1개에 최대 3개 작업장을 연결하는 구조를 중심으로, 슬롯 점유와 건물 계열 적합성을 검증한다. 실제 원작의 건물별 세부 제약은 검증 전까지 `unverified`로 표시한다.

## 건설 UX
유효 위치 녹색, 지형 불가 빨간색, 도로 미연결 주황색. 건설 고스트에는 예상 자원 소비·생산 체인 영향·도로 연결 상태를 표시한다.

## 상태
`PLANNED, WAIT_MATERIAL, BUILDING, ACTIVE, PAUSED, DESTROYED`. 취소 시 예약 반환, 건설 완료 시 이벤트 발행, 철거 시 물류 작업을 정리한다.
