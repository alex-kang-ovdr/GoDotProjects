import sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from reference_engine import *

class TestReference(unittest.TestCase):
    def setUp(self): self.m=load()
    def test_master_valid(self):self.assertEqual(validate(self.m),[])
    def test_table_ids_unique(self):
        self.m['tables']['resources'].append(copy.deepcopy(self.m['tables']['resources'][0]));self.assertTrue(validate(self.m))
    def test_no_fake_runtime(self):self.m['tables']['resources'][0]['runtime_verified']=True;self.assertTrue(validate(self.m))
    def test_no_runtime_export(self):self.m['meta']['runtime_export_allowed']=True;self.assertTrue(validate(self.m))
    def test_no_profile_runtime_export(self):self.m['tables']['edition_profiles'][0]['runtime_export']=True;self.assertTrue(validate(self.m))
    def test_bad_source(self):self.m['tables']['versioned_unit_costs'][0]['source_id']='missing';self.assertTrue(validate(self.m))
    def test_bad_unit(self):self.m['tables']['versioned_unit_costs'][0]['unit_id']='dragon';self.assertTrue(validate(self.m))
    def test_bad_resource(self):self.m['tables']['versioned_unit_costs'][0]['requirement_id']='oil';self.assertTrue(validate(self.m))
    def test_bad_quantity(self):self.m['tables']['versioned_unit_costs'][0]['qty']=-1;self.assertTrue(validate(self.m))
    def test_bad_formula_ref(self):self.m['tables']['expansion_formulas'][0]['coefficients']['elephants']='1';self.assertTrue(validate(self.m))
    def test_coeff_mismatch(self):self.m['tables']['formula_coefficients'][0]['coefficient']='999';self.assertTrue(validate(self.m))
    def test_no_guess_rounding(self):self.m['tables']['expansion_formulas'][0]['rounding_policy']='ceil';self.assertTrue(validate(self.m))
    def test_no_quarantine_leak(self):self.m['tables']['quarantined_claims'][0]['entity_id']='cannon';self.assertTrue(validate(self.m))
    def test_no_guessed_cycle(self):self.m['tables']['recipes'][0]['cycle_seconds']=20;self.assertTrue(validate(self.m))
    def test_formula_empty(self):self.assertEqual(expansion_quote({})['raw_cost'],dict(coin='5',garment='0',jewelry='0',novice='4',brother='0',father='0'))
    def test_pikemen_four(self):
        q=expansion_quote({'pikemen':4})['raw_cost'];self.assertEqual((q['coin'],q['novice']),('13','6'))
    def test_mixed_stone(self):
        q=expansion_quote(dict(pikemen=4,musketeers=2,cavaliers=1,cannons=1,stone_towers=1))['raw_cost']
        self.assertEqual(q,dict(coin='23',garment='9',jewelry='4',novice='9.7',brother='2.8',father='0.9'))
    def test_wood(self):
        q=expansion_quote({'wooden_towers':1})['raw_cost'];self.assertEqual(q['novice'],'5.8');self.assertEqual(q['brother'],'0.9')
    def test_no_rounded_quote(self):self.assertIsNone(expansion_quote({'stone_towers':1})['payable_integer_cost'])
    def test_negative_input(self):self.assertRaises(ReferenceError,expansion_quote,{'pikemen':-1})
    def test_float_input(self):self.assertRaises(ReferenceError,expansion_quote,{'pikemen':1.5})
    def test_bool_input(self):self.assertRaises(ReferenceError,expansion_quote,{'pikemen':True})
    def test_typo_input(self):self.assertRaises(ReferenceError,expansion_quote,{'pikeman':1})
    def test_wrong_profile(self):self.assertRaises(ReferenceError,expansion_quote,{},'pre_108_documented')
    def test_wrong_owner(self):self.assertRaises(ReferenceError,expansion_quote,{},ownership='enemy_player')
    def test_no_guessed_modifier(self):self.assertRaises(ReferenceError,expansion_quote,{},modifiers=['evil_eye'])
    def test_destroyed_tower_not_auto_counted(self):
        alive=expansion_quote({'pikemen':4});tower=expansion_quote({'pikemen':4,'stone_towers':1});self.assertEqual(alive['raw_cost']['coin'],'13');self.assertEqual(tower['raw_cost']['coin'],'19')
    def test_determinism(self):self.assertEqual(expansion_quote({'musketeers':7}),expansion_quote({'musketeers':7}))
    def test_musketeer_before(self):self.assertEqual(recruitment_quote(PROFILES[0],'musketeer','stronghold')['resource_cost'],{'coin':1,'weapon':1,'coal':1})
    def test_musketeer_after(self):self.assertEqual(recruitment_quote(PROFILES[1],'musketeer','stronghold')['resource_cost'],{'coin':2,'weapon':1,'coal':2})
    def test_cavalier_food_changed(self):
        q=recruitment_quote(PROFILES[1],'cavalier','stronghold')['resource_cost'];self.assertIn('plain_food',q);self.assertNotIn('fancy_food',q)
    def test_cannon_after(self):
        q=recruitment_quote(PROFILES[1],'cannon','stronghold')['resource_cost'];self.assertEqual((q['weapon'],q['coal']),(1,2))
    def test_tavern_context(self):self.assertEqual(recruitment_quote(PROFILES[1],'pikeman','tavern')['resource_cost']['coin'],3)
    def test_missing_context_no_fallback(self):self.assertRaises(ReferenceError,recruitment_quote,PROFILES[1],'pikeman','stronghold')
    def test_foundry_quarantined(self):self.assertRaises(ReferenceError,recruitment_quote,PROFILES[1],'cannon','cannon_foundry')
    def test_history_no_inheritance(self):self.assertRaises(ReferenceError,recruitment_quote,'history_edition_unverified','cannon','stronghold')
    def test_recruit_many(self):self.assertEqual(recruitment_quote(PROFILES[1],'musketeer','stronghold',10)['resource_cost']['coin'],20)
    def test_recruit_negative(self):self.assertRaises(ReferenceError,recruitment_quote,PROFILES[1],'musketeer','stronghold',-2)
    def test_bertram(self):self.assertEqual(general_bonus(PROFILES[1],'bertram')['documented_attributes']['melee_damage_bonus'],.3)
    def test_albert_regen(self):self.assertEqual(general_bonus(PROFILES[1],'albert')['documented_attributes']['regeneration_speed_multiplier'],2)
    def test_general_unknown(self):self.assertRaises(ReferenceError,general_bonus,PROFILES[1],'arthur')
    def test_general_damage_formula_unknown(self):self.assertIsNone(general_bonus(PROFILES[1],'bertram')['damage_composition'])
    def test_generalissimo_exclusions(self):
        q=generalissimo_metric([{'id':'a','victim_relation':'hostile','killer_kind':'army','count':20},{'id':'b','victim_relation':'neutral','killer_kind':'army','count':100},{'id':'c','victim_relation':'hostile','killer_kind':'fortification','count':90}]);self.assertEqual(q['eligible_kills'],20);self.assertTrue(q['threshold_met']);self.assertIsNone(q['awarded_vp'])
    def test_generalissimo_below(self):self.assertFalse(generalissimo_metric([{'id':'a','victim_relation':'hostile','killer_kind':'army','count':19}])['threshold_met'])
    def test_duplicate_kill_id(self):
        e={'id':'a','victim_relation':'hostile','killer_kind':'army','count':1};self.assertRaises(ReferenceError,generalissimo_metric,[e,e])
    def test_coop_scope(self):
        r=next(r for r in self.m['tables']['patch_rules'] if r['id']=='coop_shared');self.assertEqual(r['scope'],'coop_112_documented');self.assertNotIn('resources',r['value'])
    def test_occult_six_separate(self):
        r=[r for r in self.m['tables']['technologies'] if r.get('board_id')=='occult_science'];self.assertEqual(len(r),6);self.assertTrue(all(x['cleric_cost'] is None for x in r))
    def test_pacifist_not_invented(self):self.assertIsNone(next(r for r in self.m['tables']['victory_points'] if r['id']=='pacifist')['metric'])
    def test_campaign_baseline_not_overwritten(self):
        p=Path(__file__).resolve().parents[2]/'baseline_v21/v21/data/original_master.json';old=load(p)['tables']['initial_stock'];now=self.m['tables']['initial_stock'];self.assertEqual([{k:v for k,v in r.items() if k!='scope'} for r in now],old)
    def test_old_conflicts_preserved(self):self.assertIsNone(next(r for r in self.m['tables']['rules'] if r['id']=='carrier_capacity')['value'])
    def test_half_unit_not_silently_rounded(self):self.assertEqual(expansion_quote({'pikemen':1})['raw_cost']['novice'],'4.5')
    def test_invalid_decimal_rejected(self):self.m['tables']['expansion_formulas'][0]['constant']='NaN';self.assertTrue(validate(self.m))

if __name__=='__main__':unittest.main(verbosity=2)
