# 87. 물류 큐·복구 정책 (v18)

## 작업 상태
Requested → Reserved → Assigned → Pickup → InTransit → Delivered → Completed. 실패 시 Cancelled 또는 RetryPending.

## 불변 조건
`available = on_hand - reserved_out >= 0`; 배송 중 재고는 창고와 운반자 양쪽에 중복 집계하지 않는다. 예약 취소 시 재고를 되돌리지 않고 예약 수량만 해제한다(픽업 이전). 픽업 이후 실패 시 운반자가 보유한 화물을 복구 경로로 이동시킨다.

## 배차 평가
`score = 4*starvation + 2*critical_chain + waiting_seconds/30 - path_cost - congestion_penalty`. 가중치는 원작 미검증 예시. starvation은 작업장 재료가 0인 상태의 가중치, critical_chain은 승리 목표의 선행 체인 여부.

## 교착 방지
1. 생산 작업장별 버퍼 상한
2. 운송 예약 만료 시간과 원자적 예약
3. 실패 작업 재시도 횟수 상한 및 대기 지수 증가
4. 도로 변경 이벤트에서 경로 무효화 및 재탐색
5. 창고 철거 시 신규 예약 금지 → 진행 화물 회수 → 철거 완료

## QA
도로 단절, 중복 예약, 창고 철거, 운반자 소멸, 가득 찬 목적지, 반복 배송 실패 시 자원 보존과 유한 시간 내 복구를 검사한다.
