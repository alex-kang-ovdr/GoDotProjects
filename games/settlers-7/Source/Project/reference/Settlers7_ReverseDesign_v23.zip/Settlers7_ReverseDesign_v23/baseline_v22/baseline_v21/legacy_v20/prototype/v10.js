// v10: one continuous map for spatial sector construction, roads and shared regional logistics.
// Prototype reconstruction, not verified original Settlers 7 values.
(() => {
'use strict';
const WIDTH=900,HEIGHT=500,CELL=25,COLS=36,ROWS=20;
const CENTERS=[[445,235],[210,120],[685,120],[450,385],[125,355],[760,355]];
const KINDS={wood:['벌목소','🌲'],stone:['채석장','⛏'],farm:['농장','🌾'],saw:['제재소','🪵'],mill:['제분소','⚙'],bakery:['제빵소','🍞']};
let spatial=[],roads=[],mode='inspect',currentKind='wood',selected=0,roadId=0;
const root=document.createElement('section');root.className='panel';root.style.margin='14px';root.innerHTML=`<h2>v10 · 통합 월드 맵</h2><p class="hint">한 좌표계에서 섹터, 도로, 작업장, 지역 운송대, 원정대를 표시합니다. 지역별 재고는 v9와 공유합니다. 원작과 달리 섹터 내부 운반자 AI는 아직 구현되지 않았습니다.</p><div style="display:flex;flex-wrap:wrap;align-items:center;gap:5px"><button id="v10inspect">선택</button><button id="v10road">도로 건설 (원목1)</button><button id="v10build">작업장 건설 (원목2·석재1)</button><select id="v10kind">${Object.entries(KINDS).map(([k,v])=>`<option value="${k}">${v[0]}</option>`).join('')}</select><button id="v10center">수도 보기</button><span id="v10status" class="pill"></span></div><canvas id="v10map" width="900" height="500" style="max-width:100%;width:100%;cursor:crosshair"></canvas><div id="v10info" class="pill"></div>`;
document.querySelector('.layout').insertAdjacentElement('beforebegin',root);
const map=root.querySelector('#v10map'),ctx=map.getContext('2d');
function owner(x,y){let best=Infinity,id=0;for(let i=0;i<CENTERS.length;i++){const d=(CENTERS[i][0]-x)**2+(CENTERS[i][1]-y)**2;if(d<best){best=d;id=i}}return id}
function key(x,y){return `${x},${y}`}
function occupied(x,y){return spatial.some(b=>b.x===x&&b.y===y)||roads.some(b=>b.x===x&&b.y===y)}
function seed(){spatial=[];roads=[];roadId=0;selected=0;mode='inspect';for(let i=0;i<6;i++){const x=Math.floor(CENTERS[i][0]/CELL),y=Math.floor(CENTERS[i][1]/CELL);roads.push({id:++roadId,x,y,sector:i,hub:true})}}
function nearRoad(x,y,s){return roads.some(r=>r.sector===s&&Math.abs(r.x-x)+Math.abs(r.y-y)<=1)}
function put(x,y){const px=x*CELL+CELL/2,py=y*CELL+CELL/2,s=owner(px,py);selected=s;selected8=s;
 if(mode==='inspect'){render();return}
 if(kingdom.sectors[s]!==0){log('자신이 소유한 섹터에만 건설할 수 있습니다');render();return}
 if(occupied(x,y)){log('이미 점유된 타일입니다');render();return}
 const inv=sectors8[s].inventory;
 if(mode==='road'){
  if((inv.wood||0)<1){log('도로 건설에 원목 1개 필요');render();return}
  if(!nearRoad(x,y,s)){log('도로는 같은 섹터의 기존 도로에 연결해야 합니다');render();return}
  inv.wood--;roads.push({id:++roadId,x,y,sector:s,hub:false});log('도로 건설 완료');
 }else if(mode==='build'){
  if(s===0){log('수도 작업장은 기존 타일 건설 UI를 이용하세요');render();return}
  if(!nearRoad(x,y,s)){log('작업장은 같은 섹터 도로에 인접해야 합니다');render();return}
  if((inv.wood||0)<2||(inv.stone||0)<1){log('작업장 건설에는 원목 2개, 석재 1개가 필요');render();return}
  const before=sectors8[s].buildings.length;
  // v9 is the authoritative economic producer; its constructor performs resource debit.
  createSpatialWorkshop(s,currentKind,x,y,before);
 }
 render();
}
function createSpatialWorkshop(s,kind,x,y,before){
 // v9's createWorkshop is private, so use the same schema and single authoritative inventory.
 const inv=sectors8[s].inventory;if(sectors8[s].buildings.length>=12){log('지역 작업장 한도 12개');return}
 inv.wood-=2;inv.stone-=1;
 const next=Math.max(0,...sectors8.flatMap(a=>(a.buildings||[]).filter(b=>b&&typeof b==='object').map(b=>b.id||0)))+1;
 sectors8[s].buildings.push({id:next,type:kind,progress:0,produced:0,blocked:false});
 spatial.push({id:next,sector:s,x,y,kind});log(`${SECTOR_NAMES[s]}: ${KINDS[kind][0]} 건설 (지역 생산 시스템 연결)`);
}
function renderMap(){ctx.clearRect(0,0,WIDTH,HEIGHT);
 for(let y=0;y<ROWS;y++)for(let x=0;x<COLS;x++){
  const s=owner(x*CELL+CELL/2,y*CELL+CELL/2),o=kingdom.sectors[s];ctx.fillStyle=o===0?'#315d46':o===1?'#69433e':'#555b46';ctx.fillRect(x*CELL,y*CELL,CELL,CELL);
  ctx.strokeStyle='#ffffff0b';ctx.strokeRect(x*CELL,y*CELL,CELL,CELL);
  if(x>0&&owner((x-.5)*CELL,y*CELL+CELL/2)!==s){ctx.strokeStyle='#d4c39a77';ctx.beginPath();ctx.moveTo(x*CELL,y*CELL);ctx.lineTo(x*CELL,(y+1)*CELL);ctx.stroke()}
 }
 for(const r of roads){ctx.fillStyle=r.hub?'#d6bd7a':'#b7a887';ctx.fillRect(r.x*CELL+7,r.y*CELL+7,11,11)}
 for(const b of spatial){ctx.font='18px sans-serif';ctx.textAlign='center';ctx.fillText(KINDS[b.kind]?.[1]||'▣',b.x*CELL+12,b.y*CELL+18)}
 for(let i=0;i<6;i++){const [x,y]=CENTERS[i];ctx.fillStyle=i===selected?'#ffe3a4':'#f1e6c9';ctx.textAlign='center';ctx.font='bold 14px sans-serif';ctx.fillText(SECTOR_NAMES[i],x,y-24);ctx.font='11px sans-serif';ctx.fillText(kingdom.sectors[i]===0?'아군':kingdom.sectors[i]===1?'적군':'중립',x,y-10)}
 // All inter-sector movements are displayed in the same world coordinates.
 for(const c of caravans){const a=CENTERS[c.from],b=CENTERS[c.to],p=Math.max(0,Math.min(1,c.progress));const x=a[0]+(b[0]-a[0])*p,y=a[1]+(b[1]-a[1])*p;ctx.fillStyle='#f3d16b';ctx.beginPath();ctx.arc(x,y,7,0,7);ctx.fill();ctx.fillStyle='#1b3026';ctx.font='bold 11px sans-serif';ctx.fillText('C',x,y+4)}
 if(typeof expeditions!=='undefined')for(const e of expeditions){const a=CENTERS[e.from],b=CENTERS[e.to],p=Math.max(0,Math.min(1,e.progress));const x=a[0]+(b[0]-a[0])*p,y=a[1]+(b[1]-a[1])*p;ctx.fillStyle=e.owner===0?'#f6f1bc':'#f48e83';ctx.beginPath();ctx.arc(x,y,8,0,7);ctx.fill();ctx.fillStyle='#17231f';ctx.fillText('⚔',x,y+4)}
 for(const b of battles){const [x,y]=CENTERS[b.to];ctx.strokeStyle='#f49b78';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,18+b.progress*9,0,7);ctx.stroke()}
 const inv=sectors8[selected]?.inventory||{};root.querySelector('#v10status').textContent=`${SECTOR_NAMES[selected]} · ${mode==='road'?'도로 배치':mode==='build'?'작업장 배치':'선택'}`;
 root.querySelector('#v10info').textContent=`선택 섹터 재고: ${Object.entries(inv).map(([k,v])=>`${k} ${v}`).join(' / ')} · 지도 작업장 ${spatial.length}개 · 도로 ${roads.length}칸 · 운송 ${caravans.length}건`;
}
map.addEventListener('click',e=>{const r=map.getBoundingClientRect(),x=Math.floor((e.clientX-r.left)/r.width*COLS),y=Math.floor((e.clientY-r.top)/r.height*ROWS);if(x>=0&&x<COLS&&y>=0&&y<ROWS)put(x,y)});
for(const [id,m] of [['v10inspect','inspect'],['v10road','road'],['v10build','build']])root.querySelector('#'+id).onclick=()=>{mode=m;render()};
root.querySelector('#v10kind').onchange=e=>{currentKind=e.target.value};root.querySelector('#v10center').onclick=()=>{selected=0;selected8=0;render()};
const prevInit=init,prevTick=tick,prevRender=render,prevSave=snapshot,prevLoad=restore,prevTests=tests;
init=function(){prevInit();seed()};tick=function(dt){prevTick(dt)};
render=function(){prevRender();renderMap()};
snapshot=function(){return {...prevSave(),version:10,spatial,roads,roadId,selected10:selected}};
restore=function(d){if(!d||![9,10].includes(d.version))throw Error('v9/v10 저장만 지원');prevLoad(d.version===10?{...d,version:9}:d);seed();if(d.version===10){spatial=Array.isArray(d.spatial)?d.spatial:[];roads=Array.isArray(d.roads)?d.roads:roads;roadId=d.roadId||roads.length;selected=d.selected10||0;selected8=selected}};
tests=function(){prevTests();const checks=[['통합 지도 섹터 좌표',CENTERS.every(([x,y],i)=>owner(x,y)===i)],['건물 소속 섹터 일치',spatial.every(b=>owner((b.x+.5)*CELL,(b.y+.5)*CELL)===b.sector)],['지도 중복 배치 없음',new Set([...roads,...spatial].map(b=>key(b.x,b.y))).size===roads.length+spatial.length],['지도 건물 생산 객체 연결',spatial.every(b=>sectors8[b.sector].buildings.some(w=>w&&w.id===b.id&&w.type===b.kind))],['v10 저장 직렬화',!!JSON.stringify(snapshot())]];document.querySelector('#tests').innerHTML+=checks.map(([n,ok])=>`<div>${ok?'✅':'❌'} ${n}</div>`).join('')};
document.querySelector('#save').onclick=()=>{localStorage.setItem('settlers7_v10',JSON.stringify(snapshot()));log('v10 저장 완료');render()};
document.querySelector('#load').onclick=()=>{try{const raw=localStorage.getItem('settlers7_v10')||localStorage.getItem('settlers7_v9');if(!raw)throw Error('저장 파일 없음');restore(JSON.parse(raw));log('불러오기 완료')}catch(e){log('불러오기 실패: '+e.message)}render()};
document.querySelector('#reset').onclick=()=>{init();render()};document.querySelector('#test').onclick=tests;
window.S7Spatial={get roads(){return roads},get buildings(){return spatial},owner,CELL,COLS,ROWS};
seed();render();
})();
