# 밸런스 데이터 — The Settlers 7 역기획

> v2 고도화: 역기획과 개발용 재구성 모델을 구분한다.

## 시스템 명세 — 데이터 테이블

### 1. 테이블 관계
resource.id←recipe.inputs/outputs; building.id←workshop.parent; technology.effects→building/recipe.

**입력:** 플레이어 명령, 월드/재고 상태, 이전 틱 이벤트.  
**출력:** 상태 변화, 이벤트 로그, UI 피드백.  
**예외:** 참조 대상 소멸, 예약 취소, 저장/로드 중복 적용을 처리한다.

### 2. 단위
시간 초, 거리 타일, 수량 정수, 속도 타일/초로 통일한다.

**입력:** 플레이어 명령, 월드/재고 상태, 이전 틱 이벤트.  
**출력:** 상태 변화, 이벤트 로그, UI 피드백.  
**예외:** 참조 대상 소멸, 예약 취소, 저장/로드 중복 적용을 처리한다.

### 3. 원작과 추정
sourceStatus=verified/reference/inferred/prototype로 표시하며 미확인 수치를 원작 값으로 오인하지 않는다.

**입력:** 플레이어 명령, 월드/재고 상태, 이전 틱 이벤트.  
**출력:** 상태 변화, 이벤트 로그, UI 피드백.  
**예외:** 참조 대상 소멸, 예약 취소, 저장/로드 중복 적용을 처리한다.

### 4. 검증 규칙
참조 무결성, 음수 비용 금지, 순환 생산 체인 경고, 승리 조건 달성 가능성 검사.

**입력:** 플레이어 명령, 월드/재고 상태, 이전 틱 이벤트.  
**출력:** 상태 변화, 이벤트 로그, UI 피드백.  
**예외:** 참조 대상 소멸, 예약 취소, 저장/로드 중복 적용을 처리한다.

## 개발 구현 계약
```json
{
  "system": "15_Balance_Data",
  "version": 2,
  "tickInput": [
    "commands",
    "worldState",
    "events"
  ],
  "tickOutput": [
    "stateDelta",
    "emittedEvents",
    "diagnostics"
  ],
  "deterministic": true
}
```

## 핵심 테스트
- [ ] 테이블 관계: 정상 입력, 경계 입력, 취소/재시도 시 결과 검증
- [ ] 단위: 정상 입력, 경계 입력, 취소/재시도 시 결과 검증
- [ ] 원작과 추정: 정상 입력, 경계 입력, 취소/재시도 시 결과 검증
- [ ] 검증 규칙: 정상 입력, 경계 입력, 취소/재시도 시 결과 검증

## 자료 검증 및 표기
- **원작 기반 개념**: 공개된 게임 설명 및 기존 역기획 초안의 시스템 구조.
- **구현 제안**: 상태 머신, 알고리즘, 필드 구조, 수치와 최적화 목표. 원작 내부 코드와 동일함을 의미하지 않음.
- 참고: https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/game-basics/buildings
- 참고: https://en.wikipedia.org/wiki/The_Settlers_7%3A_Paths_to_a_Kingdom
