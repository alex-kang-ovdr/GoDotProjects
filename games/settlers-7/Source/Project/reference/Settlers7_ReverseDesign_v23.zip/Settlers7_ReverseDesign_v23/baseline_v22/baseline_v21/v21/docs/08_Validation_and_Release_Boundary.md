# 08. 검증 결과의 의미

## 실행한 검사

`python v21/tools/run_tests.py`로 50개의 자동 테스트를 수행한다. 현재 결과는 `reports/test_results.json`, 콘솔 기록은 `reports/test_console.txt`에 있다. 원작 규칙을 실행한 게임 테스트가 아니라, 이번에 구축한 데이터와 보호 정책의 검사다.

검사에는 ID 중복·외래키·양수 비용·숫자 NaN·원료 누락·인구/상품 구분·무한 창고의 null 표현·출처 누락·충돌 자동 확정·문맥 복원 승격·캠페인 재고의 임의0채움·필드 근거 값 불일치·미확인 런타임 출력 차단을 포함한다. 일부 테스트는 의도적으로 데이터를 손상시켜 검사기가 실제 거부하는지 확인한다.

## 현재 실행 준비 상태

28개 생산 관계 중 가공 시간이 확인된 것은0개다. 물질 투입·산출 수량이 모두 명시된 사례는 도구와 제련2개다. 따라서 완전한 실행 파라미터를 갖춘 레시피는0개이며 원작 런타임 출력은 차단한다. 생산 관계 표를 확보한 것과 생산 속도 밸런스를 복원한 것은 다른 작업이다.

## 재실행

```bash
python v21/tools/validate.py
python v21/tools/run_tests.py
python v21/tools/export_reference.py --mode reference --output reference_export.json
# 아래 명령은 현재 자료의 미확인 값을 보호하기 위해 종료코드 2로 실패하는 것이 정상
python v21/tools/export_reference.py --mode runtime --output original_runtime.json
```

Python 3.10 이상과 표준 라이브러리만 필요하다. Excel·HTML 열람에는 Python이 필요 없다. XLSX는 편집용 뷰이며 수정 내용을 JSON에 자동으로 수입하지 않는다.

## 배포 범위

설치 파일이나 상용 원본 자료, 그림, 음악, 공식 번역, 대사 전체를 포함하지 않는다. 이전 ZIP은 `legacy_v20`에 보존한다. v21의 주산출물은 원작 근거에 연결된 데이터·분석 문서·검증 도구이며 새로운 플레이 가능한 게임 릴리스가 아니다. 전체 원작 콘텐츠 완성도 비율은 분모가 검증되지 않았으므로 제시하지 않는다.
