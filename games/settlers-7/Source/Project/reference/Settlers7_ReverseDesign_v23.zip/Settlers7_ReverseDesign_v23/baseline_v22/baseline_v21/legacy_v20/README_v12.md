# Settlers 7 Reverse Design v12

실행: `prototype/index.html`을 Chrome/Edge로 연다. v11 기능을 유지하고, v12 패널에 도로 철거 모드, 지역별 BFS 도달성 진단, 자동 검증을 추가했다.

**주의**: v12는 완전한 단일 월드 물류 시스템이 아니다. v11의 물류와 전략 계층을 그대로 유지한다. 브라우저 E2E 검증은 수행하지 않았다.
