# 구현 계약과 데이터 설계

> 분류: 역기획 기반 개발 명세. 별도 검증 없는 세부 수치·규칙은 구현 제안이며 원작 확정값이 아닙니다.

## 1. 시뮬레이션

고정 100ms 틱(제안), 렌더링과 분리, 시드 기반 난수, 이벤트 로그.

## 2. 서비스

WorldService, BuildingService, InventoryLedger, LogisticsService, ProductionService, ArmyService, VictoryService, AIPlanner.

## 3. 업데이트 순서

명령 적용→예약→운반자 이동→입고→생산→완제품 출고→전투/점령→VP→AI 판단→이벤트 송신.

## 4. 명령

Build, Demolish, AttachWorkshop, SetPriority, DispatchArmy, Trade, Research. 사전 조건과 실패 코드 명시.

## 5. 저장

schemaVersion, worldSeed, tick, entities, inventories, reservations, transportJobs, AIPlans, victoryPoints.

## 6. 데이터 무결성

참조 무결성, 예약 합계≤물리 재고, 이동 화물 이중 집계 금지, 이벤트 재생의 결정성.

## 7. 성능

공간 인덱스, 더티 그래프 재계산, 배치 AI, 오브젝트 풀링, 렌더 프러스텀 컬링.

## 8. 마이그레이션

v12→v13 데이터 마이그레이션은 설계 범위; 기존 웹 코드에 자동 반영되었다고 주장하지 않음.

## 구현 검증 기준

- 입력 조건과 실패 조건을 모두 기록한다.
- 상태 전이마다 이벤트를 남기고 저장·로드 후 불변식을 확인한다.
- 원작 확인값과 프로토타입 제안값을 별도 데이터로 관리한다.
