# 05. 캠페인·이벤트 데이터 재구축

기본 캠페인 12개에 대한 제목·도시·문헌상 시작 재고·승리 목표를 정리했다. 지도 좌표, 섹터 경계, 원본 스크립트, 실제 난이도별 저장 상태를 복원한 것은 아니다.

| 미션 | 제목 / 도시 | 승리 방식 | 필요 VP | 제공 VP | 재고 항목 수 | 출처 |
|---|---|---|---|---|---|---|
| m01 | The Dawn of Settlements / Mohnfelden | quest_board | 미확인 | 미확인 | 7 | [C01 · The Dawn of Settlements](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-1-a-conquest-begins/conquest-walkthrough) |
| m02 | Warfarers Welcome / Brem | quest_board | 미확인 | 미확인 | 8 | [C02 · Warfarers Welcome](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-1-a-conquest-begins/conquest-walkthrough/warfarers-welcome) |
| m03 | Novice Rising / Ochsenrath | quest_board | 미확인 | 미확인 | 9 | [C03 · Novice Rising](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-1-a-conquest-begins/conquest-walkthrough/novice-rising) |
| m04 | The Trading Apprentice / Winterlin | quest_board | 미확인 | 미확인 | 19 | [C04 · The Trading Apprentice](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-1-a-conquest-begins/conquest-walkthrough/the-trading-apprentice) |
| m05 | A Formidable Adversary / Moorach | quest_board_and_event | 미확인 | 미확인 | 15 | [C05 · A Formidable Adversary](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-1-a-conquest-begins/conquest-walkthrough/a-formidable-adversary) |
| m06 | Expanding an Empire / Wolffelden | victory_points | 3 | 6 | 16 | [C06 · Expanding an Empire](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-1-a-conquest-begins/conquest-walkthrough/expanding-an-empire) |
| m07 | Storm over the Meadows / Nienroth | victory_points | 4 | 6 | 16 | [C07 · Storm over the Meadows](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/storm-over-the-meadows) |
| m08 | The Foggy Fields / Sandbeken | victory_points | 5 | 10 | 23 | [C08 · The Foggy Fields](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/the-foggy-fields) |
| m09 | 100 Years of Peace / Kronstedt | victory_points | 5 | 10 | 26 | [C09 · 100 Years of Peace](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/100-years-of-peace) |
| m10 | The Father's Revenge / Seenbach | victory_points | 충돌: 6 또는 7 | 14 | 20 | [C10 · The Father's Revenge](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/the-fathers-revenge) |
| m11 | The Return of the Old King / Mordsweiler | victory_points | 6 | 15 | 26 | [C11 · The Return of the Old King](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/the-return-of-the-old-king) |
| m12 | The Final Frontier / Drakenau | victory_points | 7 | 16 | 26 | [C12 · The Final Frontier](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/the-final-frontier) |


M06부터 VP 중심 미션이 확인된다. M01~M05의 목표는 퀘스트보드 방식이므로 `required_vp=null`은 미확인과 별개로 `required_vp_state=not_applicable`로 해석한다. M10은 같은 공략이 6/14와 7점을 모두 주장하여 승리점수를 확정하지 않았다. M09는 주요 목표와 결론이5점이지만 중간 four points 문구가 있어 연구 레지스트리에 불일치를 남겼다.

## 시작 재고

`initial_stock.csv`의 211행은 문헌의 Starting Resources 항목이다. 목록에 없는 상품은 0이라고 채우지 않았으며, 작업장 내부 버퍼·운송 중 물자·다른 창고까지 합한 전체 저장 파일 재고라는 뜻도 아니다. 특정 판본·난이도에서 실제 초기 재고가 일치하는지 확인이 필요하다.

## 이벤트 구조

32개 이벤트 선택지와 62개 요구 항목을 분리했다. 하나의 장소에 여러 선택지가 있으므로 이벤트 행 수를 장소 수로 읽지 않는다. `interaction=combat`의 수량은 지불할 병력 비용이 아니라 **물리쳐야 할 기본 방어군**이다. delivery는 상품, clergy는 요구 성직자다. 대사 원문은 저장하지 않는다.

| 미션 | 장소 | 선택지 | 유형 | 기본 요구/방어군 | 보상 | 근거 상태 |
|---|---|---|---|---|---|---|
| m05 | Laboratory | Temporary Replacement | clergy | novice×10 | map_victory | documented |
| m05 | Laboratory | Protection Money | delivery | coin×10 | map_victory | documented |
| m06 | Enchanted Forest | Top Dog | combat | pikeman×5, musketeer×5 | thunderstorm | documented |
| m06 | Enchanted Forest | I Do Not Like Vegetables | delivery | meat×10 | victory_point×1 | documented |
| m06 | Enchanted Forest | Private Lessons | clergy | novice×3 | free_passage | documented |
| m07 | Royal Observatory | In the Service of Science | combat | pikeman×2, musketeer×2, cavalier×1 | victory_point×1 | documented |
| m07 | Royal Observatory | So Much Horsepower | delivery | horse×5 | treasure | documented |
| m07 | Royal Observatory | Changing the Weather | clergy | novice×10 | thunderstorm | documented |
| m08 | Misty Swamp | Ghost Hunting | combat | pikeman×3, musketeer×2, cavalier×2 | victory_point×1 | documented |
| m08 | Misty Swamp | Velvety Memories | delivery | garment×40 | marauder_army | documented |
| m08 | Misty Swamp | Eternal Peace | clergy | novice×8 | free_passage | documented |
| m09 | Cathedral | Striking Argumentation | combat | pikeman×4, musketeer×3, cavalier×2 | heavenly_wrath | documented |
| m09 | Cathedral | Roofing Ceremony | delivery | tool×45 | victory_point×1 | documented |
| m09 | Cathedral | Ora et Labora | clergy | novice×3, brother×2 | treasure | documented |
| m09 | Pilgrimage Site | Sacred Secrets | combat | pikeman×6, musketeer×3 | technology_architecture | documented |
| m09 | Pilgrimage Site | Quid pro Quo | delivery | beer×20, plain_food×15 | heavenly_wrath | documented |
| m09 | Pilgrimage Site | The Worthy Successor | clergy | novice×6, brother×3, father×2 | victory_point×1 | documented |
| m10 | White Palace | Bodyguards Gone Rogue | combat | pikeman×5, musketeer×2 | free_passage | documented |
| m10 | White Palace | Oh, How It Glitters and Sparkles | delivery | jewelry×40 | victory_point×1 | documented |
| m10 | White Palace | Being All Ears | clergy | novice×5, brother×2, father×1 | heavenly_wrath | documented |
| m11 | Enchanted Tower | I Don’t Believe in Witchcraft | combat | pikeman×5, musketeer×4, cavalier×3 | victory_point×1 | documented |
| m11 | Enchanted Tower | A Wicked Dress | delivery | garment×12, jewelry×8 | technology_forced_march | documented |
| m11 | Enchanted Tower | Healing Hands | clergy | novice×5, brother×3 | marauder_army | documented |
| m12 | Field of Mandrakes | David Versus Goliath | combat | pikeman×5, musketeer×2 | treasure | documented |
| m12 | Field of Mandrakes | Kingsized Wool | delivery | wool×60 | victory_point×1 | context_reconstructed |
| m12 | Field of Mandrakes | A Huge Favor | clergy | novice×5, brother×2, father×1 | earthquake | documented |
| m12 | Dark Fortress | In the Name of Honor | combat | pikeman×4, musketeer×3, cavalier×2 | marauder_army | documented |
| m12 | Dark Fortress | A Call for Arms | delivery | weapon×30 | victory_point×1 | documented |
| m12 | Dark Fortress | A Broken Man | clergy | novice×3, brother×2, father×1 | general | documented |
| m12 | Volcano | Awake the Dragon | combat | pikeman×4, musketeer×3, cavalier×2 | earthquake | documented |
| m12 | Volcano | Such a Big Magpie | delivery | jewelry×5 | treasure | documented |
| m12 | Volcano | I Scratch Your Back, You Scratch Mine | clergy | novice×6, brother×3, father×2 | victory_point×1 | documented |


개별 표의 출처는 C05~C12 해당 Event Location 소제목이며 `events.csv`의 URL과 위치에서 직접 추적한다. M12 Kingsized Wool은 비용 칸에 60만 표시되어, 같은 항목 설명의 Wool과 연결했다. 따라서 품목은 `context_reconstructed`이며 직접 명시된 값으로 승격하지 않는다.

## 중요한 원작 규칙: Base Cost는 고정 실행 비용이 아니다

개발팀 설명은 현재 보유 VP에 따라 이벤트의 병력·자원·성직자 요구가 바뀐다고 한다. 이번에 옮긴 Base Cost를 모든 시점의 고정 비용으로 사용해서는 안 된다. `cost_scaling_formula=null` 상태로 두고 `cost_basis=documented_base_not_current_dynamic_cost`를 명시했다. 실제 함수·반올림·미션별 예외는 미복원이다. [DEV · Developer Tips: From Inside The Studio](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/essentials/developer-tips/from-inside-the-studio) Volker Stuckmann

## 지도 재구축 입력 계약 — 제안

섹터 연결 그래프, 지형/배치 마스크, 자원 매장량, 초기 소유권, 캠프·방어시설, 이벤트 객체, 스크립트 트리거를 별도 파일로 둔다. 원본 지도 크기·좌표는 추정 생성하지 않는다. 자료가 없는 노드는 `missing_map_geometry` 상태로 로드하며 새 시뮬레이션용 지도를 원작 맵이라고 명명하지 않는다.

M10의 동맹은 VP를 공유하지만 자원·연구·교역소는 공유하지 않는다. UI의 동맹 점수 합산을 전역 경제 통합으로 해석하지 않는다. [C10 · The Father's Revenge](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/the-fathers-revenge)
