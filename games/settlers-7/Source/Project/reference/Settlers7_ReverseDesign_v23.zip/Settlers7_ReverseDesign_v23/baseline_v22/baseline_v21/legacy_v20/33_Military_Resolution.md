# 군사 전투 해석

> Settlers 7 역기획 v4 — 원작 확인 내용과 구현 제안을 분리합니다.

## 전투 흐름
`RECRUIT → ASSEMBLE → MARCH → ENGAGE → RESOLVE → CAPTURE / RETREAT`. 전투의 구체적인 사거리·피해량·병과 상성은 원작 확인 전까지 재구성 모델로만 사용한다.

## 전투 계산 제안
공격력 `A = Σ(unit.attack × aliveRatio × moraleModifier)`; 방어력 `D = Σ(unit.defense × terrainModifier)`. 전투는 고정 틱에서 처리하며 난수는 시드 기반 PRNG로 결정적으로 생성한다. 지역 소유권 변경은 전투가 끝난 후 단일 이벤트로 커밋한다.

## 테스트
동시 점령, 전투 중 소유권 변경, 병력 0, 행군 경로 단절, 저장·로드 후 동일 결과, 적 AI와 플레이어가 같은 규칙 사용을 검증한다.
