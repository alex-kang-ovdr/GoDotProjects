// v11: Spatial workshop transport. Experimental rules, not a reproduction of original balance.
(() => {
'use strict';
const S=window.S7Spatial;
const DEF={wood:{in:null,out:'wood',time:7},stone:{in:null,out:'stone',time:9},farm:{in:null,out:'grain',time:8},saw:{in:'wood',out:'plank',time:11},mill:{in:'grain',out:'flour',time:12},bakery:{in:'flour',out:'bread',time:13}};
let couriers=[],nextId=0,elapsed=0,delivered=0,completed=0;
const panel=document.createElement('section');panel.className='panel';panel.style.margin='14px';panel.innerHTML=`<h2>v11 · 도로 기반 작업장 물류</h2><p class="hint">v10 지도에 건설한 지역 작업장은 더 이상 지역 재고를 즉시 사용하지 않습니다. 허브에서 운반자가 도로를 따라 원료를 배송하고 완제품을 회수합니다. 각 지역에 운반자 2명이 배치됩니다. v9 패널에서 직접 건설한 비공간 작업장은 기존 방식으로 작동합니다.</p><div id="v11status" class="pill"></div><div id="v11couriers" style="max-height:190px;overflow:auto"></div><button id="v11test">v11 물류 검증</button><div id="v11results"></div>`;
document.querySelector('.layout').insertAdjacentElement('beforebegin',panel);
const map=document.querySelector('#v10map'),ctx=map.getContext('2d');
function k(x,y){return x+','+y}
function nearestHub(sector){return S.roads.find(r=>r.sector===sector&&r.hub)}
function path(sector,from,to){if(!from||!to)return null;const roads=new Set(S.roads.filter(r=>r.sector===sector).map(r=>k(r.x,r.y)));const target=k(to.x,to.y);let q=[from],seen=new Set([k(from.x,from.y)]),parents=new Map();for(let h=0;h<q.length;h++){let a=q[h],ak=k(a.x,a.y);if(ak===target){let out=[a];while(parents.has(ak)){a=parents.get(ak);ak=k(a.x,a.y);out.push(a)}return out.reverse()}for(let [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){let x=a.x+dx,y=a.y+dy,kk=k(x,y);if(!seen.has(kk)&&(roads.has(kk)||kk===target)){seen.add(kk);parents.set(kk,a);q.push({x,y})}}}return null}
function findBuilding(b){return sectors8[b.sector]?.buildings.find(w=>w&&typeof w==='object'&&w.id===b.id&&w.type===b.kind)}
function resetCouriers(){couriers=[];nextId=0;elapsed=0;delivered=0;completed=0;for(let s=1;s<6;s++){let hub=nearestHub(s);if(!hub)continue;for(let i=0;i<2;i++)couriers.push({id:++nextId,sector:s,x:hub.x,y:hub.y,route:[],index:0,progress:0,task:null,load:null})}}
function ensureState(b){let w=findBuilding(b);if(w&&!w.transport)w.transport={input:0,output:0,phase:'idle',progress:0,inTransit:0};return w}
function chooseTask(c){let hub=nearestHub(c.sector);if(!hub||kingdom.sectors[c.sector]!==0)return;const inv=sectors8[c.sector].inventory;for(let b of S.buildings.filter(b=>b.sector===c.sector)){let w=ensureState(b),d=DEF[b.kind];if(!w||!d)continue;let p=path(c.sector,hub,b);if(!p)continue;let st=w.transport;
  if(st.output>0&&!st.outReserved){st.outReserved=true;c.task={kind:'pickup',id:b.id,sector:b.sector,item:d.out};c.route=p;c.index=0;c.progress=0;return}
  if(d.in&&st.input+st.inTransit<1&&(inv[d.in]||0)>=1){inv[d.in]--;st.inTransit++;c.load=d.in;c.task={kind:'deliver',id:b.id,sector:b.sector,item:d.in};c.route=p;c.index=0;c.progress=0;return}
}}
function complete(c){let t=c.task;if(!t)return;let b=S.buildings.find(b=>b.id===t.id&&b.sector===t.sector),w=b&&ensureState(b),hub=nearestHub(c.sector);if(!w||!hub){if(c.load)sectors8[c.sector].inventory[c.load]=(sectors8[c.sector].inventory[c.load]||0)+1;c.task=null;c.load=null;return}let st=w.transport;
 if(t.kind==='deliver'){st.inTransit=Math.max(0,st.inTransit-1);st.input++;c.load=null;delivered++;c.task=null;c.route=[];c.x=hub.x;c.y=hub.y}
 else if(t.kind==='pickup'){st.output=Math.max(0,st.output-1);st.outReserved=false;c.load=t.item;c.task={kind:'return',id:t.id,sector:t.sector,item:t.item};c.route=path(c.sector,{x:b.x,y:b.y},hub)||[{x:b.x,y:b.y},hub];c.index=0;c.progress=0}
 else{let inv=sectors8[c.sector].inventory;inv[t.item]=(inv[t.item]||0)+1;delivered++;c.load=null;c.task=null;c.route=[]}}
function updateCourier(c,dt){if(!c.task)chooseTask(c);if(!c.task)return;let steps=dt*2.5;while(steps>0&&c.task){if(c.index>=c.route.length-1){complete(c);break}let delta=Math.min(1-c.progress,steps);c.progress+=delta;steps-=delta;let a=c.route[c.index],b=c.route[c.index+1];c.x=a.x+(b.x-a.x)*c.progress;c.y=a.y+(b.y-a.y)*c.progress;if(c.progress>=1-1e-8){c.index++;c.progress=0;c.x=b.x;c.y=b.y;if(c.index===c.route.length-1)complete(c)}}}
function updateProduction(dt){for(let b of S.buildings){let w=ensureState(b),d=DEF[b.kind];if(!w||!d||kingdom.sectors[b.sector]!==0)continue;let st=w.transport;if(st.output>=2){st.phase='출고 대기';continue}if(d.in&&st.input<1){st.phase='원료 배송 대기';continue}st.phase='생산';st.progress+=dt;if(st.progress>=d.time){st.progress-=d.time;if(d.in)st.input--;st.output++;w.produced=(w.produced||0)+1;completed++}}}
function drawCouriers(){ctx.save();for(let c of couriers){if(kingdom.sectors[c.sector]!==0)continue;ctx.beginPath();ctx.fillStyle=c.load?'#ffad57':'#f8e3a0';ctx.arc((c.x+.5)*S.CELL,(c.y+.5)*S.CELL,5,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#28221a';ctx.stroke()}ctx.restore()}
function ui(){panel.querySelector('#v11status').textContent=`운반자 ${couriers.filter(c=>c.task).length}/${couriers.length}명 작업중 · 배송 ${delivered}건 · 공간 작업장 생산 ${completed}회`;
 panel.querySelector('#v11couriers').innerHTML=S.buildings.map(b=>{let w=ensureState(b);return `<div class="pill" style="margin:4px 0">${SECTOR_NAMES[b.sector]} · ${b.kind} (${b.x},${b.y}) · ${w?.transport?.phase||'대기'} · 입력 ${w?.transport?.input||0} · 출력 ${w?.transport?.output||0}</div>`}).join('')||'지도에 작업장을 건설하세요.'}
function verify(){const checks=[['운반자 지역 일치',couriers.every(c=>c.sector>=1&&c.sector<6)],['재고 비음수',sectors8.every(s=>Object.values(s.inventory).every(v=>Number.isFinite(v)&&v>=0))],['작업장 연결',S.buildings.every(b=>!!findBuilding(b))],['물류 상태 비음수',S.buildings.every(b=>{let t=ensureState(b)?.transport;return !!t&&t.input>=0&&t.output>=0&&t.inTransit>=0})],['도로 경로 판정',S.buildings.every(b=>{let hub=nearestHub(b.sector);return !!hub&&(!path(b.sector,hub,b)||path(b.sector,hub,b).length>0)})]];panel.querySelector('#v11results').innerHTML=checks.map(([n,v])=>`<div>${v?'✅':'❌'} ${n}</div>`).join('');return checks.every(x=>x[1])}
const prevInit=init,prevTick=tick,prevRender=render,prevSave=snapshot,prevLoad=restore,prevTests=tests;
init=function(){prevInit();resetCouriers()};
tick=function(dt){ // Suppress v9's direct-inventory production for spatial workshops; other workshops keep v9 logic.
 const hidden=[];for(let s of sectors8){let spatialIds=new Set(S.buildings.filter(b=>b.sector===s.id).map(b=>b.id));let kept=[];for(let w of s.buildings){if(w&&typeof w==='object'&&spatialIds.has(w.id))hidden.push([s,w]);else kept.push(w)}s.buildings=kept}
 try{prevTick(dt)}finally{for(let [s,w] of hidden)s.buildings.push(w)}
 elapsed+=dt;updateProduction(dt);for(let c of couriers)updateCourier(c,dt)};
render=function(){prevRender();drawCouriers();ui()};
snapshot=function(){return {...prevSave(),version:11,couriers,delivered,completed,elapsed}};
restore=function(d){if(!d||![10,11].includes(d.version))throw Error('v10/v11 저장만 지원');prevLoad({...d,version:10});if(d.version===11&&Array.isArray(d.couriers)){couriers=d.couriers;delivered=d.delivered||0;completed=d.completed||0;elapsed=d.elapsed||0}else resetCouriers()};
tests=function(){prevTests();verify()};
for(let [id,fn] of [['save',()=>{localStorage.setItem('settlers7_v11',JSON.stringify(snapshot()));log('v11 저장 완료');render()}],['load',()=>{try{let raw=localStorage.getItem('settlers7_v11')||localStorage.getItem('settlers7_v10');if(!raw)throw Error('저장 없음');restore(JSON.parse(raw));log('불러오기 완료')}catch(e){log('불러오기 실패: '+e.message)}render()}],['reset',()=>{init();render()}],['test',tests]])document.getElementById(id).onclick=fn;
panel.querySelector('#v11test').onclick=verify;
resetCouriers();render();
})();
