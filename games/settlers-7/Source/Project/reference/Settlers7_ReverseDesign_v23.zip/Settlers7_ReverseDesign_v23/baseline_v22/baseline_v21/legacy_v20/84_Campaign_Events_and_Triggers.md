# v17 캠페인 미션 및 이벤트 트리거

## 미션 데이터
mission_id, objective_type, target_id, target_value, prerequisite_ids, fail_condition, reward_id, hint_id, timeout_seconds, evidence_status.

## 튜토리얼 순서
1. 본관과 작업장 배치 → 건설 미리보기 확인
2. 원재료 생산 → 생산 진행률 확인
3. 도로·창고 연결 → 운송 경로 확인
4. 중간재 체인 → 병목 경고 해결
5. 섹터 확보 → 세 전략 경로 비교
6. 승리 포인트 → 경쟁형 소유권 변화 체험

## 트리거 안전장치
- 목표 완료는 동일 미션에서 한 번만 발화
- 선행 목표 미완료 시 후속 목표 비활성화
- 저장·불러오기 후 이벤트 중복 실행 방지
- 플레이어가 목표 이전에 건설한 시설도 소급 인정
- UI 힌트는 사용자가 닫을 수 있고, 핵심 목표는 다시 조회 가능
