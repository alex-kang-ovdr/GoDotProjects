# 지역 확장과 승리 경쟁

> Settlers 7 역기획 v4 — 원작 확인 내용과 구현 제안을 분리합니다.

## 섹터 모델
섹터는 `owner`, `neighbors`, `resources`, `militaryStrength`, `tradeCost`, `religiousResistance`, `controlState`를 가진다. 중립 지역은 군사·무역·종교 방식으로 획득할 수 있으나 실제 원작의 섹터별 조건은 자료 대조가 필요하다.

## 승리 포인트 엔진
`VictoryRule {id, type: permanent|contested, predicate, owner, priority}`. 점수는 틱마다 전체 재계산하지 않고 건설·점령·기술·교역 이벤트에 반응하여 증분 갱신한다. 동점 및 동시 달성은 동일 틱에서 모든 이벤트를 처리한 뒤 판정한다.

## AI 우선순위 예시
경제 붕괴 방지 > 필수 원료 확보 > 저비용 승리 포인트 > 적의 승리 저지 > 장기 투자. 위험과 보상을 모두 계산하며, 임의 숫자는 원작 수치로 취급하지 않는다.
