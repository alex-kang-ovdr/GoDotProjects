# 세틀러 7 v22 — 판본별 원작 데이터 복원

v21을 보존하면서 공식 업데이트 기록의 변경 전후 수치와 후속 콘텐츠를 추가했다. 원본 게임 설치 파일을 추출한 결과가 아니며, 기존 웹 게임 코드는 변경하지 않았다.

## 주요 결과

| 구분 | 결과 |
|---|---|
| 통합 데이터 | 42개 표, 870개 행 |
| Excel | 44개 시트: 요약·계산기·데이터 표 42개 |
| 판본 관리 | 적용 범위가 명시된 참조 프로필 6개 |
| 모집 비용 | 1.08 전후, 모집 경로별 상품 요구량 28행 |
| 장군 | 변경 효과 13행; 기본 전투 능력치와 구분 |
| 평화적 확장 | 매수·포교 원식 6개, 계수 24개 |
| 후속 콘텐츠 | Occult Science 기술 6종, 협동 모드, 지도 변경 기록 |
| 원작 근거 | 출처 27개, 필드 근거 레코드 6,043개 |

기술 24개는 기본 18개와 별도 연구판 6개를 합친 명칭 수이다. VP 16행에는 중복 후보와 조건 미확인 항목이 있어, 독립적인 완성 규칙 16개를 의미하지 않는다. 지도 16행도 서로 다른 지도 16종을 뜻하지 않는다.

## 검증 결과

- 참조 데이터와 계산 코드 테스트 52개 통과.
- HTML 탐색·계산·검색·CSV 내려받기·모바일 폭 검사 14개 통과.
- Excel 공식 캐시 확인: 기본 예제 결과 23 / 9 / 4 / 9.7 / 2.8 / 0.9, 수식 오류 검색 0건.
- v21의 225개 파일은 `baseline_v21/`에 바이트 그대로 보존했다.

HTML은 Chromium에 파일 내용을 직접 로드해 검사했다. 환경 정책으로 `file://` 탐색은 차단되어 그 경로는 미검증이다. Excel은 생성 라이브러리 계산·OOXML 캐시·렌더링을 점검했으며, 데스크톱 Excel 자체를 구동한 검사는 아니다. 이 검사들은 원작 게임 플레이 테스트가 아니다.

## 실행

```bash
python tools/run_tests.py
python tools/reference_engine.py validate
python tools/reference_engine.py recruit --profile patch_108_documented --unit musketeer --location stronghold --count 10
python tools/reference_engine.py expansion --pikemen 4 --musketeers 2 --cavaliers 1 --cannons 1 --stone-towers 1
```

참조 엔진과 데이터 테스트는 Python 표준 라이브러리만 사용한다. 선택 도구 `check_viewer.py`만 Playwright와 Chromium이 필요하다. 데이터 조회는 `report.html`, 원본 행은 `data/original_master.json`, 수치 검산은 `Settlers7_Original_Data_v22.xlsx`를 사용한다.

## 중요한 제한

1.08 변경값은 제작사 패치 기록의 재게시본을 근거로 한다. 공식 호스팅 사본은 확보하지 못했다. 후속 업데이트는 Steam 공식 기록을 사용했다. 1.08 이후 모든 판본이나 History Edition에 같은 값이 유지된다고 자동 가정하지 않는다.

생산 시간 28종, 전투 기본 능력치, 전체 연구 비용·시간·연결, 포교 비용의 정수 반올림은 미확인이다. 소수 원식 값을 실제 필요한 정수 인원으로 내보내지 않는다. Cannon Foundry 아래 Cavalry로 표기된 의심 항목도 임의로 수정하지 않고 격리했다.

일반 시작 자원 변경으로 캠페인 시작 재고 211행을 덮어쓰지 않았으며, 협동 모드의 자원 보내기를 자동 공용 재고로 해석하지 않았다. 완전한 원작 실행용 데이터 내보내기는 차단되어 있다.
