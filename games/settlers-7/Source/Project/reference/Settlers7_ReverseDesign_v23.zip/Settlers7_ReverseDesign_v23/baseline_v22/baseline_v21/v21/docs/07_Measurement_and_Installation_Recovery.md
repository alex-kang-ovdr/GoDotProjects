# 07. 미확인 수치의 실증 복원 절차

## 이미 한 일과 아직 하지 않은 일

공개 매뉴얼·가이드·패치 자료를 읽고 표를 재작성했다. 실제 게임 설치 폴더 접근, 압축 포맷 해석, 메모리 덤프, 원본 실행 파일 실행은 하지 않았다. `inspect_install.py`는 사용자가 선택한 로컬 폴더의 후보 파일명·크기·선택적 해시만 수집한다. 데이터 추출기라고 부르지 않는다.

## 로컬 목록 만들기

Python 3.10 이상에서 실제 설치 폴더를 인수로 지정한다. 출력은 게임 폴더 바깥에 둔다.

```powershell
python v21/tools/inspect_install.py "D:\실제_게임_설치_폴더" --output installation_manifest.json --hash
```

이 경로는 예시이며 사용자의 설치 위치를 안다는 뜻이 아니다. 스크립트는 후보 확장자를 찾을 뿐 게임이 그 확장자를 사용한다고 가정하지 않는다. 파일을 수정하거나 DRM을 우회하지 않고, 출처가 불분명한 실행 파일도 내려받지 않는다. 심볼릭 링크는 따라가지 않는다. 해시 없이 실행하면 파일 내용은 읽지 않고 크기와 경로만 수집한다.

## 파일 증거로 승격하기 위한 최소 조건

에디션, 화면에 표시되는 빌드, 실행 파일 SHA256, 파일 상대경로·SHA256, 파서 버전, 발견한 실제 키, 값의 단위, 게임 내 교차확인 결과를 묶는다. 사람이 붙인 `iron_smelter`와 바이너리 내부 키를 같다고 처리하지 않는다. 암호화·압축 구조를 알 수 없으면 ‘미확인 포맷’으로 남긴다. 저작권 자산 전체 대신 필요한 숫자/관계와 근거 위치만 독립 레코드로 작성한다.

## 작업 시간 관찰

동일 빌드, 1배속, 기술 없음, 같은 식량 정책, 충분한 원료, 비어 있는 출력 창고를 기준 조건으로 한다. 작업자의 원료 수집·이동·애니메이션·완제품 배송 시간을 분리하여 기록한다. 입고 간격만 측정하면 물류 병목을 생산 주기로 오인한다. 최초 가동의 도구 수령과 빈손 이동은 반복 생산 주기에서 분리한다.

관측 1회로 확정하지 않는다. 최소 여러 완전한 주기의 표본을 모으고 중앙값·최솟값·이상치를 보관한다. 여기서 표본 개수 기준은 조사 절차 제안이지 원작 규칙이 아니다. `measurement_template.csv`는 빈 서식이며 실측 데이터가 들어 있지 않다.

## 우선순위

| ID | 대상 | 상태 | 확인할 내용 | 방법 |
|---|---|---|---|---|
| U01 | recipes.* | unknown | 모든 작업장 무부스트·무기술 기준 작업시간 | 원본 데이터 또는 이동/가공 분리 실측 |
| U02 | recipe_inputs.* | partial | 도구·제련 외 대부분 투입 수량 | 인게임 레시피 툴팁/원본 구조 대조 |
| U03 | recipes.* | partial | 도구·제련 외 무부스트 산출 수량 | 식량 미설정과 고급 식량 구분 |
| U04 | units.* | unknown | HP·공격 간격·사거리·탄약·피해식 | 판본 고정 원본 데이터/통제 전투 |
| U05 | technologies.* | unknown | 전체 연구 연결·성직자 비용·연구 시간 | 기술판 전체 툴팁/인접선 확인 |
| U06 | missions.m10 | conflicting | 같은 가이드가 6점/14종과 7점 승리를 모두 서술 | 해당 빌드 미션 승리 화면 확인 |
| U07 | missions.m09 | source_inconsistency | 5점 요구를 반복하지만 중간에 four points 문구 존재 | 5점은 주요 목표와 결론에서 일치; 문구 오류 별도 기록 |
| U08 | buildings.mountain_shelter | unknown | 확보한 비용 표에서 산악 오두막 수치 누락 | 인게임 건설 패널 확인 |
| U09 | buildings.* | partial | 산악 오두막·Lodge 3칸 문맥 확인; 본관별 최대 슬롯 원문 직접검증 보강 | 모든 본관 건설 미리보기 확인 |
| U10 | victory_points.abbey | unresolved_alias | 매뉴얼 Bishop’s See와 가이드 Abbey를 자동 병합하지 않음 | 영문 실행판 건물 승급 명칭 확인 |
| U11 | victory_points.* | partial | Sun King 최소5레벨·동점 유지 외 미확인 | 활성 VP 툴팁·동점 실험 |
| U12 | rules.food | partial | 제련 일반식량 1·귀족 일반식량 1·도축 고급식량 1 사례 확인 | 다른 작업장 부스트별 원료 차감 확인 |
| U13 | missions.* | unknown | 시작 재고·이벤트 비용의 패치/난이도 범위 미기재 | 저장 파일·실행 파일 SHA256·난이도 기록 |
| U14 | world_actions.geologist_search | unknown | 결과 3종은 확인, 발생 확률 미확인 | 복수 채굴 실측·원본 난수 분기 |
| U15 | workshops.* | unknown | 철거 도구 환급 수량·작업장 건설시간 | 공사 전후 도구/인구 계수 관찰 |
| U16 | sources.MAN | unavailable | PDF 이미지 확인 요청이 파일 크기 제한으로 실패 | 표/그림 단독 수치를 데이터에 옮기지 않음 |
| U17 | sources.fandom | excluded | 데모 기반 커뮤니티 자료 본문 접근 실패 | 리테일 확정값에 혼합하지 않음 |
| U18 | missions.m12 | context_reconstructed | Base Cost 60의 품목은 설명 문맥으로 Wool 연결 | 아이콘 또는 인게임 툴팁 확인 |
| U19 | buildings.* | unknown | 기능 해금 존재만 확인; 전체 명성 트리 연결/레벨 미복원 | 명성 패널별 화면 수집 |
| U20 | stock_and_transport | partial | 창고 수량은 확인; 선택거리·인계·혼재 적재 상세 미확인 | 배치별 물류 추적 |
| U21 | rules.carrier_capacity | needs_runtime_verification | 매뉴얼3과 개발팀팁5 충돌 | 빌드 고정 후 UI·저장 전후·이벤트 로그 대조 |
| U22 | building_levels.storehouse | needs_runtime_verification | 기본20/첫승급50과 첫승급20 충돌 | 빌드 고정 후 UI·저장 전후·이벤트 로그 대조 |
| U23 | events.*.cost_scaling_formula | needs_runtime_verification | 이벤트 Base Cost와 현재 VP에 따른 변동 비용 분리 | 빌드 고정 후 UI·저장 전후·이벤트 로그 대조 |
| U24 | workshops.farm | needs_runtime_verification | Farm 식량 부스트는 개발팀 설명 근거. 매뉴얼 누락으로 출처 구별 | 빌드 고정 후 UI·저장 전후·이벤트 로그 대조 |
| U25 | world_actions.geologist_search | needs_runtime_verification | 광맥 잔량 증가와 상품 생산 표현 차이 | 빌드 고정 후 UI·저장 전후·이벤트 로그 대조 |


## 즉시 검사 가능한 핵심 장면

창고 화물3/5 충돌은 운반자 출고 전후 창고 재고와 실제 적재량을 함께 기록한다. 첫승급20/50 충돌은 신규 창고에서 특정 상품을 한도까지 채워 확인한다. 지질학자는 광맥 잔량과 창고 광석을 동시에 관찰한다. M10은 임무 목표/VP 패널로6/7을 판별한다. 이벤트 비용은 현재VP가 달라질 때 동일 장소의 요구값을 비교한다. 그 결과를 계산식으로 추정할 때는 원본 확인값과 추정 함수를 별도 상태로 남긴다.
