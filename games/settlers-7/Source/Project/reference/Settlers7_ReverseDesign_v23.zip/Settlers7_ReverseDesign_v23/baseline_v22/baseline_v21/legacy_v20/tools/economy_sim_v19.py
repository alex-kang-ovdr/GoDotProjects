#!/usr/bin/env python3
"""Settlers 7 v19 illustrative logistics simulator. All values are prototype assumptions."""
import argparse, csv, json
from pathlib import Path
from collections import deque

ROOT=Path(__file__).resolve().parents[1]

def load_recipes():
    with (ROOT/'v15_recipes.csv').open(encoding='utf-8-sig',newline='') as f:
        return {r['id']:r for r in csv.DictReader(f)}

def simulate(recipe_id='bake_bread', seconds=600, carriers=2, workshops=2, travel=5, initial=100):
    recipes=load_recipes(); r=recipes[recipe_id]
    inp,out=r['input_resource'],r['output_resource']
    iq,oq,cycle=int(r['input_qty']),int(r['output_qty']),int(r['cycle_seconds'])
    assert min(seconds,carriers,workshops,travel,initial)>=0
    warehouse={inp:initial,out:0}; ws=[{'input':0,'output':0,'progress':0,'busy':0,'starved':0} for _ in range(workshops)]
    fleet=[{'remaining':0,'job':None} for _ in range(carriers)]
    pending=deque(); requested=set(); delivered=0; completed=0; consumed=0; busy_carrier=0
    for t in range(seconds):
        # finish deliveries; all material stays in explicitly accounted locations
        for c in fleet:
            if c['job']:
                c['remaining']-=1
                if c['remaining']<=0:
                    kind,i,qty=c['job']
                    if kind=='input': ws[i]['input']+=qty
                    else: warehouse[out]+=qty; delivered+=qty
                    requested.discard((kind,i)); c['job']=None
        for i,w in enumerate(ws):
            if w['output'] and ('output',i) not in requested:
                pending.append(('output',i,w['output'])); requested.add(('output',i))
            if w['input']<iq and not w['output'] and ('input',i) not in requested and warehouse[inp]>=iq:
                pending.append(('input',i,iq)); requested.add(('input',i))
        for c in fleet:
            if c['job'] or not pending: continue
            kind,i,qty=pending.popleft()
            if kind=='input':
                if warehouse[inp]<qty: requested.discard((kind,i));continue
                warehouse[inp]-=qty
            else:
                if ws[i]['output']<qty: requested.discard((kind,i));continue
                ws[i]['output']-=qty
            c['job']=(kind,i,qty); c['remaining']=max(1,travel)
        for w in ws:
            if w['output']: continue
            if w['progress'] or w['input']>=iq:
                if not w['progress']: w['input']-=iq; consumed+=iq
                w['progress']+=1;w['busy']+=1
                if w['progress']>=cycle:
                    w['progress']=0;w['output']+=oq;completed+=oq
            else:w['starved']+=1
        busy_carrier+=sum(c['job'] is not None for c in fleet)
        assert all(x>=0 for x in warehouse.values())
        assert all(w['input']>=0 and w['output']>=0 for w in ws)
    in_transit=sum(q for c in fleet if c['job'] for kind,i,q in [c['job']] if kind=='input')
    assert initial==warehouse[inp]+sum(w['input'] for w in ws)+in_transit+consumed
    return {'recipe':recipe_id,'seconds':seconds,'carriers':carriers,'workshops':workshops,'travel_seconds':travel,
      'delivered':delivered,'completed':completed,'throughput_per_min':round(delivered*60/max(1,seconds),3),
      'workshop_utilization':round(sum(w['busy'] for w in ws)/max(1,seconds*max(1,workshops)),3),
      'carrier_busy_ratio':round(busy_carrier/max(1,seconds*max(1,carriers)),3),
      'warehouse':warehouse,'queued_jobs':len(pending),'in_transit':sum(c['job'] is not None for c in fleet)}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--recipe',default='bake_bread');p.add_argument('--seconds',type=int,default=600);p.add_argument('--carriers',type=int,default=2);p.add_argument('--workshops',type=int,default=2);p.add_argument('--travel',type=int,default=5);p.add_argument('--initial',type=int,default=100)
 a=p.parse_args();print(json.dumps(simulate(a.recipe,a.seconds,a.carriers,a.workshops,a.travel,a.initial),ensure_ascii=False,indent=2))
