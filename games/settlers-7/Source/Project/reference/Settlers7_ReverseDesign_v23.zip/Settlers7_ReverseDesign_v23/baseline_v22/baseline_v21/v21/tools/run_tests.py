#!/usr/bin/env python3
import io,json,sys,unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
class RecordedResult(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.records=[]
    def addSuccess(self,test):super().addSuccess(test);self.records.append({'test':test.id(),'result':'PASS'})
    def addFailure(self,test,err):super().addFailure(test,err);self.records.append({'test':test.id(),'result':'FAIL','detail':self._exc_info_to_string(err,test)})
    def addError(self,test,err):super().addError(test,err);self.records.append({'test':test.id(),'result':'ERROR','detail':self._exc_info_to_string(err,test)})
def main():
    suite=unittest.defaultTestLoader.discover(str(BASE/'tests'),pattern='test_*.py')
    result=unittest.TextTestRunner(verbosity=2,resultclass=RecordedResult).run(suite)
    report={'total':result.testsRun,'passed':sum(r['result']=='PASS' for r in result.records),'failed':len(result.failures),'errors':len(result.errors),'tests':result.records,'scope':'reference-data integrity and negative fixtures; not original executable verification'}
    (BASE/'reports').mkdir(exist_ok=True);(BASE/'reports/test_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return not result.wasSuccessful()
if __name__=='__main__':sys.exit(main())
