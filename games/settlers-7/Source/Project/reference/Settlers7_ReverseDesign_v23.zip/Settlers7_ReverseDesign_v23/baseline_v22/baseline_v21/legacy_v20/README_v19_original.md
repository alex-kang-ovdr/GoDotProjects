# Settlers 7 Reverse Design v10

브라우저 프로토타입: `prototype/index.html` (로컬 파일로 실행)

v9 문서/데이터를 보존하고 `42_Continuous_World_Map_v10.md`, `prototype/v10.js`를 추가했습니다. v10은 하나의 연속 맵에서 지역별 작업장 배치와 도로를 표현합니다. 원작 고증 완료본이 아닌 개발용 프로토타입입니다.
