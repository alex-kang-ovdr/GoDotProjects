# 01. 원작 증거 범위와 충돌 처리

**2026-11-17 조사본 / Original-reference v21.1**

이 자료는 원작 문헌에서 읽은 게임 규칙과 수치를 독립적인 데이터 스키마로 다시 작성한 것이다. 원본 실행 파일, 저장 파일, 압축된 게임 데이터의 바이트를 추출한 결과가 아니다. 원작의 그래픽·음악·대사집·공략 원문은 재배포하지 않는다. 로컬 ID와 한국어 명칭은 편집용 이름이며 원본 내부 키 또는 공식 한국어 번역이 아니다.

## 적용 범위

기준은 2010년 원작 매뉴얼과 원작을 대상으로 작성된 Prima 가이드이다. History Edition, 데모, 출시판, 특정 패치, 난이도를 한 묶음으로 취급하지 않는다. 개별 자료에 실행 빌드가 명시되지 않았으면 `version_scope`에 미상으로 남긴다. 1.03 패치 문서에는 도축장 고급 식량 배정과 명성 보상 변경이 있어, 과거 매뉴얼의 수치가 모든 후속 판본에 그대로 적용된다고 볼 수 없다. [PATCH103 · Ubisoft Version History 1.03](https://static2.cdn.ubi.com/gamesites/thesettlers7/us/patchnotes/Settlers7_PatchNotes_v1_03.pdf)

## 근거 상태

| 상태 | 의미 | 엔진 확정값 사용 |
|---|---|---|
| documented | 문헌에 해당 내용이 존재 | 판본 확인 뒤 사용; 실측 완료와 다름 |
| derived | 명시된 증분으로 계산한 값 | 계산식과 출처를 함께 확인 |
| unknown | 확인하지 못함 | 금지; 0이나 임시값으로 자동 채움 금지 |
| conflicting | 서로 다른 값이 존재 | 금지; 후보값을 보존 |
| documented_profile_with_conflict | 선택한 문헌 프로필의 값이나 다른 설명과 충돌 | 해당 문헌 프로필 표시 없이 사용 금지 |
| context_reconstructed | 문맥으로 연결한 품목 등 | 별도 확인 필요 |
| editorial | 이 프로젝트의 ID·분류·번역·설계 해석 | 원작 사실로 인용 금지 |

현재 모든 원작 레코드의 `runtime_verified`는 false이다. 자료가 많아져도 이 값을 일괄 true로 바꾸지 않는다.

## 실제 발견한 출처 충돌

| ID | 대상 | 후보 및 처리 |
|---|---|---|
| CF01 | rules.carrier_capacity.value | MAN p.18: 3 / DEV Tobias Sandkuhl / Storehouses: 5 → 미확인 |
| CF02 | building_levels.storehouse.capacity | BLD Storehouse: L0×20, L1×50, L2×unlimited / DEV Tobias Sandkuhl / Storehouses: L1×20 → BLD_reference_only |
| CF03 | missions.m10.required_vp | C10 Victory requirement: 6 / C10 claim any seven: 7 → 미확인 |
| CF04 | world_actions.geologist_search.outcomes | MAN p.24: increase_mine_deposit_by_one / DEV Tobias Sandkuhl / The Geologist: produces_a_unit_of_mine_resource → MAN_reference_only |


CF01의 운반량은 매뉴얼 p.18의 3과 개발팀 팁 일부의 5를 모두 저장했다. `rules.carrier_capacity.value=null`이다. CF02는 건물 표에 기본20·첫승급+30이 명시되지만 개발팀 팁 일부가 첫승급20이라고 적는다. 건물 표의 20/50/무제한은 **BLD 참고 프로필**이지 판본 공통 확정값이 아니다. CF03은 동일 미션 공략 내부의 6점/7점 충돌이다. CF04는 지질학자의 광맥 잔량 증가와 상품 생산 표현 차이다. [MAN · Ubisoft UK PC Manual](https://files.replacementdocs.com/The_Settlers_7_-_UK_Manual_-_PC.pdf) / [BLD · Prima Guide / buildings](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/game-basics/buildings) / [DEV · Developer Tips: From Inside The Studio](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/essentials/developer-tips/from-inside-the-studio) / [C10 · The Father's Revenge](https://primagames.com/eguides/settlers-7-paths-to-a-kingdom/walkthrough/part-2-the-cost-of-victory/the-fathers-revenge)

## 문헌의 기술적 한계

매뉴얼 본문 텍스트는 읽었으나 원본 PDF 페이지 이미지 요청은 파일 크기 제한으로 실패했다. 따라서 아이콘에만 있는 비용, 도식 연결선, 픽셀에서만 보이는 수치를 전사하지 않았다. 패치 문서는 본문과 페이지 이미지를 확인했다. 가이드의 본문 표는 읽었지만 시작 재고가 난이도별로 동일한지는 확인하지 못했다.

## 승인 절차

1. 판본, 실행 파일 해시, 난이도, 게임 속도를 고정한다.
2. 개별 필드를 원본 파일 또는 반복 관찰로 대조한다. 현장 증거와 문헌 증거를 별개로 저장한다.
3. 충돌은 조건 차이인지 오류인지 검토한다. 리뷰어가 근거를 승인한 뒤 새 버전 레코드를 만든다.
4. 기존 문헌 주장은 삭제하지 않고 새 검증 레코드와 연결한다.

`source_conflicts.csv`는 미해결 항목, `field_provenance.jsonl`은 각 최상위 필드의 값·근거 상태·출처 위치를 기록한다. 중첩 비용 객체는 한 필드 단위 근거를 가지며, 개별 비용은 정규화된 비용 테이블에서도 확인할 수 있다.
