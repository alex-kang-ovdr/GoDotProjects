# v19 이산 시간 경제 시뮬레이션

## 목적 및 범위
v15 prototype 레시피를 사용하여 원료 조달→창고 예약→운반→작업장 가공→완제품 창고 입고를 1초 단위로 재현한다. 원작의 정확한 물류 알고리즘이나 생산시간을 확인한 결과가 아니다.

## 데이터 계약
- Recipe(id,input_resource,input_qty,output_resource,output_qty,cycle_seconds,evidence)
- Workshop(id,recipe_id,buffer_in,buffer_out,progress,state)
- Warehouse(stock: resource→integer,capacity)
- Carrier(id,state,job,remaining_seconds)
- Job(id,kind,resource,qty,source,destination,priority)

## 틱 순서
1. 완료된 운송 도착 처리 및 재고 이전
2. 작업장 투입 원료 예약 및 배송 요청
3. 운반자에게 작업 배정(동일 요청 중복 금지)
4. 원료가 도착한 작업장 생산 진행
5. 완제품 회수 요청 생성
6. 자원 보존·음수 재고·상태 정합성 검사

## 재고 회계
운반 중 화물은 원천 창고에서 즉시 차감하여 운반자 재고로 기록한다. 작업장 내부 버퍼와 창고 재고는 별도 장부이다. 소비된 원료와 생성된 산출물은 레시피 전환 로그에 기록한다. 취소된 운송은 원천 창고로 반납하거나 명시적인 유실 이벤트를 기록한다.

## 의도된 단순화
단일 창고, 운반자당 1화물, 고정 왕복 시간, 한 작업장당 하나의 레시피. v12 도로 그래프와의 직접 통합은 후속 과제이다.
