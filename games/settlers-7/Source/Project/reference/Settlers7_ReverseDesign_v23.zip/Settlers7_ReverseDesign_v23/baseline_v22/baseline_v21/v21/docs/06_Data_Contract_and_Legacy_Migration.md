# 06. 정본 데이터 계약과 이전 모델 격리

## 정본과 파생물

정본은 `v21/data/original_master.json`이다. CSV와 XLSX, HTML은 이를 읽기 위한 표현이며 원본 내부 데이터 덤프가 아니다. 안정적인 로컬 ID로 연결하고 이름 문자열로 외래키를 만들지 않는다. CSV는 UTF-8 BOM, 배열과 객체는 JSON 문자열, 빈 숫자 칸은 null이다. XLSX의 ‘미확인’ 텍스트는 표시용이며 원본 JSON 숫자 칸에 다시 그대로 넣지 않는다.

| 테이블 | 행 수 |
|---|---|
| resources | 26 |
| resource_groups | 2 |
| buildings | 11 |
| building_levels | 25 |
| map_structures | 8 |
| workshops | 28 |
| recipes | 28 |
| recipe_inputs | 29 |
| world_actions | 2 |
| food_policies | 6 |
| food_examples | 2 |
| units | 11 |
| unit_costs | 33 |
| generals | 6 |
| technologies | 18 |
| technology_effects | 29 |
| victory_points | 14 |
| missions | 12 |
| initial_stock | 211 |
| events | 32 |
| event_requirements | 62 |
| trade_offers | 3 |
| rules | 32 |
| unknowns | 25 |
| corrections | 12 |
| aliases | 8 |
| source_conflicts | 4 |
| sources | 20 |


## 구분해야 할 빈 값

- `null`: 미확인 또는 해당 없음. 주변 상태 필드와 함께 해석한다.
- `0`: 문헌에서 확인된 수량0 또는 명시된 정규화. 예: 무식량 모드 식량 비용0.
- `{}`: 확인된 비용 없음. 예: 추가 street 건설비.
- `[]`: 알려진 빈 목록. 연구 선행 기술은 모른다고 []로 쓰지 않는다.
- `unlimited_storage=true`: 무한 창고. 0용량이 아니다.

## 비용·식량·인구를 분리

`unit_costs`에는 물자와 식량 그룹만 저장하며 인구는 `units.population_cost`다. 건설은 `buildings.base_cost`와 `building_levels.cost`, 작업자의 첫 도구는 `workshops.startup_tool_qty`, 매회 가공 원료는 `recipe_inputs`다. 식량 소비는 food policy로 해석한다. 자료에 없는 정수 반올림/식량 품목 선택 순서는 엔진 기본값으로 숨겨 넣지 않는다.

## 이전 버전 정정

| 이전 단순화/가정 | 재구축 규칙 |
|---|---|
| 고급 생산 원료를 bread로 고정 | plain_food는 bread 또는 fish, fancy_food는 meat |
| 음식이 단순 생산시간 단축 | 산출 배율·기술 속도 변화 분리 |
| 운반자 1화물 | 1화물 단정 제거. MAN=3, DEV 일부=5 충돌; 공통값 null, 출처 프로필 분리. |
| 모든 자원 전역 공유 | 창고별 실물재고와 작업자/운반자 역할 분리 |
| 작업장이 섹터 재고 즉시 소비 | 근거리 창고 입출고·중계 운송 단계 필요 |
| 모든 플레이어 독립 연구 트리 | 선점 독점·상대 입찰·이벤트 예외 |
| 기본 도로 건설비 부과 | 추가 street 무료; 포장에 석재 필요 |
| 전력 합으로 즉시 공성 승리 | 원거리·탄약·교전·퇴각을 별개로 처리 |
| 도시 VP를 전체 인구로 계산 | Metropolis는 노동자·운반자·건설자 기준 |
| farm가 곡물을 직접 생산 | Farm 본관과 Grain Barn 작업장을 구별 |
| Geology 연구가 지질학자 모드를 해금 | Geologist는 명성 해금; Geology는 생산 시간 효과 |
| 프로토타입 생산초를 원작값으로 취급 | 미실측 시간 null; 엔진 실행용 임시값과 분리 |


원작 근거 링크는 `corrections.csv`에 개별 연결했다. `legacy_v20/`는 이전 파일을 바이트 그대로 보존한다. 이전 문서와 게임, 시뮬레이션은 원작 근거로 승격하지 않고 역사적 프로토타입으로만 사용한다.

## 네 가지 그래프

1. 물리 섹터 그래프: 소유권, 접경, 이동 허용 조건.
2. 물류 도로/창고 그래프: 실제 운반과 재고 인계.
3. 교역판 그래프: 원정 노드 해금과 통행 비용.
4. 기술판 그래프: 수도원 출발점, 선점, 경쟁 입찰.

원작은 서로 다른 화면/규칙을 갖는다. 그래프 분리는 신규 코드 구조 제안이며 원본 엔진 아키텍처를 역공학한 결과가 아니다. 세 전략을 같은 ‘자원 지불→즉시 섹터 획득’ 함수로 합치지 않는다.

## 수입 경계

`export_reference.py --mode reference`는 참고 데이터만 출력한다. `--mode runtime`은 현재 릴리스에서 명시적으로 실패하며 게임 실행용 파일을 쓰지 않는다. 먼저 필수 시간·전투·연구·이벤트 함수와 판본 충돌을 해결해야 한다. 프로토타입을 계속 개발할 때는 `prototype_override` 프로필을 별도로 만들고 화면·로그에 적용된 임시값을 표시한다. 참고 데이터에 덮어쓰지 않는다.

## 보존 감사

`reports/legacy_integrity.json`은 v20 파일의 경로·개수·SHA256 일치 결과를 기록한다. 이 검사는 기존 게임이 실행된다는 뜻이 아니다. 이번 작업에서 브라우저 게임 소스는 수정하지 않았고 신규 분석 데이터와 통합하지 않았다.
