# 89. AI 의사결정 추적·설명가능성 (v18)

## 계층
1. 목표: VP 경로, 방어, 경제 회복
2. 계획: 필요 자원/건물/운송/병력의 선행 조건 그래프
3. 실행: 합법적인 명령 큐에 투입

## 평가식 (프로토타입)
`utility = vp_gain*4 + urgency*2 - cost*1.2 - risk*1.5 - completion_time*0.5`. 지표는 정규화된 [0,1] 값을 사용한다.

## 재계획 이벤트
핵심 생산 중단, 지역 상실, 승리 포인트 변동, 적 원정 발견, 창고 단절, 60초 이상 정체. 무한 계획 변경을 막기 위해 전략 변경 최소 유지시간과 hysteresis를 사용한다.

## AI 로그 계약
`tick,player,goal,candidates,selected,score,prerequisites,resources_before,resources_after,reason,replan_trigger`를 저장한다. 자원 생성 치트와 원작 게임 AI 규칙을 구분한다.

## 검증
동일 seed 결정성, 불가능한 건설 명령 0건, 미해결 생산 정체 감지, 정상 자원 보존, 동일 상황의 반복 계획 변경 빈도 측정.
