#!/usr/bin/env python3
"""Validate reconstructed reference data. Passing is NOT proof of original-game fidelity."""
from __future__ import annotations
import argparse, csv, json, math, sys
from collections import Counter
from pathlib import Path
from typing import Any
BASE = Path(__file__).resolve().parents[1]
NON_FACT_TABLES = {'sources','unknowns','aliases','source_conflicts'}
META_FIELDS = {'source_id','locator','secondary_source_id','secondary_locator','trade_capacity_source_id','trade_capacity_locator','tie_source_id','slots_source_id','slots_locator','observed_slots_source_id','observed_slots_locator','minimum_source_id','minimum_locator'}

def load(path: Path | None = None) -> dict[str, Any]:
    return json.loads((path or BASE/'data/original_master.json').read_text(encoding='utf-8'))

def indexes(master):
    return {name: {row['id']: row for row in rows} for name, rows in master['tables'].items()}

def validate(master, provenance=None):
    errors = []
    t = master.get('tables', {})
    required = {'resources','resource_groups','buildings','building_levels','workshops','recipes','recipe_inputs','units','unit_costs','technologies','technology_effects','missions','initial_stock','events','event_requirements','sources','source_conflicts'}
    if not required <= t.keys(): return ['Missing required tables: '+str(sorted(required-t.keys()))]
    for name, rows in t.items():
        ids = [r.get('id') for r in rows]
        if any(not isinstance(x,str) or not x for x in ids): errors.append(f'{name}: invalid ID')
        for id,n in Counter(ids).items():
            if n > 1: errors.append(f'{name}.{id}: duplicate ID')
    ix = indexes(master)
    def ref(table, key, row, field):
        if key not in ix.get(table, {}): errors.append(f'{row.get("id")}.{field}: dangling {table} reference {key!r}')
    def walk(value, path):
        if isinstance(value,bool) or value is None: return
        if isinstance(value,(float,int)):
            if not math.isfinite(value) or value < 0: errors.append(f'{path}: non-finite or negative number')
        elif isinstance(value,dict):
            for k,v in value.items(): walk(v, f'{path}.{k}')
        elif isinstance(value,list):
            for i,v in enumerate(value): walk(v,f'{path}[{i}]')
    walk(master, 'master')
    for name, rows in t.items():
        for r in rows:
            if name not in NON_FACT_TABLES:
                ref('sources',r.get('source_id'),r,'source_id')
                if not r.get('locator'): errors.append(f'{name}.{r["id"]}: missing source locator')
                if r.get('runtime_verified') is not False: errors.append(f'{name}.{r["id"]}: runtime promotion requires a separately reviewed observation dataset')
    for r in t['sources']:
        if not r.get('url','').startswith('https://'): errors.append(f'{r["id"]}: invalid source URL')
        if not r.get('version_scope'): errors.append(f'{r["id"]}: missing version scope')
    for r in t['resource_groups']:
        if r['id'] in ix['resources'] or r['inventory_item'] is not False: errors.append(f'{r["id"]}: food group incorrectly treated as inventory')
        for x in r['members']: ref('resources',x,r,'members')
    for r in t['buildings']:
        for res in (r.get('base_cost') or {}): ref('resources',res,r,'base_cost')
    for r in t['building_levels']:
        ref('buildings',r['building_id'],r,'building_id')
        for res in (r.get('cost') or {}): ref('resources',res,r,'cost')
        if r.get('unlimited_storage') and r.get('capacity_per_resource') is not None: errors.append(f'{r["id"]}: unlimited with finite capacity')
    for r in t['workshops']: ref('buildings',r['parent_building_id'],r,'parent_building_id')
    for r in t['recipes']:
        ref('buildings' if r['producer_kind']=='building' else 'workshops',r['producer_id'],r,'producer_id')
        ref('resources',r['output_resource_id'],r,'output_resource_id')
        if r['cycle_seconds'] is not None and r['cycle_seconds'] <= 0: errors.append(f'{r["id"]}: non-positive cycle')
        if r.get('executable'): errors.append(f'{r["id"]}: catalog must not silently enable execution')
    pairs=set()
    for r in t['recipe_inputs']:
        ref('recipes',r['recipe_id'],r,'recipe_id'); ref('resources',r['resource_id'],r,'resource_id')
        k=(r['recipe_id'],r['resource_id'])
        if k in pairs: errors.append(f'{r["id"]}: duplicated recipe component')
        pairs.add(k)
        if r['qty'] is not None and r['qty'] <= 0: errors.append(f'{r["id"]}: non-positive ingredient')
        if r['qty'] is None and r['quantity_state'] != 'unknown': errors.append(f'{r["id"]}: null quantity marked confirmed')
    for r in t['units']:
        ref('buildings',r['training_building_id'],r,'training_building_id')
        valid=[x['upgrade_index'] for x in t['building_levels'] if x['building_id']==r['training_building_id']]
        if r['min_upgrade_index'] not in valid: errors.append(f'{r["id"]}: nonexistent training level')
    for r in t['unit_costs']:
        ref('units',r['unit_id'],r,'unit_id')
        ref('resource_groups' if r['requirement_kind']=='group' else 'resources',r['requirement_id'],r,'requirement_id')
        if r['qty'] <= 0: errors.append(f'{r["id"]}: non-positive cost')
    for r in t['technology_effects']: ref('technologies',r['technology_id'],r,'technology_id')
    for r in t['initial_stock']:
        ref('missions',r['mission_id'],r,'mission_id'); ref('resources',r['resource_id'],r,'resource_id')
        if r['unlisted_resource_policy'] != 'unknown_not_zero': errors.append(f'{r["id"]}: absent inventory was zero-filled')
    for r in t['events']:
        ref('missions',r['mission_id'],r,'mission_id')
        if r['cost_basis'] != 'documented_base_not_current_dynamic_cost': errors.append(f'{r["id"]}: base cost treated as runtime price')
    for r in t['event_requirements']:
        ref('events',r['event_id'],r,'event_id')
        ref({'unit':'units','group':'resource_groups','resource':'resources'}[r['requirement_kind']],r['requirement_id'],r,'requirement_id')
    for r in t['trade_offers']:
        ref('missions',r['mission_id'],r,'mission_id')
        for k in ['give_resource_id','get_resource_id']: ref('resources',r[k],r,k)
    for r in t['food_policies']:
        if r.get('food_group_id'): ref('resource_groups',r['food_group_id'],r,'food_group_id')
    for r in t['aliases']: ref({'resource':'resources','workshop':'workshops','unit':'units'}[r['domain']],r['canonical_id'],r,'canonical_id')
    for r in t['source_conflicts']:
        if len(r['claims'])<2: errors.append(f'{r["id"]}: conflict has fewer than two candidates')
        for c in r['claims']: ref('sources',c['source_id'],r,'claims.source_id')
    for r in t['missions']:
        if r['required_vp_state']=='conflicting' and r['required_vp'] is not None: errors.append(f'{r["id"]}: unresolved VP conflict silently resolved')
    # This release intentionally holds ambiguous carrier capacity unresolved.
    carrier = ix['rules']['carrier_capacity']
    if carrier['evidence_state']=='conflicting' and carrier['value'] is not None: errors.append('carrier capacity conflict silently resolved')
    if provenance is not None:
        actual={}
        for p in provenance:
            key=(p['table'],p['row_id'],p['field'])
            if key in actual: errors.append(f'{key}: duplicate field provenance')
            actual[key]=p
            r=ix.get(p['table'],{}).get(p['row_id'])
            if r is None or p['field'] not in r: errors.append(f'{key}: orphan provenance');continue
            if r[p['field']] != p['value']: errors.append(f'{key}: provenance value mismatch')
            if p['state'] not in {'unknown','editorial'} and (not p.get('source_id') or not p.get('locator')): errors.append(f'{key}: sourced fact missing evidence')
        expected={(name,r['id'],k) for name,rows in t.items() if name not in NON_FACT_TABLES for r in rows for k in r if k not in META_FIELDS}
        for key in sorted(expected-actual.keys()): errors.append(f'{key}: missing field provenance')
        for key in sorted(actual.keys()-expected): errors.append(f'{key}: unexpected field provenance')
    return errors

def readiness(master):
    t=master['tables']; blocked=[]
    for r in t['recipes']:
        missing=[]
        if r['cycle_seconds'] is None: missing.append('cycle_seconds')
        if r['output_qty'] is None: missing.append('output_qty')
        for x in t['recipe_inputs']:
            if x['recipe_id']==r['id'] and x['qty'] is None: missing.append('input_qty:'+x['resource_id'])
        if missing: blocked.append({'recipe_id':r['id'],'missing':missing})
    return {'reference_catalog_available':True,'original_runtime_export_allowed':False,
            'production_cycles_documented':sum(r['cycle_seconds'] is not None for r in t['recipes']),
            'recipe_count':len(t['recipes']),'fully_parameterized_recipes':len(t['recipes'])-len(blocked),
            'recipes_with_complete_material_quantities':sum(r['material_quantities_complete'] for r in t['recipes']),
            'unresolved_source_conflicts':len([x for x in t['source_conflicts'] if x['state']=='unresolved']),
            'blocked_recipes':blocked,
            'additional_blockers':['edition_and_build_not_pinned','combat_base_stats_unknown','technology_graph_and_research_cost_unknown','event_cost_scaling_unknown','no_original_game_file_extraction','no_runtime_observations'],
            'meaning':'Data-integrity checks are not original-game runtime or balance verification.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--master',type=Path);p.add_argument('--report',type=Path,default=BASE/'reports/validation.json');a=p.parse_args()
    m=load(a.master); proofs=[json.loads(l) for l in (BASE/'data/field_provenance.jsonl').read_text(encoding='utf-8').splitlines()]
    errors=validate(m,proofs)
    report={'errors':errors,'error_count':len(errors),'tables':{k:len(v) for k,v in m['tables'].items()},'field_provenance_count':len(proofs),'readiness':readiness(m)}
    a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'error_count':len(errors),'field_provenance_count':len(proofs),'original_runtime_export_allowed':False},ensure_ascii=False))
    if errors: print('\n'.join(errors[:20]),file=sys.stderr)
    return bool(errors)
if __name__=='__main__':sys.exit(main())
