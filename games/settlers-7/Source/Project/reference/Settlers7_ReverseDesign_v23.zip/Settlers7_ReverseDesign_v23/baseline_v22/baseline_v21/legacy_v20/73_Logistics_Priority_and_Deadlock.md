# 73. 물류 우선순위, 예약 및 교착 방지

## 물류 주문 데이터
`job_id`, `resource_id`, `quantity`, `source_id`, `target_id`, `priority`, `created_tick`, `expires_tick`, `reservation_id`, `status`, `route_version`.

## 상태 전이
`REQUESTED → RESERVED → ASSIGNED → PICKUP → IN_TRANSIT → DELIVERED`.
실패 경로는 `CANCELLED`, `RETRY_WAIT`, `FAILED`; 자원 보존을 위해 `RESERVED`에서 수량을 별도 원장에 잠근다.

## 우선순위 점수(prototype)
`score = 100*criticality + 15*starvation_seconds/30 + 10*age_seconds/60 - 2*estimated_travel_seconds - 30*route_risk`.
criticality: 건설 필수 3, 식량·기본 생산 2, 일반 생산 1, 잉여 재고 0. 범위와 가중치는 실험 데이터로 조절한다.

## 배차 규칙
1. 예약 가능한 출발 창고를 거리·재고·혼잡도로 비교한다.
2. 운반자의 현재 작업이 완료될 때만 새 작업을 할당한다.
3. 운송 중 도로가 끊기면 최신 그래프 버전으로 재탐색한다.
4. 우회 불가능 시 화물은 운반자에 유지하고 복구를 기다리거나 출발지로 복귀한다.
5. 예약 만료는 미픽업 상태에만 적용한다. 이미 픽업한 자원은 예약 해제가 아닌 운송 화물 원장으로 이동한다.

## 불변식
`총자원 = 창고 가용 + 창고 예약 + 작업장 입력 + 작업장 출력 + 운송 중 + 소비/생산 누적 조정`.
한 자원 단위는 오직 한 위치에만 존재한다. 중복 작업 취소 및 중복 도착 이벤트는 idempotency key로 무시한다.

## QA
- 도로 단절 중 운반자 저장·로드 후 재탐색
- 동일 자원을 두 작업장이 동시에 요청
- 창고 철거 직전 예약, 픽업 직후 취소
- 작업장 생산 중 철거와 출력 재고 반환
- 10분 동안 운반자가 이동하지 않는 starvation 탐지
