# 78. 원작 정확도·데이터 거버넌스

## 분류
- `verified`: 원작 화면·공식 자료에서 직접 확인, 출처·버전·조건 필수
- `observed`: 반복 플레이로 추정, 측정 절차·표본 필수
- `inferred`: 시스템 상호작용으로 유추, 반례 가능
- `prototype`: 자체 개발용 가정, 원작 수치 아님

## 필드별 증거
`entity_id`, `field`, `value`, `unit`, `status`, `source_url_or_capture`, `game_version`, `scenario`, `sample_count`, `reviewer`, `verified_at`.

## 승인 게이트
- verified 항목에 출처 누락 시 배포 차단
- prototype을 verified로 변경하려면 증거 기록 및 리뷰 필요
- 원작 관찰과 충돌하는 데이터는 삭제하지 않고 변경 이력에 보관
- 기존 문서의 원작 관련 미검증 서술은 별도 검증 백로그에 등록

## 저작권 주의
원작의 텍스트·대사·아트·음원을 그대로 재배포하지 않는다. 역기획 문서는 자체 설명과 데이터 구조로 작성한다.
