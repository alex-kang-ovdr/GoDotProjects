# 생산 레시피·처리량·병목 상세

## 생산 주기
1. 원료 수요 계산 및 배송 요청.
2. 작업장 버퍼 도착 후 원료 소비 확정.
3. 생산 진행률 갱신.
4. 완제품 버퍼에 적재.
5. 창고로 반출 예약.

## 예시 레시피 (원작 수치 아님)
| 레시피 | 투입 | 산출 | 주기(초) | 비고 |
|---|---|---|---:|---|
| saw_planks | log × 1 | plank × 1 | 15 | 가정 |
| mill_flour | grain × 1 | flour × 1 | 20 | 가정 |
| bake_bread | flour × 1 | bread × 1 | 20 | 가정 |
| smelt_iron | ore × 2, coal × 1 | iron × 1 | 30 | 가정 |
| forge_weapon | iron × 1, coal × 1 | weapon × 1 | 30 | 가정 |

## 생산량 계산
- 이론 처리량: `3600 / cycleSeconds * outputQuantity` (개/시간)
- 실효 처리량: `min(이론량, 원료 공급량, 운반량, 버퍼 처리량) * uptimeRatio`
- 목표 생산량으로 작업장 수 역산: `ceil(targetPerHour / effectivePerWorkshopHour)`.
- 생산량이 증가해도 배송 대기 시간이 늘면 실효 생산량은 감소할 수 있다.

## 병목 진단 우선순위
1. 원료 부족 2. 운반자 부족 3. 도로 단절 4. 완제품 적체 5. 노동력 부족.
- UI에는 현재 중단 원인과 최근 60초 생산/소비량을 함께 표시한다.
