# 1. 판본을 분리하는 원작 복원 v22

## 실제 범위
v21의 문헌 정본을 폐기하지 않고, 원작 업데이트가 명시한 변경 전/후 값을 별도 테이블로 연결했다. 원본 게임 실행 파일·아카이브를 추출한 결과가 아니다. 새 게임 구현·기존 브라우저 게임 통합은 하지 않았다. JSON ID와 표 구조는 재구축용 식별자이다. 한국어 명칭은 설명용 번역으로 공식 현지화 문자열이 아니다.

## 이번 조사에서 해결한 실질적 문제
v21의 총병 모집비, 기병 식량 종류, 포병 무기/석탄 요구, 장군 보너스는 1.08 변경 문서의 Before와 대응한다. 따라서 `documented`라는 상태만 보고 모든 실행판에 적용하면 잘못된 경제 모델이 된다. 새 자료는 `profile_id`, `recruitment_location`, `scope`를 필수적인 해석 조건으로 사용한다.

| 구분 | 처리 |
|---|---|
| 초기 공략 자료 | `v21_guide_reference`: 본문 범위 안에서만 사용 |
| 1.08 변경 전 | `pre_108_documented`: Before에 실제 적힌 필드만 |
| 1.08 변경 후 | `patch_108_documented`: After와 명시된 규칙만 |
| 오컬트 연구판 | `occult_20101207_documented`: 날짜와 연구판 이름으로 한정 |
| 1.12 협동 모드 | `coop_112_documented`: 새 모드의 팀 공유 규칙 |
| History Edition | 미대조. 기존 수치를 자동 계승하지 않음 |

하나의 프로필도 원작 전체 실행 데이터라고 주장하지 않는다. 문헌에 없는 생산시간·전투 능력치·연구비·소수점 처리·효과 합성은 null로 둔다. 미확인 값은 0, 비용 없음, 즉시 처리로 바꾸지 않는다.

## 출처의 한계
1.08은 WorthPlaying에 재게시된 제작사 변경 기록을 읽었다. 본문에 Version 1.08과 Before/Now가 있지만 Ubisoft 호스팅의 동일 파일을 확보하지 못했다. 따라서 출처 유형을 `publisher_patch_notes_reproduced`로 표시했다. 단순한 팬 추정값과는 구별하지만 실행 검증값으로 승격하지 않는다.

2010-12-07 Steam 공지에는 기술 내용이 있지만 버전 번호 자체는 인쇄되어 있지 않다. 흔히 1.11로 불리는 내용이어도 이 데이터셋은 canonical `patch`를 null로 보존한다. 1.12 날짜는 Steam 게시 날짜이며 모든 플랫폼의 동시 배포 날짜를 보장하지 않는다.

## 기존 파일 보존
`baseline_v21/`에는 v21 ZIP 내부 225개 파일을 그대로 보관했다. `v22/reports/baseline_integrity.json`은 각 파일 SHA-256 대조 결과다. 새 정본은 `v22/data/original_master.json`이며 이전 파일을 덮어쓰지 않는다.

## 적용하지 않은 추정
Cannon Foundry 아래 결과 유닛이 Cavalry로 적힌 항목은 Cannon으로 조용히 수정하지 않았다. 캠페인 211개 시작재고 항목에 일반 Starting Resources 변경을 일괄 적용하지 않았다. Abbey/Bishop’s See, 운반량3/5, M10의6/7 등 기존 충돌도 자동 해소하지 않았다.

- [P108] Publisher v1.08 changelog reproduced by WorthPlaying — https://www.worthplaying.com/article/2010/7/31/news/75915-the-settlers-7-paths-to-a-kingdom-v108-patch-available-now/
- [P112] Steam product update — Version 1.12 — https://store.steampowered.com/oldnews/5383
- [OCCULT] Steam product update — Occult Science — https://store.steampowered.com/oldnews/4743