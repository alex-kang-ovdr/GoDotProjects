from economy_sim_v19 import simulate,load_recipes
assert len(load_recipes())==5
for carriers in (0,1,2,4):
 for travel in (1,5,10):
  a=simulate(carriers=carriers,travel=travel)
  assert a==simulate(carriers=carriers,travel=travel)
  assert a['delivered']>=0 and a['warehouse']['resource.flour']>=0
assert simulate(carriers=0)['delivered']==0
assert simulate(carriers=4)['delivered']>=simulate(carriers=1)['delivered']
assert simulate(initial=0)['delivered']==0
print('PASS: deterministic simulation, conservation, nonnegative stock, zero-carrier, scaling, zero-input')
