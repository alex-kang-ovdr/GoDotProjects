# 12. 경제·보상·상점·수익화

> **확장판 안내:** 초판2026-11-13에2026-11-17 공개 데이터 재구축을 추가했다. 최신 수치·충돌·미확정 값의 사용 범위는 [23번](23_data_reconstruction_overview.md)과 각 상세 데이터 문서를 함께 확인한다.

> 조사 기준: 2026-11-13. 현행 자원 흐름과 보상 설계, 공개 확률 해석, 거래 처리 제안을 다룬다. **[확인]**은 공식 자료, **[분석]**은 설계 해석, **[재현 설계]**는 구현 및 운영 제안이다. 국가별 실결제 가격·개인화 상품·계정별 실험 상태는 확인하지 않았다.

## 1. 경제 구조의 중심

**[분석]** 경제의 핵심은 전투를 통해 받은 여러 자원을 원하는 덱의 준비도와 새로운 선택지로 바꾸는 과정이다. 모든 보상을 같은 가치의 화폐로 취급할 수 없다. 랜덤 카드와 원하는 카드에 사용할 수 있는 와일드 카드는 같은 수량이어도 선택권이 다르며, 골드는 카드 요구량을 대체하지 못한다.

| 자원·진척도 | 주요 기능 | 소비·진행 대상 | 설계상 역할 |
| --- | --- | --- | --- |
| 골드 | 카드 성장의 공통 자원 | 카드 강화·일부 상점 거래 | 여러 카드 투자 사이의 공통 예산 |
| Gems | 다양한 부족분·편의 선택 | 부족 재료·모드 입장·상품 등 | 선택권과 시간 단축 |
| 카드 복제본 | 특정 카드 성장 | 해당 카드 강화 | 관심 카드와 무작위 획득의 연결 |
| Wild Cards | 같은 희귀도의 선택 성장 | 원하는 보유 카드 | 랜덤 보상의 편차 완화 |
| 진화 조각·Wild Shards | 진화 해금 | 특정 또는 선택 진화 | 새 전술 형태에 접근 |
| Hero Coins | 히어로 선택 해금 | 원하는 히어로 형태 | 형태 획득 선택권 |
| Crystals | 최대 레벨 중복의 전환 가치 | 상점 장식 보상 | 최대 성장 후 보상 소진처 |
| Star Points | 카드 장식 성장 | Star Levels | 애착과 외형 성취 |
| Crowns | 시즌 패스 진행 | 패스 단계 | 전투와 시즌 목표 연결 |
| Trophies | 경쟁 진척 | 도달 조건·해금 | 상점 화폐와 다른 경쟁 지표 |
| 이벤트 전용 재화 | 해당 이벤트의 선택 보상 | 기간 한정 마켓 | 시즌별 목표와 소비 결정 |

이 표의 기능은 [카드 성장](09_collection_and_card_progression.md), [특수 형태](08_evolutions_champions_heroes_towers.md), 공식 마법 아이템 및 패스 안내에 근거한다. “상점 화폐”, “진척도”, “해금 재료”는 재현 설계를 위한 분류다. [E23](https://support.clashroyale.com/hc/en-us/articles/49484940179483-Magic-Items), [E21](https://support.clashroyale.com/hc/en-us/articles/49484915388443-Pass-Royale)

## 2. 구형 상자 타이머와 현재 보상을 분리

**[확인]** 2025-03-31 April Update는 상자 대기열·개방 타이머·열쇠 제거를 공지했다. 이후 2025년 10월 업데이트에서 Lucky Drops가 Lucky Chests로 바뀌었다. 따라서 현재 문서에 “상자 4칸이 가득 차면 보상 획득을 멈추고 3시간·8시간을 기다린다”는 예전 경제를 적용하면 안 된다. 현재 Lucky Chest는 예전 대기열 타이머와 분리된 보상 객체로 분석해야 한다. 클랜전처럼 정산 시점이 별도로 있는 보상은 해당 시스템의 지급 조건을 따른다. [E28](https://supercell.com/en/games/clashroyale/blog/release-notes/april-update/), [E02](https://supercell.com/en/games/clashroyale/blog/release-notes/october-update-2025/)

**[분석]** 타이머 중심 구조는 재방문 시점을 요구하지만, 일일 전투 보상 중심 구조는 원하는 시간에 연속 플레이할 여지를 준다. 플레이 세션의 장벽이 사라지는 만큼 보상 인플레이션은 전투 횟수별 보상량과 일일 구간으로 제어해야 한다. 보상 이름이 다시 상자가 되었다는 사실만으로 예전 시간제한 경제가 돌아온 것은 아니다.

## 3. 전투 후 보상과 여러 목표의 동시 진행

**[확인]** 현재 일일 보상 지원은 첫 4승에 Magic Lucky Chest를 주고 첫 3경기에 각각 보너스 크라운 5개를 준다고 설명한다. 승리 횟수와 경기 횟수는 다른 카운터다. 초기 April Update의 첫 3승 기준을 현재 보상량으로 혼합하지 않는다. [E18](https://support.supercell.com/clash-royale/en/articles/daily-battle-rewards-3.html)

**[재현 설계]** 한 경기가 여러 진행도에 반영될 때 각 보상 조건을 분리한다.

`MatchResult`를 확정한 뒤 다음 계산을 각각 수행하는 모델을 제안한다.

- 전투 성적에 따른 크라운.
- 일일 경기 수 기반 보너스.
- 일일 승리 수 기반 보상.
- 모드 진척도와 마일스톤.
- 카드별 마스터리.
- 현재 이벤트의 유효 모드 조건.

이 목록은 구현 의존성을 설명하는 모델이며 실제 서버 처리 순서가 아니다. 패스가 완료되었어도 카드 마스터리는 진행될 수 있고, 일일 보상을 모두 받았어도 경쟁 목표는 남을 수 있다. 모든 보상을 단일 “일일 할당량”으로 묶지 않는 편이 적합하다.

## 4. Lucky Chest의 세 가지 차원

**[확인]** 현재 Lucky Chest 안내는 Standard·Magic·Seasonal을 구분한다. Standard는 3회, Magic과 Seasonal은 4회의 개방 상호작용을 안내한다. 상자 종류는 보상 풀, 별 등급은 결과 희귀도, Chest Level은 보상량의 성장 조건과 연결된다. [E20](https://support.supercell.com/clash-royale/en/articles/lucky-chests-6.html)

| 축 | 의미 | 데이터 필드 예 |
| --- | --- | --- |
| 상자 종류 | 어떤 계열의 보상인가? | `chestType`, `rewardPoolId` |
| 시작 별 등급 | 어떤 상태에서 개방하는가? | `initialStar` |
| 최종 별 등급 | 개방 과정 후 얻은 희귀도 | `finalStar` |
| Chest Level | 보상량의 기준 | `rewardLevel` |
| 아레나·소유 상태 | 어떤 보상에 자격이 있는가? | `eligibilitySnapshot` |
| 시즌·확률표 버전 | 어느 보상 설정을 적용했는가? | `tableVersion`, `seasonId` |

**[분석]** “5성 상자”라고만 기록하면 충분하지 않다. 동일한 별 등급도 상자 종류·레벨·보상 자격에 따라 내용이 달라진다. 분석 로그와 고객 지원 영수증에는 이 조건이 함께 남아야 한다.

### 4.1 확률표를 읽는 방법

**[확인·조회 스냅샷]** 공식 확률 안내에서 1성으로 시작하는 Magic Lucky Chest가 최종 5성이 되는 확률은 1.01%로 제시된다. 13레벨 이상 상자의 **5성에 도달한 뒤** 완전 진화 보상 확률은 9.5%로 안내된다. 이는 서로 다른 조건부 확률이다. 일부 Lucky Chest 지원 문서에는 이전 5% 표가 남아 있어 2026-03-16 변경 공지와 갱신된 확률 허브를 우선했다. [E19](https://supercell.com/en/games/clashroyale/blog/news/clash-royale-chest-info-2/), [E08](https://supercell.com/en/games/clashroyale/blog/news/mid-march-update/), [E20](https://support.supercell.com/clash-royale/en/articles/lucky-chests-6.html)

**[분석·조건부 계산]** 같은 표가 적용되고 추가 자격·전환 예외가 없다고 가정하면 다음처럼 계산한다.

```text
P(완전 진화 보상)
 = P(최종 5성 | 시작 1성) × P(완전 진화 | 최종 5성, 상자 레벨 13+)
 = 0.0101 × 0.095
 = 0.0009595, 약 0.09595%
```

이 값은 모든 상자나 모든 계정에 적용되는 실측 확률이 아니다. 처음부터 5성인 상자, 시즌 확정 보상, 미해금 진화 대상 풀, 중복 전환을 포함하면 계산 조건이 달라진다. “화면에서 탭을 잘하면 확률이 높아진다”는 근거도 없으므로 그런 숙련 요소로 설명하지 않는다.

### 4.2 상자 레벨을 결정하는 시점

**[검증 필요]** 획득 시점과 실제 개방 시점 사이에 아레나가 바뀌었을 때 어떤 시점의 레벨·자격이 적용되는지는 일반 안내만으로 모든 보상에서 확정할 수 없다. 재현 설계에서는 상자에 적용할 기준 스냅샷을 고정하고 UI에 보여 주어야 한다. 아레나 상승 전 보상을 보류하는 행동이 의도치 않은 경제 이득을 만들지 않도록 테스트한다.

## 5. 보상 경제의 수량과 선택권

**[분석]** 랜덤 카드 보상과 와일드 카드 보상은 같은 성장량이 아니다. 플레이어에게 필요한 특정 카드의 비율을 `q`로 두면 단순 기대 유효량은 `randomCount × q`로 표현할 수 있지만, 이미 충분한 카드·최대 레벨 전환·다른 덱 계획까지 고려하면 `q`는 계정마다 달라진다.

**[재현 설계]** 경제 검토에서 다음 세 가지 값을 분리한다.

- **총 지급량:** 전체 카드·골드 등 표면적인 양.
- **현재 목표 유효량:** 사용자가 지정한 덱 강화에 당장 쓰이는 양.
- **선택권 가치:** 필요할 때 원하는 대상으로 돌릴 수 있는 정도.

획득량은 늘었지만 목표 유효량이 감소하면 플레이어는 성장이 느려졌다고 느낄 수 있다. 최대 레벨 중복 보호와 선택형 보상은 이러한 체감 차이를 조절하는 수단이다.

## 6. Pass Royale의 구조

**[확인]** 패스는 아레나 2에서 열리고 크라운으로 진행한다. 무료 보상과 구매한 프리미엄 보상이 병렬로 존재하며, 프리미엄의 일부 구간은 히어로·진화·Wild Evo Shards 중 선택을 제공한다. 시즌이 끝나면 해당 패스 권한은 끝난다. 카드 사용 아레나 조건을 충족하지 못해도 선택 보상은 얻을 수 있으나 사용은 제한된다. [E21](https://support.clashroyale.com/hc/en-us/articles/49484915388443-Pass-Royale)

**[확인·실험]** 지원 문서는 연속 패스 구매 보상이 시험 중이라 계정별로 다를 수 있다고 명시한다. Mini Pass도 별도 소규모 보상 트랙으로 설명되며 일반 패스의 모든 편의 기능을 공유하지 않는다. 따라서 하나의 고정 상품 표를 모든 사용자에게 적용하지 않는다. [E21](https://support.clashroyale.com/hc/en-us/articles/49484915388443-Pass-Royale)

**[분석]** 패스는 시즌 단위 구매 상품이면서 반복 전투에 추가 보상과 선택형 성장 목표를 연결하는 장치다. 플레이어가 이미 수행하는 전투에 추가 보상을 얹어 시즌 목표를 제공하고, 특정 카드 또는 형태를 골라 성장하도록 한다. 프리미엄의 가치에는 자원 총량뿐 아니라 확정성·선택 가능성·외형·도전 재시도 등 서로 다른 요소가 섞여 있다.

**[재현 설계]** 패스 데이터는 `seasonId`, `variantId`, `entitlement`, `crownProgress`, `choiceSelections`, `claimedTiers`, `expiryTime`으로 구성한다. 구매 자격과 보상 수령 자격을 분리하여 시즌 중반 구매 시 이전 달성 구간을 올바르게 처리한다. 한 번 선택한 분기 보상은 재접속이나 기기 변경으로 다른 보상을 추가 수령할 수 없어야 한다.

## 7. 상점과 유료 가치

**[분석]** 상품은 기능적으로 다음 네 범주로 구분할 수 있다.

| 상품 성격 | 사용자가 사는 가치 | 경제 영향 |
| --- | --- | --- |
| 성장 재료 | 원하는 카드 준비까지의 시간 | 카드 레벨 격차와 투자 범위 |
| 형태 해금 | 새로운 전투 선택지 | 덱 구성 접근성과 메타 참여 |
| 외형 | 표현·수집·기념 | 직접 전투 수치와 분리 |
| 진행 편의 | 재시도·단계 도달 시간 등 | 시즌 참여 방식과 피로도 |

이 분류는 실제 매출 비중이나 상품 효율 순위를 뜻하지 않는다. 지역 가격·세금·플랫폼·실험군에 따라 가격이 바뀔 수 있으므로 확인하지 않은 한국 원화 가격이나 할인 배수를 문서에 고정하지 않는다.

**[재현 설계]** 상점은 상품이 주는 실제 자원, 해금 조건, 사용 조건, 선택 보상의 후보, 기간, 중복 시 전환 결과를 구매 전에 보여 주어야 한다. 표시상 “가치” 계산이 어떤 기준 상품에 의존하는지도 경제 데이터에서 추적할 수 있어야 한다.

## 8. 초과 정책과 거래 안정성

**[확인]** 공식 전환 안내는 인벤토리 한도와 절대 상한을 구분한다. 골드는 절대 상한 5,000,000이며 초과분이 사라진다. 반면 한도 직전 획득한 묶음 보상이나 구매 보상에는 자원 종류별 초과 보관 규칙이 있을 수 있다. [E22](https://support.clashroyale.com/hc/en-us/articles/49484891791771-Resource-Magic-Item-Conversion-Details)

**[재현 설계]** 범용 보상 지급은 아래 정책을 지원해야 한다.

```text
GrantReward(reward, playerSnapshot, source):
  자격과 지급 중복 여부 검사
  항목별 보유·상한·초과 정책 적용
  원 보상과 실제 지급·전환 내역 계산
  계정 자산과 수령 이력을 한 번에 확정
  사용자에게 지급 영수증 반환
```

| 정책 | 의미 | 예외 처리에서 필요한 입력 |
| --- | --- | --- |
| 절대 상한 | 초과분 저장 불가 | 경고·손실 정책 |
| 묶음 초과 허용 | 한도 미만에서 수령한 묶음 보관 | 수령 직전 잔액 |
| 대체 자원 전환 | 원래 보상 대신 다른 자원 지급 | 레벨·희귀도·아레나 |
| 유료 획득 예외 | 일반 획득과 다른 보관 규칙 | 결제 출처와 영수증 |
| 고유 장식 | 중복 소유 자체가 불가 | 이미 보유한 장식 목록 |
| 이벤트 만료 | 해당 시즌 종료 후 소멸·전환 | 시즌·만료 정책 버전 |

**[분석]** 보상 개방 애니메이션과 자산 지급은 분리할 필요가 있다. 앱을 닫아도 승인된 보상은 사라지지 않고, 애니메이션을 다시 보더라도 추가 지급되지 않아야 한다. 이것은 특정 상자 내부 추첨 방식의 공개 사실이 아니라 재현 시스템의 기본 요건이다.

## 9. 성장 속도 모델과 경제 검증

**[재현 설계]** 골드와 특정 카드가 동시에 필요한 강화의 최소 소요시간을 단순화하면 다음과 같다.

```text
GoldDays = RemainingGold / ExpectedDailyGold
CardDays = RemainingEffectiveCopies / ExpectedDailyUsefulCopies
ApproximateBottleneckDays = max(GoldDays, CardDays)
```

이는 수입이 일정하고 자원을 병렬로 얻으며 다른 소비가 없다는 가정이다. 실제 예측은 랜덤 보상·마일스톤 일괄 지급·와일드 배분·이벤트를 포함한 시뮬레이션으로 중간값과 상위 지연 구간을 구해야 한다.

**가상 예시:** 필요 골드 60,000, 예상 일일 골드 6,000이면 골드 병목은 10일이다. 필요한 유효 카드가 300장이고 일일 15장이라면 카드 병목은 20일이다. 골드 지급만 두 배로 늘려도 이 카드의 예상 완성 시간은 단순 모델상 20일로 유지된다. 전체 지급량만으로 성장 개선을 판단하면 이 병목을 놓친다.

**[분석]** 경제 모니터링에서는 다음을 따로 본다: 주력 덱 완성까지 시간, 사용하지 않는 재료 누적, 상한 때문에 사라진 보상 비율, 선택 보상 선호, 최대 레벨 중복 비율, 새 카드 사용까지 걸린 시간, 모드별 레벨 격차. 실제 Clash Royale의 내부 KPI나 목표 수치가 공개된 것은 아니다.

## 10. 검증 시나리오

| ID | 상황 | 확인 결과 |
| --- | --- | --- |
| EC-01 | 첫 3경기를 모두 패배 | 경기 보너스와 승리 보상이 혼합되지 않음 |
| EC-02 | 보상 개방 중 앱 종료 | 자산 보존, 재개 시 중복 지급 없음 |
| EC-03 | 확률표가 패치된 뒤 보류 상자 개방 | 정의된 기준 시점·버전 적용 |
| EC-04 | 5성 확정 상자 확률 표시 | 1성 출발 확률을 다시 곱하지 않음 |
| EC-05 | 한도 직전 묶음 보상 | 자원별 overflow 정책 적용 |
| EC-06 | 최대 레벨 카드 복제본 | 카드별 전환량 정확 |
| EC-07 | 패스 선택형 보상 두 번 요청 | 최초 선택만 확정 |
| EC-08 | 시즌 중반 패스 구매 | 이미 달성한 구간의 구매 보상 자격 반영 |
| EC-09 | 실험 비대상 계정 | 연속 구매 혜택을 확정 제공처럼 표시하지 않음 |
| EC-10 | 이벤트 재화가 다음 시즌과 같은 이름 | 시즌 ID를 분리하여 잘못 이월하지 않음 |
| EC-11 | 결제 완료 후 응답 유실 | 영수증 기준으로 한 번만 권한 지급 |

## 11. 출처

- **E02** [October Update 2025](https://supercell.com/en/games/clashroyale/blog/release-notes/october-update-2025/), 2025-09-25.
- **E08** [Mid-March Update](https://supercell.com/en/games/clashroyale/blog/news/mid-march-update/), 2026-03-16. 5성 보상 구성 변경.
- **E18** [Daily Battle Rewards](https://support.supercell.com/clash-royale/en/articles/daily-battle-rewards-3.html), 공식 지원, 2026-11-13 검색 본문 확인.
- **E19** [All About Drop Rates!](https://supercell.com/en/games/clashroyale/blog/news/clash-royale-chest-info-2/), 공식 확률 허브, 표시 발행일 2026-03-02, 본문은 후속 개편 반영, 2026-11-13 조회.
- **E20** [Lucky Chests & Boxes](https://support.supercell.com/clash-royale/en/articles/lucky-chests-6.html), 공식 지원, 2026-11-13 검색 본문 확인. 일부 5성 구성표는 E08/E19와 충돌.
- **E21** [Pass Royale](https://support.clashroyale.com/hc/en-us/articles/49484915388443-Pass-Royale), 공식 지원, 2026-11-13 조회.
- **E22** [Resource & Magic Item Conversion Details](https://support.clashroyale.com/hc/en-us/articles/49484891791771-Resource-Magic-Item-Conversion-Details), 공식 지원, 2026-11-13 조회.
- **E23** [Magic Items](https://support.clashroyale.com/hc/en-us/articles/49484940179483-Magic-Items), 공식 지원, 2026-11-13 조회.
- **E28** [April Update!](https://supercell.com/en/games/clashroyale/blog/release-notes/april-update/), 2025-03-31. 타이머·대기열 제거의 1차 자료.
- 관련: [카드 성장](09_collection_and_card_progression.md), [계정 성장](10_player_progression_trophy_and_ranked.md), [시즌·이벤트](13_seasons_events_and_retention.md).

## 12. 2026-11-17 보강: 확률·수량·전환 데이터

공식 확률 허브와 지원 표를 다시 읽어 [economy_rules.json](data/tables/economy_rules.json), [reward_probability_tables.json](data/tables/reward_probability_tables.json)을 만들었다. Magic/Standard 상자의 **가족×최종 등급×상자 레벨**별 지급 수량 144행과, 출발 등급별 최종 등급 확률 및 보상 종류 확률을 분리했다. `amounts`의 여러 숫자는 동시에 주는 보상 묶음이 아니라 선택된 종류별 수량이다. [공식 확률 허브](https://supercell.com/en/games/clashroyale/blog/news/clash-royale-chest-info-2/)

종류 확률의 Chest Level 13+ 조건을 낮은 레벨에 그대로 적용하지 않는다. 표시 확률의 합이 99.99% 또는 100.01%인 경우 원문 값을 유지하고 `probability_sum_tolerance`로 검증한다. 합을 맞추기 위한 정규화는 원본 표가 아닌 별도의 파생 설정에서만 수행한다.

현재 지원의 재화 한도·자동/수동 전환도 포함했다. 진화 조각 전환표에서 누락된 아레나 19~21 구간, 미확보 와일드 수량 한도, 개인별 패스 가격은 `null`과 미확정 사유로 남겼다. 자료에 없는 값을 이웃 구간 보간이나 0으로 대체하지 않았다. [변환 안내](https://support.clashroyale.com/hc/en-us/articles/49484891791771-Resource-Magic-Item-Conversion-Details)

Crown Series의 정규 Duel Weekend 보상은 9개 리그 그룹×0~8승의 81행으로 복구했다. 해당 승수의 **최종 보상 한 행**을 적용하며 이전 승수 보상들을 합산하지 않는다. Grand Duel에는 이 표를 재사용하지 않는다. [Crown Series 보상](https://support.clashroyale.com/hc/en-us/articles/58566501950107-Crown-Series)

[26번 문서](26_progression_economy_reconstruction.md)는 조건부 확률 결합, 최대 카드 중복 보정의 정확히 60개 경계 누락, 구 Hero Fragments와 현행 Hero Coins 구분, 성장 병목과 거래 영수증 계약을 설명한다.
