# 데이터 품질·커버리지 정적 분석 보고서

분석 기준일: 2026-11-17 · 패키지: 4.0.0 · 생성기: `scripts/analyze_quality.py` · 스키마: 1.1.0

이 보고서는 포함된 공개 자료의 연결성과 미확인 범위를 집계한다. 원작 실측 또는 전체 게임 재현 완료 보고서가 아니다.

## 범위

| 구분 | 개수 | 의미 |
|---|---:|---|
| 원표 / 원표 레코드 | 22 / 7,668 | 조회본·정규화·자체 비교 포함 |
| 출처 레코드 / 서로 다른 URL | 107 / 78 | 서로 다른 독립 주장 수가 아님 |
| 카드 키 합집합 | 133 | 역사 카탈로그·부분 패치·자체 카드의 합집합 |
| 2023 카탈로그 / 정의 / 연결 | 120 / 532 / 465 | 과거 공개 스냅샷 |
| 아카이브 기본 / 추가 명시 연결 | 428 / 37 | 합친 그래프로 도달 범위를 계산 |
| 아카이브 추가 행동 행 / 필드 종류 | 113 / 31 | 기존 개체에 연결한 같은 스냅샷의 추가 원시 필드 |
| 아카이브 레벨별 수치 행 | 4,956 | 추가 필드 때문에 과거 성장표를 변경하지 않음 |
| 2026 패치 원장 / 최종 필드 | 201 / 191 | 포함한 패치 원장 내부에서만 최신 |
| 2026 기본 / 확장 패치 원장 | 61 / 140 | 원장 파일은 분리 보존하고 분석 시 합산 |
| 부분 패치에 등장한 카드 키 | 91 | 현행 전체 카드 수가 아님 |
| 완전한 현재 카드 프로필 | 0 | 부분 필드를 완전 프로필로 승격하지 않음 |

## 확인된 공백

정확한 공개 key로 루트가 연결되지 않은 역사 카드 10개:

`arrows`, `barbarian-barrel`, `elixir-collector`, `fireball`, `giant-snowball`, `goblin-barrel`, `mirror`, `party-rocket`, `rocket`, `the-log`.

이름 없는 정의 6개는 격리 상태다. 여러 exact-key 루트가 있는 18개 카드는 참조 연결의 모호성과 구별한다. 명시적 개체 연결 중 unresolved 표시는 0개이며, 이것이 카드 전체 정의 완성을 뜻하지는 않는다.

그래프 조회는 방문 집합으로 순환을 차단하고 깊이 제한 없이 모든 명시적 resolved 연결을 따라간다. missing/ambiguous 연결은 후보 이름으로 보충하지 않는다.

추가 행동 필드 값은 684개다. 카드별 도달 그래프에 추가 행동 행이 나타나는 키는 40개, 추가 참조 덕분에 도달 개체가 늘어난 키는 15개다. 이 수치는 서로 다른 집계이며 새 카드 수가 아니다. 카드 커버리지 JSON에 추가 참조 ID, 기본 그래프 대비 추가 도달 개체, 행동 원시 필드와 출처를 함께 기록한다.

## 패치 레벨과 적용일의 불확실성

| 기준 레벨 상태 | 원장 행 | 최종 필드 |
|---|---:|---:|
| specified | 73 | 69 |
| not_applicable | 88 | 82 |
| not_stated | 40 | 40 |

레벨 명시·비적용·미기재를 구분한다. 레벨 미기재 후속 변경은 이전 레벨값을 현재값으로 확정하지 못하게 하는 별도 불확실성이다. 포함된 원장 내부의 부분 필드이며 전체 현재 프로필이 아니다.

기준 레벨이 미기재인 최종 필드는 40개, 그 이후 레벨 미기재 변경이 있어 현재값으로 확정할 수 없는 이전 필드는 1개다. 두 목록은 구분해서 보존하며 단순히 더하여 결측 카드 수로 사용하지 않는다.

| 패치 적용일 | 통합 원장 행 | 해당 날짜의 최종 필드 |
|---|---:|---:|
| 2026-05-04 | 18 | 17 |
| 2026-06-01 | 31 | 28 |
| 2026-07-06 | 17 | 16 |
| 2026-08-04 | 65 | 62 |
| 2026-08-26 | 9 | 8 |
| 2026-09-08 | 25 | 25 |
| 2026-09-16 | 4 | 3 |
| 2026-10-06 | 20 | 20 |
| 2026-10-19 | 12 | 12 |

## 추가 조사의 분류

| 원표 | 분류별 행 수 |
|---|---|
| card_behavior_research_v4 | new_fact: 24, rechecked_claim: 3, unresolved_gap: 5 |
| economy_research_v4 | new_fact: 38, rechecked_claim: 4, unresolved_gap: 5 |
| mode_research_v4 | conflict: 5, new_fact: 31, unresolved_gap: 4 |

재확인·미해결·충돌 행을 새 사실 수에 합치지 않는다. new_fact의 파생 검산도 공식 원문 사실과 evidence_status로 구분한다.

## null과 날짜 해석

최상위 value가 null인 행은 26개, value 내부에 null이 포함된 행은 692개, unit이 null인 행은 46개다. 별도 근거 분류 unverified는 51개다. 서로 다른 집계이며 합산해 결측 수치를 만들지 않는다.

null 출현 개수는 미복원 수치의 개수가 아니다. 단위 비적용·정책상 무상한·해금 Gold 비적용·원시 참조 부재를 필드별로 해석해야 한다. 0과 false는 null로 계산하지 않는다.

effective_from 미기재: 7,091행. effective_to 미기재: 7,661행. effective_from null은 적용 시작 미확정이다. effective_to null은 종료일 미기재이며 영구 유효 또는 현재 유효 판정이 아니다. 조회일과 자료 스냅샷 날짜는 적용일과 별도다.

## 실측·출처 검증 범위

원작 상호작용 명세 44개 가운데 observed=true는 0개다. 현재 실험 상태 집계는 {"not_run": 44}다. 참조 JS 자동 검사는 원작 실험 결과로 합산하지 않는다.

이번 생성기는 네트워크를 사용하지 않는다. source_audit의 link_check_status=not_checked는 링크 접근을 아직 검사하지 않았다는 뜻이며 정상·오류·최신 판정이 아니다. 출처의 내용이 원표 주장과 일치하는지 재독해하는 작업도 별도다.

## 출처 충돌

| 충돌 그룹 | 관련 원표 ID |
|---|---|
| clan_hit_speed | `MERGE_CLAN_PATCH`, `MERGE_CLAN_SUPPORT`, `V4_MODE_MERGE_CLAN_CONFLICT` |
| max_level_donation_gold | `SOCIAL_MAX_DONATE_ANNOUNCE`, `SOCIAL_MAX_DONATE_SUPPORT`, `V4_MODE_DONATION_GOLD_CONFLICT` |
| ranked_trophy_requirement | `V4_MODE_RANKED_GATE_CONFLICT` |
| rider_speed | `MERGE_RIDER_PATCH`, `MERGE_RIDER_SUPPORT`, `V4_MODE_MERGE_RIDER_CONFLICT` |
| round_income | `MERGE_INCOME_CURRENT`, `MERGE_INCOME_SUPPORT`, `V4_MODE_MERGE_INCOME_CONFLICT` |

## 후속 작업과 완료 기준

| 우선순위 | 과제 | 상태 |
|---|---|---|
| P0 | G01_PROFILE_ISOLATION · 아카이브·공식 부분 패치·자체 카드의 분리 유지 | guarded_by_data_checks |
| P0 | G02_ARCHIVE_ROOTS · 공개 카드 루트 연결 누락 보완 | requires_evidence |
| P0 | G03_CURRENT_PROFILES · 동일 빌드 대표 카드의 완전한 프로필 확보 | requires_original_client |
| P0 | G04_COORDINATES · 배치·거리·충돌 좌표를 관측으로 교정 | requires_original_client |
| P0 | G05_SHIELD_DAMAGE · 보호막 초과 피해와 다중 파동의 처리 순서 확정 | requires_original_client |
| P0 | G06_EVENT_BOUNDARIES · 타워 파괴·사망·투사체 동시 사건의 경계 규칙 확정 | requires_original_client |
| P0 | G07_ELIXIR_PROFILE · 엘릭서 초기값·용량·기본 생성 간격의 근거 확보 | requires_original_client |
| P0 | G08_OBSERVATION_LEDGER · 실측 결과를 명세와 분리한 관측 원장 도입 | ready_for_implementation |
| P0 | G09_RUNTIME_IMPORT · 재현 엔진 데이터 가져오기 전 필수 필드 게이트 | ready_for_implementation |
| P1 | G10_ABILITY_OWNER · 능력 소유권·일회 사용·Boss Bandit 예외 검증 | requires_original_client |
| P1 | G11_MIRROR_CAP · Mirror 진화·레벨 증가·모드 상한의 적용 순서 검증 | requires_original_client |
| P1 | G12_ECONOMY_GAPS · 경제표의 미기재 경계를 보완 | requires_evidence |
| P1 | G13_PROBABILITY_CHAIN · 보상 조건부 확률의 조합 조건 고정 | ready_for_implementation |
| P1 | G14_SOURCE_CONFLICTS · 시즌 자료와 일반 지원 문서의 상충 조건 확인 | requires_original_client |
| P2 | G15_MODE_SETTLEMENT · 모드·클랜의 입장 스냅샷과 정산 불변식 구현 | ready_for_implementation |
| P1 | G16_CLIENT_QA · 오프라인 분석 화면의 실제 브라우저·접근성 점검 | requires_runtime_validation |

상세 선행조건·완료 기준·원표 근거는 [reconstruction_backlog.json](../data/analysis/reconstruction_backlog.json)에 있다. 현재 데이터가 지키는 분리 규칙도 후속 가져오기 경로에서 계속 검사해야 한다.

## 재생성

```bash
python scripts/analyze_quality.py
python scripts/analyze_quality.py --check
python -m unittest discover -s tests -p 'test_quality.py'
```

`--check`는 현재 원표로 재계산한 출력과 파일의 바이트가 같은지 검사한다. 파일에 기록된 적용일·실측 여부의 사실성 자체를 증명하지 않는다.

관련 파일: [요약 JSON](../data/analysis/quality_summary.json), [카드 커버리지](../data/analysis/card_coverage.json), [출처 감사](../data/analysis/source_audit.json), [완료 게이트 문서](../37_coverage_and_implementation_gates.md).
