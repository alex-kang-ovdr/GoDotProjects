# 조사·분석·데이터 복원 재구축 보고서 v4.0.0

기준일: 2026-11-17. 이 문서는 `scripts/reconcile_research.py`가 저장된 JSON에서 생성한다.

## 1. 조사 범위와 결과

공식 공지의 숫자 변경, 경제·모드·카드 동작에 관한 조사 행, 고정 역사 자료와 출처 연결을 함께 감사했다. 완전한 현행 클라이언트 데이터나 실제 전투 검증을 뜻하지 않는다. 행 수를 원작 복원율로 환산하지 않는다.

| 항목 | 수량 |
|---|---:|
| JSON 데이터 테이블 | 22 |
| 전체 데이터 행 | 7668 |
| 등록 출처 / 정확히 같은 문자열을 합친 URL | 107 / 78 |
| 공식 숫자 패치 이력 | 201 |
| before·after 모두 명시 / after만 명시 | 199 / 2 |
| 레벨 상태까지 구분한 최신 부분 필드 | 191 |
| 조사 분류가 있는 행 | 119 |

최신 부분 필드는 공급된 이력 안에서의 마지막 주장이다. 카드의 모든 능력치가 복원되었다는 의미가 없으며, 기준일의 실게임 값을 모두 보증하지도 않는다.

## 2. 새 사실·재확인·공백·충돌

| 조사표 | 존재 | 새 사실 | 재확인 | 미해결 공백 | 충돌 |
|---|---|---:|---:|---:|---:|
| `card_behavior_research_v4` | 있음 | 24 | 3 | 5 | 0 |
| `economy_research_v4` | 있음 | 38 | 4 | 5 | 0 |
| `mode_research_v4` | 있음 | 31 | 0 | 4 | 5 |
| 합계 | — | 93 | 7 | 14 | 5 |

`new_fact`는 이번 조사에서 추가한 주장 행이고, 완전히 새로운 게임 기능이라는 뜻은 아니다. `rechecked_claim`은 기존 주장을 재조사한 결과다. `unresolved_gap`과 `conflict`는 발견한 한계를 보존한 행으로 성공적인 수치 복구에 합산하지 않는다. 아직 없는 조사표는 0행으로 표시하며, 그 표가 생기면 다음 재생성에서 자동 집계한다.

## 3. 패치 연속성과 레벨 경계

| 레벨 상태 | 패치 이력 | 최신 부분 필드 | 의미 |
|---|---:|---:|---|
| `specified` | 73 | 69 | 문서에 특정 레벨이 명시됨 |
| `not_applicable` | 88 | 82 | 시간·거리 등 레벨에 적용되지 않는 필드 |
| `not_stated` | 40 | 40 | 수치는 있지만 문서가 기준 레벨을 밝히지 않음 |

미기재 레벨은 null로 보존한다. 레벨 11의 숫자와 우연히 같거나 앞뒤 패치와 연결되더라도 자동 승격하지 않는다. 기본형·진화형·히어로형과 소환물·능력의 component도 독립적으로 비교한다.

여러 날짜의 변경이 있는 필드는 14개, 인접 연결은 15개다. 숫자 불일치는 1개이며, 이 중 같은 명시 레벨 또는 레벨 비적용 범위에서의 불일치는 0개다.

### 숫자가 이어지지 않는 연결

- **void / base / two_to_four_targets / damage_per_hit / damage**: 2026-08-04의 after `294` → 2026-10-19의 before `296`. 분류 `unspecified_level_candidate`. 레벨·중간 패치·정밀도·원문 오류 가운데 무엇이 원인인지는 결정하지 않았다. 두 원값을 유지한다.
  근거 레코드: `PATCH_EXP_20260804_void_base_two_to_four_targets_damage_per_hit`, `PATCH_20261019_037`.

### 명시 레벨 값 뒤의 미기재 레벨 변경

- **tombstone / hero / tomb_queen / hitpoints**: 레벨 `11` 값 `4044`는 2026-07-06의 주장으로 남는다. 이후 `PATCH_EXP_20260804_tombstone_hero_tomb_queen_hitpoints`가 있으므로 현재 같은 레벨의 값이라고 단정하지 않는다.

### 단위와 중복

동일 의미 필드의 단위 차이 0건, 동일 날짜·범위 중복 이벤트 0건을 발견했다. 원문 단위를 보존한 행은 아래와 같다. 출처가 환산 관계를 제공하지 않으므로 타일·초 등의 단위로 변환하지 않는다.

| 레코드 | 단위 | before → after |
|---|---|---:|
| `PATCH_20261019_030` | `source_mass_unit` | 3 → 6 |
| `PATCH_EXP_20260804_battle_healer_base_healing_radius` | `source_radius_unit` | 4000 → 3000 |
| `PATCH_EXP_20260804_goblin_machine_base_rocket_travel_speed` | `source_speed_unit` | 250 → 350 |
| `PATCH_EXP_20260804_x_bow_base_projectile_speed` | `source_speed_unit` | 1400 → 1600 |

## 4. 출처·참조 무결성

출처 참조 12952개와 관련 레코드 참조 146개를 저장된 ID 집합에 대조했다. `related_record_ids`가 있는 119행 중 66행의 빈 배열은 허용한다. 직접 연결할 기존 행이 없는 독립 주장도 유효하기 때문이다.

출처·레코드 참조 검사 결과: **통과**. URL 수는 문자열 기준이며, 동일 URL의 여러 source ID는 문맥별 별칭으로 보존한다. 이 오프라인 스크립트는 URL의 온라인 접근 가능 여부를 확인하지 않는다.

패치 확장 원문:

- [May Balance Changes](https://supercell.com/en/games/clashroyale/blog/release-notes/may-balance-changes-2026/) — `V4_PATCH_2026_05`; 문서 날짜 2026-05-04; [출처 등록부](../data/sources/patch_expansion_sources.json).
- [June Balance Changes](https://supercell.com/en/games/clashroyale/blog/release-notes/june-balance-changes-2026/) — `V4_PATCH_2026_06`; 문서 날짜 2026-06-01; [출처 등록부](../data/sources/patch_expansion_sources.json).
- [July Balance Changes](https://supercell.com/en/games/clashroyale/blog/release-notes/july-balance-changes-2026/) — `V4_PATCH_2026_07`; 문서 날짜 2026-07-06; [출처 등록부](../data/sources/patch_expansion_sources.json).
- [August Balance Changes](https://supercell.com/en/games/clashroyale/blog/news/final-august-balance-changes-826/) — `V4_PATCH_2026_08`; 문서 날짜 2026-08-04; [출처 등록부](../data/sources/patch_expansion_sources.json).

## 5. 원작 관측과 검증의 경계

원작 상호작용 사례 44개 중 `observed=true`는 0개다. 상태 집계는 `{"not_run": 44}`다. 문서 조사, JSON 참조 검사와 오프라인 회귀 검사는 실제 원작 클라이언트에서의 실행 검증으로 바꾸지 않는다.

전체 정합성 검사: **통과**; 오류 0건, 근거 한계 경고 2건. 알려진 레벨 경계와 원문 숫자 차이는 수정 없이 경고로 유지한다.

## 6. 재생성

```bash
python scripts/rebuild.py
python scripts/reconcile_research.py
python scripts/reconcile_research.py --check
python -m unittest discover -s tests -p test_reconciliation.py
```

`--check`는 출력 파일을 고치지 않는다. JSON 입력에서 다시 계산한 결과가 저장된 산출물과 다르거나, 출처 참조·레벨 계약·최신 부분뷰에 오류가 있으면 실패한다. 실행 시간이나 네트워크 응답을 입력으로 사용하지 않아 같은 JSON 입력에서는 같은 바이트가 생성된다.

입력 지문 SHA-256: `ee4209b9e4da2f5ea01668edb0caf213a96df8aed8dc962358a0e8aa4a71d81a`.

상세 결과: [패치 연속성 감사](../data/analysis/patch_lineage_audit.json), [조사 요약](../data/analysis/research_v4_summary.json), [해석·재현 설명](../44_sources_and_level_reconciliation.md).
