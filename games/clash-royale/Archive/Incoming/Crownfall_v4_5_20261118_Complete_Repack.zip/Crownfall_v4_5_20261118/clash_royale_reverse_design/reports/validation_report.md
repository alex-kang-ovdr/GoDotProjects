# 재구축 데이터 검증 결과

- 기준: 2026-11-17 / 패키지 4.0.0
- 결과: **PASSED**
- 표: 22종 / 레코드: 7,668개
- 출처 레코드: 107개 / 고유 URL: 78개
- 원작 전투 실험: 44개 명세, **실행 0개**

이 결과는 데이터 정합성 검사다. 비공개 클라이언트 수치·실제 게임 동작의 일치 검증이 아니다.

## 데이터별 행 수

| 표 | 행 |
|---|---:|
| archive_behavior_extensions_2023 | 113 |
| archive_reference_extensions_2023 | 37 |
| balance_patch_ledger_2026 | 61 |
| card_behavior_research_v4 | 32 |
| card_bindings_2023 | 120 |
| card_catalog_2023 | 120 |
| combat_rules | 63 |
| economy_research_v4 | 47 |
| economy_rules | 324 |
| entity_definitions_2023 | 532 |
| entity_links_2023 | 428 |
| implementation_card_mapping | 19 |
| interaction_cases | 44 |
| level_stats_2023 | 4,956 |
| merge_tactics_rules | 106 |
| mode_research_v4 | 40 |
| mode_rules | 45 |
| official_patch_expansion_2026 | 140 |
| progression_rules | 103 |
| reward_probability_tables | 98 |
| social_clan_rules | 49 |
| verified_patch_fields_2026 | 191 |

## 검사

- all_table_records_schema_ids_sources_dates_and_csv
- pinned_factual_snapshot_hashes
- archive_card_entity_graph_and_provider_level_arrays
- 2026_patch_lineage_chronology_and_no_historical_fallback
- research_new_rechecked_unknown_conflict_and_record_links
- conditional_probability_groups_without_renormalization
- custom_cards_and_unexecuted_observation_boundary
- markdown_relative_file_links

## 보존한 결측

- 2023 카드↔정의 연결 없음: elixir-collector, fireball, arrows, rocket, goblin-barrel, mirror, the-log, barbarian-barrel, giant-snowball, party-rocket
- 이름 없는 공개 원시 행 6개는 격리 플래그로 보존.
- 공식 확률의 반올림은 원값과 그룹별 허용 오차로 보존; 임의 정규화하지 않음.
- 현행 전체 카드값과 숨은 전투·매칭 로직은 이 검사로 확정할 수 없음.
