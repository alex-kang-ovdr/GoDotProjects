# Dark Descent Offline Edition 28.1 — 새 다운로드 패키지

기존 28.1 릴리스를 새 ZIP 파일로 재취합했습니다. 게임 구현, 게임 데이터, 에셋과 기존 문서·검사 결과를 변경하지 않았으며 새 모델링을 생성하지 않았습니다.

## 실행

1. ZIP의 압축을 모두 풉니다.
2. 최상위 `dark_descent_offline.html`을 Chrome 또는 Edge로 엽니다.
3. 시작 화면에서 이어하기 또는 직업 선택 → 새 탐험 시작을 선택합니다.

소스 폴더의 `dark_descent_offline/index.html`도 같은 실행본입니다. Windows에서는 그 폴더의 `START_GAME.cmd`를 사용할 수 있습니다. 다운로드 후 플레이에 서버·npm·인터넷 연결이 필요하지 않도록 만든 기존 실행본입니다.

## 포함 내용

- `dark_descent_offline.html`: 기존 단일 HTML의 바이트 그대로 복사한 실행본.
- `dark_descent_offline/`: 기존 ZIP의 71개 파일을 경로와 내용 그대로 보존.
- `dark_descent_offline/src/`: JavaScript·CSS·HTML 원본 소스.
- `dark_descent_offline/data/`: 게임 데이터와 공개 참조 출처 기록.
- `dark_descent_offline/docs/`: 시스템별 Markdown 문서 8개.
- `dark_descent_offline/tests/`, `QA_REPORT.md`: 기존 검사 코드·샘플·결과 보고서. QA_REPORT.md는 dark_descent_offline 폴더 안에 있습니다.
- `REPACKAGE_VERIFICATION.json`: 원본 71개 파일의 크기·SHA-256 및 재취합 기록.

## 재취합 검증

기존 ZIP의 CRC와 70개 manifest 항목 해시를 확인했습니다. 단일 HTML과 기존 index.html은 바이트가 같습니다. 새 ZIP을 생성한 뒤 전 항목 CRC와 원본 71개 파일의 내용 일치 여부를 다시 확인하여 제공합니다. 게임 테스트 결과는 기존 28.1 결과를 보존한 것이며 이번에 재실행한 결과가 아닙니다.

기존 진행을 옮기려면 이전 실행본에서 JSON 백업을 내보낸 뒤 이 실행본에서 가져오세요.
