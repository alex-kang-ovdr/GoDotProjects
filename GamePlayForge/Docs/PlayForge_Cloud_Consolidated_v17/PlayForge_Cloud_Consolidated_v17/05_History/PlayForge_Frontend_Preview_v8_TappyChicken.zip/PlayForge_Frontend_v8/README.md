# PlayForge Frontend v8 — Tappy Chicken Project Workspace

Open `index.html` in a browser and select **Tappy Chicken**.

## New in v8
- Editable Scene JSON Actor hierarchy and inspector (class, position, components).
- Gameplay defaults in the Scene draft; Apply to PIE / Restart PIE commands to JavaScript preview.
- Editable Lua source draft with heuristic checks, save and export. **Lua is not executed.**
- Scene JSON import/export with basic schema checks.
- Undo/Redo for Scene/Lua draft edits; browser localStorage persistence.
- Existing v7 tuning, analytics, Library and Discover remain.

## Boundaries
Scene actor transforms do not control the JS preview; only gameplay defaults are wired to it. This is a browser-only prototype, not C++/Lua engine, cloud collaboration or EOS integration. Heuristic Lua checks are not a Lua compiler.
