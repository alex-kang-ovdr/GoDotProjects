# PlayForge Frontend v4 — Tappy Chicken sample

Open `index.html` in a browser. Select **🐔 Tappy Chicken** in the top navigation. The game can also be opened independently at `TappyChicken/index.html`.

## Example project
- `TappyChicken/project.json`: project manifest
- `TappyChicken/Scenes/Main.scene.json`: proposed scene object manifest
- `TappyChicken/Scripts/Game.lua`: gameplay logic written for a proposed PlayForge Lua 5.4 engine API
- `TappyChicken/index.html`: playable, standalone JavaScript port of the same core rules; no Lua interpreter is embedded

Controls: Space, Up Arrow or tap/click to flap. Restart button; sound toggle. Best score is stored in localStorage where available.

## Mock limitations
Existing v3 editor/library/discover/analytics/safety UI remains a front-end prototype. Tappy game play is real in the standalone JS preview; it does not yet execute the Lua source or C++20 engine. Telemetry uses window.postMessage to the parent editor and localStorage for the demo event log; no online backend or EOS service is connected. All artwork is original canvas vector drawing; synthesized sound uses Web Audio API.
