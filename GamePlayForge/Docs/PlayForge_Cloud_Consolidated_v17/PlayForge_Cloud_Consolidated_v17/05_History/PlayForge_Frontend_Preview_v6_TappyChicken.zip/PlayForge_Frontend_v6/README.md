# PlayForge Frontend v6 — Tappy Chicken Live Tuning

Open `index.html` and choose **Tappy Chicken**. The right panel includes a live gameplay inspector for gravity, flap, obstacle speed/gap/interval/width, and deterministic random seed. **Apply + Restart** sends settings to the embedded JavaScript game via postMessage. Settings persist in localStorage. Diagnostics show live bird velocity, Y, obstacles and time.

The standalone game is `TappyChicken/index.html`. Lua source remains in `TappyChicken/Scripts/Game.lua` as a reference implementation; the browser game is JavaScript, not a Lua VM. Backend, EOS, real GitHub and native cooking are not implemented. Other marketplace/editor mock sections remain from v5.
