# PlayForge Frontend v10 — Unity-inspired 2D/3D Scene Editor

Open `index.html` in a browser. No dependencies or server needed.

## New
- 3D perspective scene viewport with projected solid geometry, grid, orbit and zoom (Canvas 2D software projection; **not WebGL 3D rendering**)
- 2D orthographic viewport using same actor data
- Click actor selection, drag to move, right-drag orbit/pan, wheel zoom
- W/E/R tools: Move/Rotate/Scale mock transforms; project data persisted locally
- Unity-style Hierarchy / Scene / Inspector / Project Assets / Console / Game tabs
- Game-specific logic remains in TappyChicken example, not platform controls

## Limitations
- Scene viewport is an interactive projection mock; no actual 3D engine, physics or Lua VM
- Rotation/scale scene visualization is illustrative; Inspector position is editable
- Game preview uses JavaScript, not Lua runtime
- EOS, multiplayer, GitHub, cloud services are not connected
