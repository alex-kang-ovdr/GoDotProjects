# PlayForge Studio v9 — Game-agnostic editor mock

Open `index.html` directly in a browser. No build tools or server required.

## Platform editor features
- Project selector with Tappy Chicken and Empty Sandbox
- Generic Scene / Hierarchy / Inspector / Actor/Component / arbitrary Property editing
- Lua source editing, JSON project settings, local Undo/Redo and LocalStorage
- Generic Shared Library reference UI, mock AI ChangeSet, validation and project JSON export
- PIE browser preview for projects that provide one

## Project-owned content
- `TappyChicken/` is an example project, not a hardcoded editor subsystem.
- `TappyChicken/Gameplay.settings.json` owns game-specific parameters, removed from the Scene's editor-only defaults.
- The game preview uses JavaScript, and Lua is reference source only. No Lua VM, C++ engine, real reflection, EOS, GitHub, cloud backend, or live collaboration is connected.
- The generic Inspector is schema-shaped from the project data, not actual C++ reflection.

## Notes
- Scene editor is a 2D schematic, not a 3D viewport.
- LocalStorage persistence and JSON export work within the browser's security constraints.
- Game-specific settings are not automatically forwarded to the standalone JS game preview; this would require a generic runtime bridge.
