# PlayForge Frontend v7 — Tappy Chicken Live PIE

Open `index.html` in a browser and select **Tappy Chicken**. Alternatively open `TappyChicken/index.html` directly.

## Added in v7
- Live Apply: adjust gravity, flap impulse, pipe speed/gap/width, spawn interval and seed while the JavaScript preview is running without restarting.
- Presets: Balanced, Floaty, Challenge.
- Undo / Redo for inspector tuning changes (local-only).
- Export / Import `TappyChicken.settings.json`.
- Retains v6 editor, game, library, discovery, analytics, safety, scene JSON and Lua example.

## Boundaries
- The browser game runs JavaScript, **not Lua VM**. `Scripts/Game.lua` remains an illustrative gameplay source.
- Hot Apply changes runtime parameters; it does not hot-reload source code. Seed changes affect the generator's subsequent use, while a restart is needed for a deterministic fresh run.
- No real C++ engine, GitHub, EOS, cloud services, multiplayer or native cooker integration.
- Settings and analytics are local mock data.
