# PlayForge Cloud — Frontend Interactive Preview v3

Open `index.html` in a modern browser. No server, npm, or external dependencies.

## Added in v3
- Top navigation: Editor, Shared Asset Library, Discover, Analytics, Safety
- Search/category/sort, free asset preview, favorites, version pinning
- Import preview options: scale, source axis, target platform, reference vs local copy
- Audio listening: an original synthesized demo tone (not a downloaded audio asset)
- Local reuse actions create ChangeSet previews and local analytics events
- Free asset share drafts, release validation drafts, report/moderation queue
- Event JSON export, localStorage persistence, responsive layout
- Preserves the previous Scene/Inspector/Lua/PIE mock and AI change workflow

## Limitations
Frontend-only demo. No real 3D renderer, backend, multiplayer, EOS/EAC, AI service, audio asset decoding, CDN, asset importer, cooker, payment, GitHub commits, release publishing, or server analytics. All sample counts and chart data are illustrative. Demo audio is generated in-browser from an oscillator.
