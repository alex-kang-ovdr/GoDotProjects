# PlayForge Studio v12 — Generic 2D/3D Editor

Open `index.html` in a browser. All operations are local mock behavior; no backend or native engine.

## New in v12
- Generic project-owned Prefab definitions
- Create Prefab from selected Actor, instantiate, apply, revert, unpack
- Duplicate selected Actor (Ctrl+D or toolbar)
- Prefab definitions persist in project JSON and LocalStorage, included in Export Project
- Unity-like split Scene/Game and resizable panes retained
- Tappy Chicken remains an independent sample project; no game-specific controls in editor

## Limitations
The 3D scene is a Canvas projection, not WebGL. Prefab Apply updates the definition; existing instances preserve their current properties instead of automatically resolving inherited values. Lua code is not executed. Game preview is JavaScript. No real network, EOS, or GitHub integration.
