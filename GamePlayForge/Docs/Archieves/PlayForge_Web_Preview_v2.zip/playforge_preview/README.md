# PlayForge Cloud — Interactive Web Editor Preview v2

Open `index.html` in Chrome or Edge. No installation, network, or server required.

## Interactive features
- Scene hierarchy selection, new GameObjects, search
- Canvas isometric scene preview, drag-to-move, wheel zoom
- Inspector edits with local autosave (`localStorage`)
- Conditional Undo/Redo for property edits
- Changes, History, Console, Project, Profiler panels
- Lua script editing mock
- Listen Server PIE visual preview (not a game engine)
- AI agent dry-run and mock changes
- Publish / source bundle / GitHub tag validation mock
- Collaboration presence mock

## Limitations
This is a front-end-only interactive prototype. It does not connect to GitHub, Havok, Lua VM, MCP, multiplayer servers, CRDT or actual cloud storage. Scene graphics are rendered in 2D Canvas to illustrate a 3D editor viewport.
