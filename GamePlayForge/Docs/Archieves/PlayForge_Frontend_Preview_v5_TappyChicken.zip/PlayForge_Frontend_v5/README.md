# PlayForge Frontend v5 — Tappy Chicken

Open `index.html` to explore the editor and choose **Tappy Chicken**. Open `TappyChicken/index.html` for standalone play.

## Added in v5
- Easy / Normal / Hard difficulty presets
- Pause / resume and restart controls
- Deterministic pipe sequence per reset (seeded PRNG)
- Debug collision / velocity overlay
- Editor-to-game postMessage controls and gameplay analytics event hooks
- Lua gameplay reference extended with matching difficulty presets
- QA checklist

## Limitations
Frontend prototype only. Lua code is a reference; JavaScript executes in the browser. No Lua VM, native engine, EOS, backend, GitHub, real asset cook, or multiplayer.
