# PlayForge Frontend v14 — Generic Prefab Variants

Open `index.html` in a browser. No server or external dependencies.

## New in v14
- Prefabs tab: Create Variant for any prefab; variants inherit parent defaults.
- Editing and applying a variant records its field-level differences from the parent.
- Applying a parent prefab propagates unchanged fields to descendant variants and their instances.
- Prefab validation detects missing parents, cycles and dangling instance references.
- Removing a parent with variants is blocked.
- Existing 2D/3D canvas scene, hierarchy, generic inspector, split view, Lua draft editor, Undo/Redo and Tappy Chicken example retained.

## Limitations
Frontend mock only. No C++ reflection, Lua VM, WebGL/WebGPU, cloud collaboration or EOS backend. Prefab variants are prototype JSON snapshots, not a production-ready stable Property ID implementation. Tappy Chicken-specific logic stays in the project.
