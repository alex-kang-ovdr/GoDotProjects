# PlayForge Cloud — Web Editor Mockup

Open `index.html` in a modern browser. No dependencies, build tools, or server are required.

## Included interactions
- Hierarchy selection and object creation
- Scene canvas mock (isometric grid, object picking, transform gizmo illustration)
- Inspector property editing and CDO/instance indicators
- Scene/Game/Script tabs, Listen Server PIE mock
- Changes staging, History, Console, Profiler
- Collaboration presence indicators
- AI agent mock with local-only batch actor creation
- Publish flow notification

This is a **front-end mockup**, not a connected engine, GitHub integration, real multiplayer, or actual AI agent.
