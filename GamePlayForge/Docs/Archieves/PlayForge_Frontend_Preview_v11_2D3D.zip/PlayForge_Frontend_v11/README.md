# PlayForge Frontend v11 — Generic 2D/3D Editor

Standalone browser mock. Open `index.html`.

## Changes
- Unity-style resizable left/right/bottom panels on desktop.
- Scene + Game split viewport (game preview for projects with an HTML preview).
- Generic 2D/3D scene with Move/Rotate/Scale manipulation.
- Transform inspector Position/Rotation/Scale.
- Grid snapping for drag movement (0.1/0.5/1 units).
- Scene drag operations now create undo snapshots.
- Tappy Chicken remains a separate example project; no game-specific platform editor controls.

## Scope
Canvas 2D drawing is used for the 3D perspective mock, not WebGL/WebGPU. The game preview is JavaScript, while Lua is a source example; no Lua VM, cloud services, EOS, multiplayer or native engine integration is included.
