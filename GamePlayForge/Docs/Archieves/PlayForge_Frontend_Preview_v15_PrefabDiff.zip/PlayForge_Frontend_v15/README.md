# PlayForge Frontend v15 — Generic Prefab Diff

## New
- Generic **Prefab Diff** tab for any project, not Tappy Chicken-specific.
- Per-property comparison of Prefab definition and selected Instance.
- Stable deterministic property path IDs (prototype FNV-1a; production requires reflection-generated IDs).
- Field-level Revert and Apply, Revert All, Apply All, validation, and JSON diff export.
- Existing 2D/3D Canvas Scene, Prefab Variants, Inspector, Lua source draft, Tappy Chicken example retained.

## Test
1. Open Empty Sandbox, select Cube and Create Prefab.
2. Instantiate the Prefab, select the instance and edit a property in Inspector.
3. Open Prefab Diff; compare fields and apply/revert individual changes.
4. Create a Variant from Prefabs and verify parent inheritance.

## Limitations
Frontend mock only. No C++ Reflection runtime, Lua VM, WebGL renderer, network collaboration, or real EOS integration. Property IDs are a deterministic demo hash, not production persistent GUIDs.
