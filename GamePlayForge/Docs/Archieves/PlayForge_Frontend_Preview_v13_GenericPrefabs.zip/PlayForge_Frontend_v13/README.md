# PlayForge Frontend v13 — Generic Prefab Inheritance

## Changes
- Live Prefab default propagation to linked instances on Apply.
- Explicit per-field overrides retained across Prefab updates.
- Inspector lists instance overrides and offers per-field Revert.
- Revert All, Unpack, Instantiate, Duplicate, Undo/Redo continue to work.
- Unity-inspired generic 2D/3D Canvas editor and standalone Tappy Chicken sample retained.

## Usage
Open `index.html`. Select Empty Sandbox, select `cube`, create Prefab, instantiate it twice, modify one instance's `roughness` property, select original and change its `label`, then Apply. The non-overridden label propagates; overridden roughness remains.

## Limits
Frontend-only mock. 3D scene uses Canvas projection, not WebGL. Reflection is JSON-driven, not native C++ reflection. PIE runs a JavaScript sample, not Lua 5.4 VM. No EOS/GitHub/backend. Old v12 browser localStorage projects may have prefab instances without a baseline; these are treated conservatively until Revert.
