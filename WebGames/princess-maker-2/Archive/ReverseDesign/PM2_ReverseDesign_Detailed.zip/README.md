# Princess Maker 2 역기획서

총 21개 시스템별 Markdown 문서. 원작 관찰 사항과 재구현 제안 구분.

- [게임 개요 및 코어 루프](00_Overview.md)
- [시간 및 일정 편성](01_Time_Schedule.md)
- [캐릭터 능력치](02_Character_Stats.md)
- [교육 시스템](03_Education.md)
- [아르바이트 시스템](04_Work.md)
- [경제 시스템](05_Economy.md)
- [건강과 컨디션](06_Health_Condition.md)
- [전투 시스템](07_Combat.md)
- [무사수행 및 탐험](08_Adventure.md)
- [아이템 및 장비](09_Equipment_Items.md)
- [이벤트 시스템](10_Events.md)
- [NPC 및 관계](11_NPC_Relationships.md)
- [평가와 성향](12_Reputation_Morality.md)
- [아버지 관계](13_Father_Relationship.md)
- [수확제와 대회](14_Festivals_Contests.md)
- [엔딩 판정](15_Endings.md)
- [UI/UX](16_UI_UX.md)
- [세이브 데이터](17_Save_Data.md)
- [밸런스 및 수식](18_Balance_Formulas.md)
- [웹 구현 아키텍처](19_Web_Architecture.md)
- [데이터 스키마](20_Data_Schemas.md)


## 상세화 업데이트
21개 시스템 문서에 구체적인 데이터 모델, 처리 시퀀스, 예외 정책, 5종 테스트 및 원작 검증 절차를 추가했습니다. 정량 수치는 원작 검증 전까지 제안으로 분류합니다.
