# EMBERWILD v13 — 웹 생존 게임

`index.html`을 Chrome/Edge/Firefox에서 열면 오프라인 실행됩니다.

## v13
- 나무와 바위를 클릭하면 도구 내구도가 남아 있는 동안 연속 채집합니다.
- 채집 간격 0.32초, 중간 이동/회피 시 취소할 수 있습니다.
- 도구 파손 시 자동 채집 중단, 새 도구 제작 후 다시 시도합니다.
- 이전 v2~v12 저장 슬롯을 읽고 v13 슬롯에 저장합니다.
- 자동 채집 회귀 테스트 추가.

## 조작
WASD 이동 · 클릭 이동/채집/건설 · E 상호작용 · Space 공격 · Shift 회피 · 1 열매 먹기 · 3 횃불 · F 모닥불 · C 보관함 · M 지도.

## 검증
`node --check game.js` · `node tests/smoke.js` · `node tests/integration.js` · `node tests/harvest.js`

16일 전체 플레이에 대한 자율 생존·밸런스 검증은 미완료입니다.
