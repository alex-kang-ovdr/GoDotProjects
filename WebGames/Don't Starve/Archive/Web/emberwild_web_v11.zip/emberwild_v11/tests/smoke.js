const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(require('path').join(__dirname,'../game.js'),'utf8');
const elements=new Map();
function el(id){if(!elements.has(id))elements.set(id,{id,style:{},value:'전체',textContent:'',innerHTML:'',hidden:false,disabled:false,onclick:null,onchange:null,dataset:{},getBoundingClientRect(){return {left:0,top:0,width:800,height:600}},addEventListener(){},querySelectorAll(){return []},getContext(){return ctx}});return elements.get(id)}
const ctx=new Proxy({createRadialGradient(){return {addColorStop(){}}}}, {get(o,k){return o[k]??(()=>{})}});
const store=new Map();let callback;
const sandbox={document:{getElementById:el,querySelectorAll(){return []}},window:{addEventListener(){}},localStorage:{setItem(k,v){store.set(k,v)},getItem(k){return store.get(k)||null}},performance:{now:()=>0},devicePixelRatio:1,requestAnimationFrame(fn){callback=fn},confirm:()=>true,console,Math,Set,Map,JSON,Number,Object,Array,Date};
vm.createContext(sandbox);
const hooked=src.replace('create();resize();requestAnimationFrame(frame);',`create();resize();requestAnimationFrame(frame);globalThis.TEST={get state(){return state},get goal(){return goal},set goal(v){goal=v},get route(){return route},tick,move,craft,placeAt,harvest,save,load,normalizeSave,decayFood,add,spawn,findPath};`);
vm.runInContext(hooked,sandbox);const t=sandbox.TEST;let count=0;
function test(name,fn){fn();count++;console.log('PASS',name)}
test('world initialization',()=>assert(t.state.entities.length>900));
test('starting inventory',()=>assert(t.state.inv.twig>=3));
test('craft axe',()=>{t.craft('axe');assert(t.state.gear.axe>0)});
test('craft placement',()=>{t.add('log',10);t.craft('fire');t.placeAt(t.state.player.x+100,t.state.player.y+100);if(!t.state.builds.some(b=>b.kind==='fire')){for(let a=0;a<16;a++){let angle=a*Math.PI/8;t.placeAt(t.state.player.x+110*Math.cos(angle),t.state.player.y+110*Math.sin(angle));if(t.state.builds.some(b=>b.kind==='fire'))break}}assert(t.state.builds.some(b=>b.kind==='fire'))});
test('save v11',()=>{t.save(true);assert(store.has('emberwild-save-v11'))});
test('load v11',()=>{t.state.health=12;t.load();assert(t.state.health===100)});
test('expired target cancels auto movement',()=>{let e=t.state.entities.find(e=>!e.dead&&e.kind==='twig');t.goal={x:e.x,y:e.y,eid:e.id};e.dead=true;t.move(.016);assert(t.goal===null)});
test('near target harvests immediately',()=>{let e=t.state.entities.find(e=>!e.dead&&e.kind==='twig');e.x=t.state.player.x+45;e.y=t.state.player.y;t.goal={x:e.x,y:e.y,eid:e.id};let before=t.state.inv.twig;t.move(.016);assert(t.state.inv.twig===before+1)});
test('chest food spoilage',()=>{t.state.builds.push({kind:'chest',x:100,y:100,inventory:{berry:4},foodAge:{berry:1}});t.decayFood();assert(t.state.builds.at(-1).inventory.spoiled===2)});
test('invalid inventory key rejected',()=>{let v=JSON.parse(JSON.stringify(t.state));v.inv.invalid=1;assert.throws(()=>t.normalizeSave(v))});
test('fractional inventory rejected',()=>{let v=JSON.parse(JSON.stringify(t.state));v.inv.twig=1.5;assert.throws(()=>t.normalizeSave(v))});
test('older v10 save accepted',()=>{let v=JSON.parse(JSON.stringify(t.state));v.version=10;assert(t.normalizeSave(v).version===11)});
test('night and day progress',()=>{t.state.time=179.99;t.tick(.03);assert(t.state.day===2)});
console.log(`${count}/${count} smoke tests passed`);
