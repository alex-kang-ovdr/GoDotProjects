const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const code=fs.readFileSync(path.join(__dirname,'..','game.js'),'utf8');
const elements=new Map();
function el(id){if(!elements.has(id))elements.set(id,{id,textContent:'',innerHTML:'',value:'전체',hidden:false,disabled:false,dataset:{},style:{},onclick:null,onchange:null,addEventListener(){},querySelectorAll(){return[]},getBoundingClientRect(){return {width:900,height:600,left:0,top:0}},getContext(){return new Proxy({setTransform(){},clearRect(){},save(){},restore(){},translate(){},scale(){},fillRect(){},beginPath(){},arc(){},stroke(){},fillText(){},createRadialGradient(){return {addColorStop(){}}}}, {get(t,k){return t[k]??(()=>{})},set(t,k,v){t[k]=v;return true}})}});return elements.get(id)}
const storage=new Map(),localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)};
const context={document:{getElementById:el,querySelectorAll(){return[]},createElement(){return {click(){}}}},window:{addEventListener(){}},localStorage,performance:{now:()=>0},devicePixelRatio:1,requestAnimationFrame(){},console,Math,Set,Map,Blob,URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){}},setTimeout(){},confirm(){return true}};
vm.createContext(context);
const instrument=code.replace(/\}\)\(\);\s*$/,`globalThis.__test={get state(){return state},setState(v){state=v},tick,craft,attack,harvest,spawn,save,load,create,add,phase,season,findPath};})();`);
vm.runInContext(instrument,context,{timeout:10000});
const t=context.__test;let passed=0;
function test(name,fn){fn();passed++;console.log('PASS',name)}
test('game initializes',()=>assert.equal(t.state.day,1));
test('world populated',()=>assert(t.state.entities.length>800));
test('starting resources',()=>assert(t.state.inv.twig>=3));
test('v15 save',()=>{t.save(true);assert(storage.has('emberwild-save-v15'));assert.equal(JSON.parse(storage.get('emberwild-save-v15')).version,15)});
test('v14 migration',()=>{let old=JSON.parse(storage.get('emberwild-save-v15'));old.version=14;storage.delete('emberwild-save-v15');storage.set('emberwild-save-v14',JSON.stringify(old));t.load();assert.equal(t.state.version,15);t.save(true);assert.equal(JSON.parse(storage.get('emberwild-save-v15')).version,15)});
test('craft axe',()=>{t.craft('axe');assert(t.state.gear.axe>0)});
test('day advances',()=>{t.state.time=179.99;t.state.health=100;t.state.hunger=100;t.state.torch=100;t.tick(.02);assert.equal(t.state.day,2)});
test('boss phase 2 radius',()=>{t.state.entities=[];t.state.builds=[];t.state.player={x:500,y:500};t.spawn('deer',550,500);let e=t.state.entities[0];e.hp=100;e.cool=0;e.windup=0;t.tick(.02);assert.equal(e.attackRadius,92)});
test('boss phase 1 radius',()=>{let e=t.state.entities[0];e.hp=200;e.cool=0;e.windup=0;t.tick(.02);assert.equal(e.attackRadius,70)});
test('attack warning has radius',()=>assert(t.state.entities[0].attackRadius>0));
test('save restore health',()=>{t.state.health=75;t.save(true);t.state.health=5;t.load();assert.equal(t.state.health,75)});
test('invalid save rejected',()=>{const before=t.state.health;storage.set('emberwild-save-v15','{broken');t.load();assert.equal(t.state.health,before)});
test('tool break stops repeat harvest',()=>{t.create();t.state.entities=[];t.state.player={x:500,y:500};t.spawn('tree',510,500);const tree=t.state.entities[0];t.state.gear.axe=1;t.harvest(tree);assert.equal(t.state.gear.axe,undefined);assert.equal(tree.hp,3)});
test('boss can spawn at entity cap',()=>{t.create();t.state.entities=Array.from({length:1400},(_,i)=>({id:i,kind:'tree',x:100+i,y:100,hp:4,dead:false}));t.spawn('deer',t.state.player.x+200,t.state.player.y);assert(t.state.entities.some(e=>e.kind==='deer'))});
test('invalid inventory type rejected',()=>{t.create();t.save(true);let data=JSON.parse(storage.get('emberwild-save-v15'));data.inv=['bad'];storage.set('emberwild-save-v15',JSON.stringify(data));let day=t.state.day;t.load();assert.equal(t.state.day,day)});
test('16th day boss appears',()=>{t.create();t.state.day=15;t.state.time=179.99;t.state.torch=100;t.state.health=100;t.tick(.02);assert.equal(t.state.day,16);assert(t.state.entities.some(e=>e.kind==='deer'&&!e.dead))});
console.log(`${passed}/${passed} tests passed`);
