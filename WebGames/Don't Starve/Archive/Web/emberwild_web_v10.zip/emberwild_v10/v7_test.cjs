const fs=require('fs'),vm=require('vm'),assert=require('assert');
const elements=new Map();const fake=()=>({textContent:'',innerHTML:'',hidden:false,disabled:false,value:'전체',dataset:{},style:{},addEventListener(){},getBoundingClientRect(){return {width:900,height:620,left:0,top:0}},getContext(){return new Proxy({},{get:()=>()=>{}})},setPointerCapture(){}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,fake());return elements.get(id)},querySelectorAll(){return []},createElement(){return fake()}};
const storage=new Map(),localStorage={setItem(k,v){storage.set(k,v)},getItem(k){return storage.get(k)||null}};let scheduled;const ctx={document,window:{addEventListener(){}},localStorage,performance:{now:()=>0},devicePixelRatio:1,requestAnimationFrame(f){scheduled=f},Math,console,confirm:()=>true,Blob,URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){}},setTimeout(){}};
vm.createContext(ctx);let code=fs.readFileSync(__dirname+'/game.js','utf8').replace(/\}\)\(\);\s*$/, 'globalThis.__test={create,craft,placeAt,save,load,attack,spawn,add,chestAction,decayFood,tick,normalizeSave,dodge,findPath,get state(){return state},setAttackCooldown(v){attackCooldown=v}};})();');vm.runInContext(code,ctx);const run=s=>vm.runInContext(s,ctx);
// dodge timer is simulation time rather than wall clock
run(`__test.state.entities=[];__test.state.stamina=100;__test.dodge()`);assert(run('__test.state.dodge>0'));run('__test.tick(3)');assert(run('__test.state.dodge===0'));console.log('PASS simulation-time dodge');
// 16-day progression from a healthy controlled simulation state
run(`__test.create();__test.state.entities=[];__test.state.builds=[];__test.state.health=100;__test.state.hunger=100;__test.state.torch=100000;`);
for(let day=1;day<16;day++){run(`__test.state.health=100;__test.state.hunger=100;__test.state.time=179.9;__test.tick(.2);__test.state.entities=[]`)}
assert(run('__test.state.day===16'));console.log('PASS 16-day transition');
run(`__test.state.day=15;__test.state.time=179.9;__test.state.entities=[];__test.tick(.2)`);assert(run('__test.state.entities.some(e=>e.kind==="deer")'));console.log('PASS boss transition');
run(`__test.state.victory=true;__test.state.boss=true;__test.state.entities=[];__test.state.time=179.9;__test.tick(.2)`);assert(!run('__test.state.entities.some(e=>e.kind==="deer")'));console.log('PASS boss does not respawn after victory');
assert.throws(()=>run(`__test.normalizeSave({version:7,player:{x:100,y:100},entities:[{kind:'tree',x:NaN,y:3,hp:2}],builds:[],inv:{},gear:{}})`));console.log('PASS malformed entity rejected');
run(`__test.save(true)`);assert(storage.has('emberwild-save-v10'));console.log('PASS v7 save key');
console.log('ALL V7 TESTS PASSED');
