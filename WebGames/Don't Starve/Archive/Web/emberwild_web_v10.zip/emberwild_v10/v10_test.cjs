const fs=require('fs'),vm=require('vm'),assert=require('assert');
const elements=new Map();const fake=()=>({textContent:'',innerHTML:'',hidden:false,disabled:false,value:'전체',dataset:{},style:{},addEventListener(){},getBoundingClientRect(){return {width:900,height:620,left:0,top:0}},getContext(){return new Proxy({},{get:()=>()=>{}})},setPointerCapture(){}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,fake());return elements.get(id)},querySelectorAll(){return []},createElement(){return fake()}};
const storage=new Map(),localStorage={setItem(k,v){storage.set(k,v)},getItem(k){return storage.get(k)||null}};const ctx={document,window:{addEventListener(){}},localStorage,performance:{now:()=>0},devicePixelRatio:1,requestAnimationFrame(){},Math,console,confirm:()=>true,Blob,URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){}},setTimeout(){}};
vm.createContext(ctx);let code=fs.readFileSync(__dirname+'/game.js','utf8').replace(/\}\)\(\);\s*$/, 'globalThis.__test={create,craft,placeAt,save,load,attack,spawn,add,chestAction,tick,normalizeSave,get state(){return state},setPaused(v){paused=v}};})();');vm.runInContext(code,ctx);const run=s=>vm.runInContext(s,ctx);
assert.strictEqual(run('__test.state.version'),10);console.log('PASS v10 startup');
run('__test.state.inv.twig=20;__test.state.inv.flint=20;__test.craft("axe")');assert(run('__test.state.gear.axe')>0);console.log('PASS craft tool');
run('__test.save(true)');assert(storage.has('emberwild-save-v10'));console.log('PASS v10 save');
const old=JSON.parse(storage.get('emberwild-save-v10'));old.version=9;storage.delete('emberwild-save-v10');storage.set('emberwild-save-v9',JSON.stringify(old));run('__test.load()');assert.strictEqual(run('__test.state.version'),10);console.log('PASS v9 migration');
assert.throws(()=>run(`__test.normalizeSave({version:10,player:{x:100,y:100},entities:[],builds:[{kind:'malicious',x:100,y:100,inventory:{}}],inv:{},gear:{},day:1,time:0,health:100,hunger:100,sanity:100})`));console.log('PASS invalid building rejected');
assert.throws(()=>run(`__test.normalizeSave({version:10,player:{x:100,y:100},entities:[],builds:[],groundDrops:[{id:'hacked',x:10,y:10,count:1}],inv:{},gear:{},day:1,time:0,health:100,hunger:100,sanity:100})`));console.log('PASS invalid drop rejected');
// Controlled 16-day progression with supplies and invulnerability; validates event lifecycle, not game balance.
run('__test.create();__test.state.health=100;__test.state.inv.berry=100;__test.state.torch=100000;__test.state.builds.push({kind:"fire",x:__test.state.player.x+65,y:__test.state.player.y,fuel:100000,inventory:{},hp:70})');
for(let day=1;day<16;day++){
 run('__test.state.health=100;__test.state.hunger=100;__test.state.sanity=100;__test.state.time=179.9;__test.tick(.2)');
 assert.strictEqual(run('__test.state.day'),day+1);
}
assert(run('__test.state.entities.some(e=>e.kind==="deer"&&!e.dead)'));console.log('PASS scripted 16-day event progression and boss spawn');
console.log('ALL V10 TESTS PASSED');
