'use strict';
const R=600000, MU=3.5316e12, G0=9.80665, ATM=70000;
const specs={pod:{name:'지휘 캡슐',dry:0.8,fuel:0,length:1.2},tank:{name:'연료 탱크',dry:0.5,fuel:3,length:2.0},engine:{name:'액체 엔진',dry:0.8,fuel:0,length:1.2,thrust:90000,isp:300},booster:{name:'고체 부스터',dry:0.8,fuel:1.7,length:2.3,thrust:65000,isp:220},fin:{name:'안정 날개',dry:0.15,fuel:0,length:0.6},parachute:{name:'낙하산',dry:0.12,fuel:0,length:0.4}};
let parts=['pod','tank','tank','engine'],mode='build',s,stage=0,parachute=false,keys=new Set(),camera='follow',last=performance.now();
const $=id=>document.getElementById(id),canvas=$('scene'),ctx=canvas.getContext('2d');
function mass(){return parts.reduce((a,k)=>a+specs[k].dry,0)+s.fuel+s.solid}
function maxFuel(){return parts.filter(x=>x==='tank').length*3}
function newState(){s={x:0,y:R+2,vx:0,vy:0,angle:0,omega:0,throttle:0,engine:false,booster:false,fuel:maxFuel(),solid:parts.filter(x=>x==='booster').length*1.7,t:0,peak:0,landed:false,crashed:false};stage=0;parachute=false}
newState();
function build(){mode='build';newState();updateUI()}
function launch(){newState();mode='flight';updateUI()}
function triggerStage(){if(mode!=='flight'||s.landed||s.crashed)return;if(stage===0){s.engine=parts.includes('engine');s.booster=parts.includes('booster');s.throttle=1;stage=1}else if(stage===1){parachute=true;stage=2}}
function physics(dt){if(mode!=='flight'||s.landed||s.crashed)return;
 const alt=Math.max(0,Math.hypot(s.x,s.y)-R),r=Math.hypot(s.x,s.y),ux=s.x/r,uy=s.y/r;
 const density=alt<ATM?1.225*Math.exp(-alt/7000):0;
 const speed=Math.hypot(s.vx,s.vy),dragArea=(parachute&&alt<ATM)?35:1.2+parts.filter(x=>x==='fin').length*.12;
 const drag=.5*density*speed*speed*dragArea*.55;
 let ax=-MU*s.x/(r*r*r),ay=-MU*s.y/(r*r*r);
 if(speed>1e-5){ax-=drag*s.vx/speed/(mass()*1000);ay-=drag*s.vy/speed/(mass()*1000)}
 const steer=(keys.has('a')?-1:0)+(keys.has('d')?1:0)+(keys.has('w')?-1:0)+(keys.has('s')?1:0);
 s.omega+=steer*1.4*dt;s.omega*=Math.exp(-2.0*dt);s.angle+=s.omega*dt;
 let thrust=0;
 if(s.engine&&s.fuel>0){let engines=parts.filter(x=>x==='engine').length,request=engines*90000*s.throttle,used=Math.min(s.fuel,request/(300*G0)/1000*dt);s.fuel-=used;thrust+=used*1000*300*G0/dt;if(s.fuel<=0)s.engine=false}
 if(s.booster&&s.solid>0){let boosters=parts.filter(x=>x==='booster').length,request=boosters*65000,used=Math.min(s.solid,request/(220*G0)/1000*dt);s.solid-=used;thrust+=used*1000*220*G0/dt;if(s.solid<=0)s.booster=false}
 // angle=0 means outward radial direction; rotate with planet local vertical.
 const heading=Math.atan2(uy,ux)-Math.PI/2+s.angle;
 ax+=thrust*Math.cos(heading)/(mass()*1000);ay+=thrust*Math.sin(heading)/(mass()*1000);
 s.vx+=ax*dt;s.vy+=ay*dt;s.x+=s.vx*dt;s.y+=s.vy*dt;s.t+=dt;
 let a=Math.hypot(s.x,s.y)-R;s.peak=Math.max(s.peak,a);
 if(a<=0){const vr=s.vx*ux+s.vy*uy,vt=Math.abs(s.vx*uy-s.vy*ux);s.x=ux*(R+1);s.y=uy*(R+1);s.vx=s.vy=0;if(Math.abs(vr)<9&&vt<7){s.landed=true}else{s.crashed=true}s.engine=false;s.booster=false}
}
function draw(){const dpr=window.devicePixelRatio||1,w=canvas.clientWidth,h=canvas.clientHeight;if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr)}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
 const alt=Math.max(0,Math.hypot(s.x,s.y)-R),scale=mode==='build'?1:Math.max(.04,Math.min(1,350/(alt+300)));const ground=h*.80;
 ctx.fillStyle='#10243b';ctx.fillRect(0,0,w,h);for(let i=0;i<70;i++){let x=(i*137.3)%w,y=(i*71.7)%h;ctx.fillStyle='#8eabc8';ctx.fillRect(x,y,1.3,1.3)}
 if(mode==='build'||alt<15000){ctx.fillStyle='#427a60';ctx.fillRect(0,ground,w,h-ground);ctx.fillStyle='#679579';ctx.fillRect(0,ground,w,6)}
 else{const planetY=ground+alt*scale;ctx.fillStyle='#427a60';ctx.beginPath();ctx.arc(w/2,planetY,R*scale,0,Math.PI*2);ctx.fill()}
 const cx=w/2,cy=mode==='build'?h*.46:ground-Math.min(alt*scale,ground*.43);ctx.save();ctx.translate(cx,cy);ctx.rotate(s.angle);const unit=17*scale;let offset=0;
 const sequence=[...parts].reverse();const total=sequence.reduce((a,k)=>a+specs[k].length,0);offset=total*unit/2;
 for(const k of sequence){const sp=specs[k],hh=sp.length*unit;offset-=hh;ctx.fillStyle=({pod:'#e7e9f2',tank:'#e2e5ee',engine:'#c46b44',booster:'#e7a64b',fin:'#65b5d5',parachute:'#e76472'})[k];ctx.strokeStyle='#16293c';ctx.lineWidth=1.5;let ww=(k==='booster'?31:23)*scale;if(k==='fin'){ctx.beginPath();ctx.moveTo(-ww/2,offset);ctx.lineTo(-ww,offset+hh);ctx.lineTo(ww,offset+hh);ctx.lineTo(ww/2,offset);ctx.closePath();ctx.fill()}else{ctx.fillRect(-ww/2,offset,ww,hh);ctx.strokeRect(-ww/2,offset,ww,hh)}if(k==='pod'){ctx.fillStyle='#65c9e8';ctx.fillRect(-ww*.23,offset+hh*.2,ww*.46,hh*.25)}}
 if(mode==='flight'&&(s.engine||s.booster)){ctx.fillStyle='#ff9b30';ctx.beginPath();ctx.moveTo(-8*scale,total*unit/2);ctx.lineTo(0,total*unit/2+Math.random()*36*scale+14*scale);ctx.lineTo(8*scale,total*unit/2);ctx.fill()}if(parachute){ctx.fillStyle='#ff7687';ctx.beginPath();ctx.arc(0,-total*unit/2-22*scale,30*scale,Math.PI,0);ctx.fill();ctx.strokeStyle='#fff';ctx.beginPath();ctx.moveTo(-30*scale,-total*unit/2-22*scale);ctx.lineTo(0,-total*unit/2);ctx.lineTo(30*scale,-total*unit/2-22*scale);ctx.stroke()}ctx.restore();
 if(mode==='build'){ctx.fillStyle='#aac8df';ctx.textAlign='center';ctx.fillText('조립 후 [발사 / 재시작]을 누르세요',w/2,35)}
}
function updateUI(){const alt=Math.max(0,Math.hypot(s.x,s.y)-R),speed=Math.hypot(s.vx,s.vy),rad=Math.hypot(s.x,s.y),energy=speed*speed/2-MU/rad,h=s.x*s.vy-s.y*s.vx,a=energy<0?-MU/(2*energy):Infinity,e=Math.sqrt(Math.max(0,1+2*energy*h*h/(MU*MU))),apo=Number.isFinite(a)&&e<1?a*(1+e)-R:Infinity;
 $('parts').innerHTML=parts.map((p,i)=>`<div class="part"><span>${i+1}. ${specs[p].name}</span><span>${specs[p].dry.toFixed(2)} t</span></div>`).join('');
 $('telemetry').innerHTML=`<p>시간: ${s.t.toFixed(1)} s</p><p>고도: ${(alt/1000).toFixed(2)} km</p><p>속도: ${speed.toFixed(1)} m/s</p><p>최고 고도: ${(s.peak/1000).toFixed(2)} km</p><p>예상 원지점: ${Number.isFinite(apo)?(apo/1000).toFixed(1)+' km':'탈출 궤도'}</p><p>질량: ${mass().toFixed(2)} t</p><p>액체 연료: ${s.fuel.toFixed(2)} t</p><p>고체 연료: ${s.solid.toFixed(2)} t</p><p>스로틀: ${Math.round(s.throttle*100)}%</p><p>단계: ${stage}</p>`;
 $('overlay').innerHTML=`<b>${mode==='build'?'VAB / 조립':s.crashed?'💥 기체 파괴':s.landed?'✅ 안전 착륙':'비행 중'}</b><br>ALT ${(alt).toFixed(0)} m<br>VEL ${speed.toFixed(0)} m/s<br>THR ${Math.round(s.throttle*100)}%<br>AP ${Number.isFinite(apo)?Math.round(apo/1000)+' km':'ESCAPE'}`;
 $('status').textContent=mode==='build'?'조립 모드':s.crashed?'기체 파괴':s.landed?'착륙 성공':'비행 중';
}
for(const b of document.querySelectorAll('[data-part]'))b.onclick=()=>{if(mode==='build'){parts.splice(parts.length-1,0,b.dataset.part);newState();updateUI()}};
$('remove').onclick=()=>{if(mode==='build'&&parts.length>1){parts.pop();newState();updateUI()}};
$('launch').onclick=launch;$('reset').onclick=build;$('stage').onclick=triggerStage;
window.addEventListener('keydown',e=>{let k=e.key.toLowerCase();if([' ','arrowup','arrowdown'].includes(k))e.preventDefault();keys.add(k);if(k===' '&&!e.repeat)triggerStage();if(k==='p')parachute=true;if(k==='arrowup')s.throttle=Math.min(1,s.throttle+.1);if(k==='arrowdown')s.throttle=Math.max(0,s.throttle-.1)});window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));
let uiAccum=0;function frame(now){let elapsed=Math.min(.05,(now-last)/1000);last=now;let warp=Number($('warp').value);let steps=Math.max(1,Math.ceil(elapsed*warp/.02));for(let i=0;i<steps;i++)physics(elapsed*warp/steps);draw();uiAccum+=elapsed;if(uiAccum>.12){updateUI();uiAccum=0}requestAnimationFrame(frame)}updateUI();requestAnimationFrame(frame);
