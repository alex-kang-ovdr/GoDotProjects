# Shadow over Mystara-inspired Web Combat v3

Open `index.html` in a modern browser; no server or dependencies.

## v3 features
- Spell and item selection overlays (Q/O, 1-4).
- Consumable inventory: healing potions, mana ethers, area bombs.
- Branch selection between stages with distinct rewards (1/2).
- Save and load via browser localStorage.
- Mobile selection controls.
- Existing six classes, combos, spells, enemy AI, bosses and waves remain.

## Controls
WASD move, J attack, K heavy, E skill, L guard, Space jump, Shift dash, Q spell ring, O item ring, 1-4 select, U cast, I use item, P pause, R restart.

Original character artwork and exact frame data are not included. This is an independent educational gameplay prototype.
