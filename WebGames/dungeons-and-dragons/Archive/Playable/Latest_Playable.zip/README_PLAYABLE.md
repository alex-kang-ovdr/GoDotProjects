# Dungeons & Dragons - Shadow over Mystara — 최신 보관 실행본

- 출처: 이전 작업에서 실제 생성된 `Shadow_over_Mystara_Web_Enhanced_v4.zip`
- 실행: 압축 해제 후 `index.html` 또는 `RUN_GAME.cmd` 실행
- 기본 형태: HTML + JavaScript, 온라인 서버 없이 브라우저에서 실행하도록 구성된 보관본
- 외부 에셋 호출, 브라우저 정책 및 원작과의 차이는 개별 프로젝트 문서 확인
- 최신의 의미: **이번 아카이브에서 확인된 가장 최신의 웹 실행 소스 버전**. 이전 ChatGPT 웹 배포의 더 최신 버전이 있을 수 있습니다.
- `RUN_GAME.cmd` 는 기본 웹 브라우저로 HTML을 여는 편의 파일이며 서버 설치가 필요하지 않습니다.
- 원작 게임 실행 파일이 아닌 재구축 웹 프로토타입입니다.
