# Shadow over Mystara inspired browser combat prototype

Original, standalone HTML5 Canvas and vanilla JavaScript implementation. Open `index.html` in any modern browser. No dependencies or server required.

## Features
- Six selectable class archetypes with different health, mana, speed, damage and reach
- 2.5D lane movement, sprint, jump, facing, light/heavy attacks, three-hit combo multiplier
- Guarding (excluding thief and mage), potions, area spells, hit stun, invulnerability, knockback
- Melee goblins, ranged-distance AI archetype, boss encounters
- Three stages, three waves per stage, healing between stages, score and victory/defeat
- Fixed 60 Hz gameplay tick with canvas rendering

## Notes
This is a playable approximation inspired by the game's genre, not a frame-accurate recreation. Placeholder geometric graphics are original and no copyrighted game assets are included. AI archer currently uses a proximity strike rather than a projectile.
