# Dark Descent — Diablo II-inspired browser ARPG prototype

Open `index.html` in a modern browser. No dependencies, build step, or server required.

## Implemented
- Procedurally generated interconnected dungeon rooms and corridors
- WASD / touch or pointer movement, melee attack, fireball, healing
- Monster pursuit AI, elite monsters, health, damage, waves
- Experience, leveling, random item drops, equipment, potions, gold
- Inventory UI, equipment stats, localStorage save/load

## Controls
WASD move, left mouse click move/attack and fireball, 1 melee, 2 fireball, 3 heal, E pick up, I toggle inventory.

## Limitations
Original independent prototype, not Diablo II code or assets. Combat calculations, itemization, AI and content are simplified. No multiplayer or original copyrighted assets.
