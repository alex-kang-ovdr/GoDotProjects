# Diablo II 역기획서 — 시스템별 문서

> 분석 기준: Diablo II + Lord of Destruction 중심, Diablo II: Resurrected 차이는 필요 시 명시. 비공식 역설계 문서이며 내부 원본 설계서가 아닙니다.

## 문서 목록

- [게임 개요 및 핵심 루프](00_Overview.md)
- [캐릭터 및 직업](01_Character_Classes.md)
- [전투 및 판정](02_Combat.md)
- [스킬 및 성장](03_Skills.md)
- [능력치 및 파생 스탯](04_Stats.md)
- [아이템·장비·옵션](05_Items.md)
- [드롭 및 파밍](06_Loot.md)
- [몬스터·AI·챔피언](07_Monsters_AI.md)
- [월드·맵·던전](08_World_Maps.md)
- [퀘스트·액트 진행](09_Quests.md)
- [난이도·레벨링·엔드게임](10_Difficulty.md)
- [경제·상점·큐브·룬워드](11_Economy_Crafting.md)
- [인벤토리·창고·UI](12_Inventory_UI.md)
- [용병·동료](13_Mercenary.md)
- [멀티플레이·거래·동기화](14_Multiplayer.md)
- [저장·데이터·구현 구조](15_Save_Architecture.md)
- [밸런스·테스트·계측](16_Balance_Test.md)

## 시스템 간 의존 관계
`World → Monster → Combat → Loot → Inventory → Character/Skill → Difficulty`

`Quest → World Unlock`, `Economy/Crafting → Items`, `Save → 모든 영속 상태`

## 역기획 범위와 한계
- 공개된 플레이 규칙을 바탕으로 한 시스템 구조 분석 및 구현 제안.
- 원본 내부 소스코드, 정확한 서버 구현, 확률 테이블을 확인한 문서는 아님.
- 실제 개발 시 패치 버전별 데이터 테이블과 테스트 결과로 보완 필요.
