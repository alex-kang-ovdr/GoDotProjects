# Orbital Workshop v5 — KSP-style 2D browser game

Open `play.html` directly in a modern browser. No server or dependencies required.

## New in v5
- Persistent career: launch cost, funds, science, reputation, first-time contracts
- Science observations by environment (surface, atmosphere, space, stable orbit)
- Technology research (reaction wheels); persistent progress via localStorage
- Recovery reward after safe landing; career reset
- Corrected landing radial-speed safety test

## Existing v4 systems
- Rocket editor, stages, fuel, thrust, atmospheric drag, SAS, maneuver nodes, orbital map, autopilot and quicksave.

## Limitations
2D single-body approximation. No 3D joints, multi-body patched conics or full original KSP content. The game uses independently authored simplified rules.
